# 1 "c:\\lr_scripts\\demo_script\\combined_Demo_script.c"
# 1 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/lrun.h" 1
 
 












 











# 103 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/lrun.h"





















































		


		typedef unsigned size_t;
	
	
        
	

















	

 



















 
 
 
 
 


 
 
 
 
 
 














int     lr_start_transaction   (char * transaction_name);
int lr_start_sub_transaction          (char * transaction_name, char * trans_parent);
long lr_start_transaction_instance    (char * transaction_name, long parent_handle);
int   lr_start_cross_vuser_transaction		(char * transaction_name, char * trans_id_param); 



int     lr_end_transaction     (char * transaction_name, int status);
int lr_end_sub_transaction            (char * transaction_name, int status);
int lr_end_transaction_instance       (long transaction, int status);
int   lr_end_cross_vuser_transaction	(char * transaction_name, char * trans_id_param, int status);


 
typedef char* lr_uuid_t;
 



lr_uuid_t lr_generate_uuid();

 


int lr_generate_uuid_free(lr_uuid_t uuid);

 



int lr_generate_uuid_on_buf(lr_uuid_t buf);

   
# 273 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/lrun.h"
int lr_start_distributed_transaction  (char * transaction_name, lr_uuid_t correlator, long timeout  );

   







int lr_end_distributed_transaction  (lr_uuid_t correlator, int status);


double lr_stop_transaction            (char * transaction_name);
double lr_stop_transaction_instance   (long parent_handle);


void lr_resume_transaction           (char * trans_name);
void lr_resume_transaction_instance  (long trans_handle);


int lr_update_transaction            (const char *trans_name);


 
void lr_wasted_time(long time);


 
int lr_set_transaction(const char *name, double duration, int status);
 
long lr_set_transaction_instance(const char *name, double duration, int status, long parent_handle);


int   lr_user_data_point                      (char *, double);
long lr_user_data_point_instance                   (char *, double, long);
 



int lr_user_data_point_ex(const char *dp_name, double value, int log_flag);
long lr_user_data_point_instance_ex(const char *dp_name, double value, long parent_handle, int log_flag);


int lr_transaction_add_info      (const char *trans_name, char *info);
int lr_transaction_instance_add_info   (long trans_handle, char *info);
int lr_dpoint_add_info           (const char *dpoint_name, char *info);
int lr_dpoint_instance_add_info        (long dpoint_handle, char *info);


double lr_get_transaction_duration       (char * trans_name);
double lr_get_trans_instance_duration    (long trans_handle);
double lr_get_transaction_think_time     (char * trans_name);
double lr_get_trans_instance_think_time  (long trans_handle);
double lr_get_transaction_wasted_time    (char * trans_name);
double lr_get_trans_instance_wasted_time (long trans_handle);
int    lr_get_transaction_status		 (char * trans_name);
int	   lr_get_trans_instance_status		 (long trans_handle);

 



int lr_set_transaction_status(int status);

 



int lr_set_transaction_status_by_name(int status, const char *trans_name);
int lr_set_transaction_instance_status(int status, long trans_handle);


typedef void* merc_timer_handle_t;
 

merc_timer_handle_t lr_start_timer();
double lr_end_timer(merc_timer_handle_t timer_handle);


 
 
 
 
 
 











 



int   lr_rendezvous  (char * rendezvous_name);
 




int   lr_rendezvous_ex (char * rendezvous_name);



 
 
 
 
 
char *lr_get_vuser_ip (void);
void   lr_whoami (int *vuser_id, char ** sgroup, int *scid);
char *	  lr_get_host_name (void);
char *	  lr_get_master_host_name (void);

 
long     lr_get_attrib_long	(char * attr_name);
char *   lr_get_attrib_string	(char * attr_name);
double   lr_get_attrib_double      (char * attr_name);

char * lr_paramarr_idx(const char * paramArrayName, unsigned int index);
char * lr_paramarr_random(const char * paramArrayName);
int    lr_paramarr_len(const char * paramArrayName);

int	lr_param_unique(const char * paramName);
int lr_param_sprintf(const char * paramName, const char * format, ...);


 
 
static void *ci_this_context = 0;






 








void lr_continue_on_error (int lr_continue);
char *   lr_unmask (const char *EncodedString);
char *   lr_decrypt (const char *EncodedString);
char *   lr_encrypt_ex (const char *plaintext);
char *   lr_decrypt_ex (const char *EncodedString);


 
 
 
 
 
 



 







 















void   lr_abort (void);
void lr_exit(int exit_option, int exit_status);
void lr_abort_ex (unsigned long flags);

void   lr_peek_events (void);


 
 
 
 
 


void   lr_think_time (double secs);

 


void lr_force_think_time (double secs);


 
 
 
 
 



















int   lr_msg (char * fmt, ...);
int   lr_debug_message (unsigned int msg_class,
									    char * format,
										...);
# 515 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/lrun.h"
void   lr_new_prefix (int type,
                                 char * filename,
                                 int line);
# 518 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/lrun.h"
int   lr_log_message (char * fmt, ...);
int   lr_message (char * fmt, ...);
int   lr_error_message (char * fmt, ...);
int   lr_output_message (char * fmt, ...);
int   lr_vuser_status_message (char * fmt, ...);
int   lr_error_message_without_fileline (char * fmt, ...);
int   lr_fail_trans_with_error (char * fmt, ...);

 
 
 
 
 
# 542 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/lrun.h"

 
 
 
 
 





int   lr_next_row ( char * table);
int lr_advance_param ( char * param);



														  
														  

														  
														  

													      
 


char *   lr_eval_string (char * str);
int   lr_eval_string_ext (const char *in_str,
                                     unsigned long const in_len,
                                     char ** const out_str,
                                     unsigned long * const out_len,
                                     unsigned long const options,
                                     const char *file,
								     long const line);
# 576 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/lrun.h"
void   lr_eval_string_ext_free (char * * pstr);

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
int lr_param_increment (char * dst_name,
                              char * src_name);
# 599 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/lrun.h"













											  
											  

											  
											  
											  

int	  lr_save_var (char *              param_val,
							  unsigned long const param_val_len,
							  unsigned long const options,
							  char *			  param_name);
# 623 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/lrun.h"
int   lr_save_string (const char * param_val, const char * param_name);



int   lr_set_custom_error_message (const char * param_val, ...);

int   lr_remove_custom_error_message ();


int   lr_free_parameter (const char * param_name);
int   lr_save_int (const int param_val, const char * param_name);
int   lr_save_timestamp (const char * tmstampParam, ...);
int   lr_save_param_regexp (const char *bufferToScan, unsigned int bufSize, ...);

int   lr_convert_double_to_integer (const char *source_param_name, const char * target_param_name);
int   lr_convert_double_to_double (const char *source_param_name, const char *format_string, const char * target_param_name);

 
 
 
 
 
 
# 702 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/lrun.h"
void   lr_save_datetime (const char *format, int offset, const char *name);









 











 
 
 
 
 






 



char * lr_error_context_get_entry (char * key);

 



long   lr_error_context_get_error_id (void);


 
 
 

int lr_table_get_rows_num (char * param_name);

int lr_table_get_cols_num (char * param_name);

char * lr_table_get_cell_by_col_index (char * param_name, int row, int col);

char * lr_table_get_cell_by_col_name (char * param_name, int row, const char* col_name);

int lr_table_get_column_name_by_index (char * param_name, int col, 
											char * * const col_name,
											size_t * col_name_len);
# 763 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/lrun.h"

int lr_table_get_column_name_by_index_free (char * col_name);

 
 
 
 
# 778 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/lrun.h"
int   lr_zip (const char* param1, const char* param2);
int   lr_unzip (const char* param1, const char* param2);

 
 
 
 
 
 
 
 

 
 
 
 
 
 
int   lr_param_substit (char * file,
                                   int const line,
                                   char * in_str,
                                   size_t const in_len,
                                   char * * const out_str,
                                   size_t * const out_len);
# 802 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/lrun.h"
void   lr_param_substit_free (char * * pstr);


 
# 814 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/lrun.h"





char *   lrfnc_eval_string (char * str,
                                      char * file_name,
                                      long const line_num);
# 822 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/lrun.h"


int   lrfnc_save_string ( const char * param_val,
                                     const char * param_name,
                                     const char * file_name,
                                     long const line_num);
# 828 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/lrun.h"

int   lrfnc_free_parameter (const char * param_name );







typedef struct _lr_timestamp_param
{
	int iDigits;
}lr_timestamp_param;

extern const lr_timestamp_param default_timestamp_param;

int   lrfnc_save_timestamp (const char * param_name, const lr_timestamp_param* time_param);

int lr_save_searched_string(char * buffer, long buf_size, unsigned int occurrence,
			    char * search_string, int offset, unsigned int param_val_len, 
			    char * param_name);

 
char *   lr_string (char * str);

 
# 933 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/lrun.h"

int   lr_save_value (char * param_val,
                                unsigned long const param_val_len,
                                unsigned long const options,
                                char * param_name,
                                char * file_name,
                                long const line_num);
# 940 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/lrun.h"


 
 
 
 
 











int   lr_printf (char * fmt, ...);
 
int   lr_set_debug_message (unsigned int msg_class,
                                       unsigned int swtch);
# 962 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/lrun.h"
unsigned int   lr_get_debug_message (void);


 
 
 
 
 

void   lr_double_think_time ( double secs);
void   lr_usleep (long);


 
 
 
 
 
 




int *   lr_localtime (long offset);


int   lr_send_port (long port);


# 1038 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/lrun.h"



struct _lr_declare_identifier{
	char signature[24];
	char value[128];
};

int   lr_pt_abort (void);

void vuser_declaration (void);






# 1067 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/lrun.h"


# 1079 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/lrun.h"
















 
 
 
 
 







int    _lr_declare_transaction   (char * transaction_name);


 
 
 
 
 







int   _lr_declare_rendezvous  (char * rendezvous_name);

 
 
 
 
 







int   lr_cyberark_get_vault(char * first_param, ...);
int   lr_cyberark_get_vault_no_ellipsis(const char* first_param, char** arguments, int argCount);

 
 
 
 
 







int   lr_aws_get_secret(char * first_param, ...);
int   lr_aws_get_secret_no_ellipsis(const char* first_param, char** arguments, int argCount);

 
 
 
 
 







int   lr_azure_set_service_port(int portNum);
int   lr_azure_ad_client_get_token(char * first_param, ...);
int   lr_azure_ad_client_get_token_no_ellipsis(const char* first_param, char** arguments, int argCount);
int   lr_azure_kv_get_secret(char * first_param, ...);
int   lr_azure_kv_get_secret_no_ellipsis(const char* first_param, char** arguments, int argCount);

 
 
 
 
 







int   lr_hashicorp_vault_get_secret_with_token(char * first_param, ...);
int   lr_hashicorp_vault_get_secret_with_token_no_ellipsis(const char* first_param, char** arguments, int argCount);
int   lr_hashicorp_vault_get_secret_with_approle_auth(char * first_param, ...);
int   lr_hashicorp_vault_get_secret_with_approle_auth_no_ellipsis(const char* first_param, char** arguments, int argCount);
int   lr_hashicorp_vault_get_secret_with_jwt_auth(char * first_param, ...);
int   lr_hashicorp_vault_get_secret_with_jwt_auth_no_ellipsis(const char* first_param, char** arguments, int argCount);
int   lr_hashicorp_vault_get_secret_with_userpass_auth(char * first_param, ...);
int   lr_hashicorp_vault_get_secret_with_userpass_auth_no_ellipsis(const char* first_param, char** arguments, int argCount);
int   lr_hashicorp_vault_save_secret_from_json(char * first_param, ...);
int   lr_hashicorp_vault_save_secret_from_json_no_ellipsis(const char* first_param, char** arguments, int argCount);

 
 
 
 
 


typedef int PVCI;






typedef int VTCERR;









PVCI   vtc_connect(char * servername, int portnum, int options);
VTCERR   vtc_disconnect(PVCI pvci);
VTCERR   vtc_get_last_error(PVCI pvci);
VTCERR   vtc_query_column(PVCI pvci, char * columnName, int columnIndex, char * *outvalue);
VTCERR   vtc_query_row(PVCI pvci, int rowIndex, char * **outcolumns, char * **outvalues);
VTCERR   vtc_send_message(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_if_unique(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_row1(PVCI pvci, char * columnNames, char * messages, char * delimiter, unsigned char sendflag, unsigned short *outUpdates);
VTCERR   vtc_search_row(PVCI pvci, char * columnNames, char * messages, char * delimiter, char * **outcolumns, char * **outvalues);
VTCERR   vtc_update_message(PVCI pvci, char * column, int index , char * message, unsigned short *outRc);
VTCERR   vtc_update_message_ifequals(PVCI pvci, char * columnName, int index,	char * message, char * ifmessage, unsigned short 	*outRc);
VTCERR   vtc_update_row1(PVCI pvci, char * columnNames, int index , char * messages, char * delimiter, unsigned short *outUpdates);
VTCERR   vtc_retrieve_message(PVCI pvci, char * column, char * *outvalue);
VTCERR   vtc_retrieve_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues);
VTCERR   vtc_retrieve_row(PVCI pvci, char * **outcolumns, char * **outvalues);
VTCERR   vtc_rotate_message(PVCI pvci, char * column, char * *outvalue, unsigned char sendflag);
VTCERR   vtc_rotate_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_rotate_row(PVCI pvci, char * **outcolumns, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_increment(PVCI pvci, char * column, int index , int incrValue, int *outValue);
VTCERR   vtc_clear_message(PVCI pvci, char * column, int index , unsigned short *outRc);
VTCERR   vtc_clear_column(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_ensure_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_drop_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_clear_row(PVCI pvci, int rowIndex, unsigned short *outRc);
VTCERR   vtc_create_column(PVCI pvci, char * column,unsigned short *outRc);
VTCERR   vtc_column_size(PVCI pvci, char * column, int *size);
void   vtc_free(char * msg);
void   vtc_free_list(char * *msglist);
VTCERR   vtc_update_all_message_ifequals(PVCI pvci, char * columnNames, char * message, char * ifmessage, char * delimiter, unsigned short *outRc);

VTCERR   lrvtc_connect(char * servername, int portnum, int options);
VTCERR   lrvtc_connect_ex(char * vtc_first_param, ...);
VTCERR   lrvtc_connect_ex_no_ellipsis(const char *vtc_first_param, char ** arguments, int argCount);
VTCERR   lrvtc_disconnect();
VTCERR   lrvtc_query_column(char * columnName, int columnIndex);
VTCERR   lrvtc_query_row(int columnIndex);
VTCERR   lrvtc_send_message(char * columnName, char * message);
VTCERR   lrvtc_send_if_unique(char * columnName, char * message);
VTCERR   lrvtc_send_row1(char * columnNames, char * messages, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_search_row(char * columnNames, char * messages, char * delimiter);
VTCERR   lrvtc_update_message(char * columnName, int index , char * message);
VTCERR   lrvtc_update_message_ifequals(char * columnName, int index, char * message, char * ifmessage);
VTCERR   lrvtc_update_row1(char * columnNames, int index , char * messages, char * delimiter);
VTCERR   lrvtc_retrieve_message(char * columnName);
VTCERR   lrvtc_retrieve_messages1(char * columnNames, char * delimiter);
VTCERR   lrvtc_retrieve_row();
VTCERR   lrvtc_rotate_message(char * columnName, unsigned char sendflag);
VTCERR   lrvtc_rotate_messages1(char * columnNames, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_rotate_row(unsigned char sendflag);
VTCERR   lrvtc_increment(char * columnName, int index , int incrValue);
VTCERR   lrvtc_noop();
VTCERR   lrvtc_clear_message(char * columnName, int index);
VTCERR   lrvtc_clear_column(char * columnName); 
VTCERR   lrvtc_ensure_index(char * columnName); 
VTCERR   lrvtc_drop_index(char * columnName); 
VTCERR   lrvtc_clear_row(int rowIndex);
VTCERR   lrvtc_create_column(char * columnName);
VTCERR   lrvtc_column_size(char * columnName);
VTCERR   lrvtc_update_all_message_ifequals(char * columnNames, char * message, char * ifmessage, char * delimiter);



 
 
 
 
 

 
int lr_enable_ip_spoofing();
int lr_disable_ip_spoofing();


 




int lr_convert_string_encoding(char * sourceString, char * fromEncoding, char * toEncoding, char * paramName);
int lr_read_file(const char *filename, const char *outputParam, int continueOnError);

int lr_get_char_count(const char * string);


 
int lr_db_connect (char * pFirstArg, ...);
int lr_db_disconnect (char * pFirstArg,	...);
int lr_db_executeSQLStatement (char * pFirstArg, ...);
int lr_db_dataset_action(char * pFirstArg, ...);
int lr_checkpoint(char * pFirstArg,	...);
int lr_db_getvalue(char * pFirstArg, ...);







 
 

















# 1 "c:\\lr_scripts\\demo_script\\combined_Demo_script.c" 2

# 1 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/SharedParameter.h" 1



 
 
 
 
# 100 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/SharedParameter.h"






typedef int PVCI2;






typedef int VTCERR2;


 
 
 

 
extern PVCI2    vtc_connect(char *servername, int portnum, int options);
extern VTCERR2  vtc_disconnect(PVCI2 pvci);
extern VTCERR2  vtc_get_last_error(PVCI2 pvci);

 
extern VTCERR2  vtc_query_column(PVCI2 pvci, char *columnName, int columnIndex, char **outvalue);
extern VTCERR2  vtc_query_row(PVCI2 pvci, int columnIndex, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_send_message(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_if_unique(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_row1(PVCI2 pvci, char *columnNames, char *messages, char *delimiter,  unsigned char sendflag, unsigned short *outUpdates);
extern VTCERR2  vtc_search_row(PVCI2 pvci, char *columnNames, char *messages, char *delimiter, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_update_message(PVCI2 pvci, char *column, int index , char *message, unsigned short *outRc);
extern VTCERR2  vtc_update_message_ifequals(PVCI2 pvci, char	*columnName, int index,	char *message, char	*ifmessage,	unsigned short 	*outRc);
extern VTCERR2  vtc_update_row1(PVCI2 pvci, char *columnNames, int index , char *messages, char *delimiter, unsigned short *outUpdates);
extern VTCERR2  vtc_retrieve_message(PVCI2 pvci, char *column, char **outvalue);
extern VTCERR2  vtc_retrieve_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues);
extern VTCERR2  vtc_retrieve_row(PVCI2 pvci, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_rotate_message(PVCI2 pvci, char *column, char **outvalue, unsigned char sendflag);
extern VTCERR2  vtc_rotate_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues, unsigned char sendflag);
extern VTCERR2  vtc_rotate_row(PVCI2 pvci, char ***outcolumns, char ***outvalues, unsigned char sendflag);
extern VTCERR2	vtc_increment(PVCI2 pvci, char *column, int index , int incrValue, int *outValue);
extern VTCERR2  vtc_clear_message(PVCI2 pvci, char *column, int index , unsigned short *outRc);
extern VTCERR2  vtc_clear_column(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_clear_row(PVCI2 pvci, int rowIndex, unsigned short *outRc);

extern VTCERR2  vtc_create_column(PVCI2 pvci, char *column,unsigned short *outRc);
extern VTCERR2  vtc_column_size(PVCI2 pvci, char *column, int *size);
extern VTCERR2  vtc_ensure_index(PVCI2 pvci, char *column, unsigned short *outRc);
extern VTCERR2  vtc_drop_index(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_noop(PVCI2 pvci);

 
extern void vtc_free(char *msg);
extern void vtc_free_list(char **msglist);

 


 




 




















 




 
 
 

extern VTCERR2  lrvtc_connect(char *servername, int portnum, int options);
 
 
extern VTCERR2  lrvtc_disconnect();
extern VTCERR2  lrvtc_query_column(char *columnName, int columnIndex);
extern VTCERR2  lrvtc_query_row(int columnIndex);
extern VTCERR2  lrvtc_send_message(char *columnName, char *message);
extern VTCERR2  lrvtc_send_if_unique(char *columnName, char *message);
extern VTCERR2  lrvtc_send_row1(char *columnNames, char *messages, char *delimiter,  unsigned char sendflag);
extern VTCERR2  lrvtc_search_row(char *columnNames, char *messages, char *delimiter);
extern VTCERR2  lrvtc_update_message(char *columnName, int index , char *message);
extern VTCERR2  lrvtc_update_message_ifequals(char *columnName, int index, char 	*message, char *ifmessage);
extern VTCERR2  lrvtc_update_row1(char *columnNames, int index , char *messages, char *delimiter);
extern VTCERR2  lrvtc_retrieve_message(char *columnName);
extern VTCERR2  lrvtc_retrieve_messages1(char *columnNames, char *delimiter);
extern VTCERR2  lrvtc_retrieve_row();
extern VTCERR2  lrvtc_rotate_message(char *columnName, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_messages1(char *columnNames, char *delimiter, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_row(unsigned char sendflag);
extern VTCERR2  lrvtc_increment(char *columnName, int index , int incrValue);
extern VTCERR2  lrvtc_clear_message(char *columnName, int index);
extern VTCERR2  lrvtc_clear_column(char *columnName);
extern VTCERR2  lrvtc_clear_row(int rowIndex);
extern VTCERR2  lrvtc_create_column(char *columnName);
extern VTCERR2  lrvtc_column_size(char *columnName);
extern VTCERR2  lrvtc_ensure_index(char *columnName);
extern VTCERR2  lrvtc_drop_index(char *columnName);

extern VTCERR2  lrvtc_noop();

 
 
 

                               


 
 
 





















# 2 "c:\\lr_scripts\\demo_script\\combined_Demo_script.c" 2

# 1 "globals.h" 1



 
 

# 1 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/web_api.h" 1







# 1 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/as_web.h" 1



























































 




 



 











 





















 
 
 

  int
	web_add_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_add_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
	
  int
	web_add_auto_header(
		const char *		mpszHeader,
		const char *		mpszValue);

  int
	web_add_header(
		const char *		mpszHeader,
		const char *		mpszValue);
  int
	web_add_cookie(
		const char *		mpszCookie);
  int
	web_cleanup_auto_headers(void);
  int
	web_cleanup_cookies(void);
  int
	web_concurrent_end(
		const char * const	mpszReserved,
										 
		...								 
	);
  int
	web_concurrent_start(
		const char * const	mpszConcurrentGroupName,
										 
										 
		...								 
										 
	);
  int
	web_create_html_param(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim);
  int
	web_create_html_param_ex(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim,
		const char *		mpszNum);
  int
	web_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_disable_keep_alive(void);
  int
	web_enable_keep_alive(void);
  int
	web_find(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_get_int_property(
		const int			miHttpInfoType);
  int
	web_image(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_image_check(
		const char *		mpszName,
		...);
  int
	web_java_check(
		const char *		mpszName,
		...);
  int
	web_link(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

	
  int
	web_global_verification(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
  int
	web_reg_find(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
				
  int
	web_reg_save_param(
		const char *		mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 

  int
	web_convert_param(
		const char * 		mpszParamName, 
										 
		...);							 
										 
										 


										 

										 
  int
	web_remove_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
				
  int
	web_remove_auto_header(
		const char *		mpszHeaderName,
		...);							 
										 



  int
	web_remove_cookie(
		const char *		mpszCookie);

  int
	web_save_header(
		const char *		mpszType,	 
		const char *		mpszName);	 
  int
	web_set_certificate(
		const char *		mpszIndex);
  int
	web_set_certificate_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_set_connections_limit(
		const char *		mpszLimit);
  int
	web_set_max_html_param_len(
		const char *		mpszLen);
  int
	web_set_max_retries(
		const char *		mpszMaxRetries);
  int
	web_set_proxy(
		const char *		mpszProxyHost);
  int
	web_set_pac(
		const char *		mpszPacUrl);
  int
	web_set_proxy_bypass(
		const char *		mpszBypass);
  int
	web_set_secure_proxy(
		const char *		mpszProxyHost);
  int
	web_set_sockets_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue
	);
  int
	web_set_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue,
		...								 
	);
  int
	web_set_timeout(
		const char *		mpszWhat,
		const char *		mpszTimeout);
  int
	web_set_user(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);

  int
	web_sjis_to_euc_param(
		const char *		mpszParamName,
										 
		const char *		mpszParamValSjis);
										 

  int
	web_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_submit_form(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	spdy_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_set_proxy_bypass_local(
		const char * mpszNoLocal
		);

  int 
	web_cache_cleanup(void);

  int
	web_create_html_query(
		const char* mpszStartQuery,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_create_radio_button_param(
		const char *NameFiled,
		const char *NameAndVal,
		const char *ParamName
		);

  int
	web_convert_from_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										
  int
	web_convert_to_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_ex(
		const char * mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_xpath(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_json(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_regexp(
		 const char * mpszParamName,
		 ...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_attrib(
		const char * mpszParamName,
		...);
										 
										 
										 
										 
										 
										 
										 		
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_run(
		const char * mpszCode,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_reset(void);

  int
	web_convert_date_param(
		const char * 		mpszParamName,
		...);










# 789 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/as_web.h"


# 802 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/as_web.h"



























# 840 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/as_web.h"

 
 
 


  int
	FormSubmit(
		const char *		mpszFormName,
		...);
  int
	InitWebVuser(void);
  int
	SetUser(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);
  int
	TerminateWebVuser(void);
  int
	URL(
		const char *		mpszUrlName);
























# 908 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/as_web.h"


  int
	web_rest(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 

  int
web_stream_open(
	const char *		mpszArg1,
	...
);
  int
	web_stream_wait(
		const char *		mpszArg1,
		...
	);

  int
	web_stream_close(
		const char *		mpszArg1,
		...
	);

  int
web_stream_play(
	const char *		mpszArg1,
	...
	);

  int
web_stream_pause(
	const char *		mpszArg1,
	...
	);

  int
web_stream_seek(
	const char *		mpszArg1,
	...
	);

  int
web_stream_get_param_int(
	const char*			mpszStreamID,
	const int			miStateType
	);

  double
web_stream_get_param_double(
	const char*			mpszStreamID,
	const int			miStateType
	);

  int
web_stream_get_param_string(
	const char*			mpszStreamID,
	const int			miStateType,
	const char*			mpszParameterName
	);

  int
web_stream_set_param_int(
	const char*			mpszStreamID,
	const int			miStateType,
	const int			miStateValue
	);

  int
web_stream_set_param_double(
	const char*			mpszStreamID,
	const int			miStateType,
	const double		mdfStateValue
	);

  int
web_stream_set_custom_mpd(
	const char*			mpszStreamID,
	const char*			aMpdBuf
	);

 
 
 






# 9 "C:\\Program Files (x86)\\OpenText\\LoadRunner\\include/web_api.h" 2

















 







 















  int
	web_reg_add_cookie(
		const char *		mpszCookie,
		...);							 
										 

  int
	web_report_data_point(
		const char *		mpszEventType,
		const char *		mpszEventName,
		const char *		mpszDataPointName,
		const char *		mpszLAST);	 
										 
										 
										 

  int
	web_text_link(
		const char *		mpszStepName,
		...);

  int
	web_element(
		const char *		mpszStepName,
		...);

  int
	web_image_link(
		const char *		mpszStepName,
		...);

  int
	web_static_image(
		const char *		mpszStepName,
		...);

  int
	web_image_submit(
		const char *		mpszStepName,
		...);

  int
	web_button(
		const char *		mpszStepName,
		...);

  int
	web_edit_field(
		const char *		mpszStepName,
		...);

  int
	web_radio_group(
		const char *		mpszStepName,
		...);

  int
	web_check_box(
		const char *		mpszStepName,
		...);

  int
	web_list(
		const char *		mpszStepName,
		...);

  int
	web_text_area(
		const char *		mpszStepName,
		...);

  int
	web_map_area(
		const char *		mpszStepName,
		...);

  int
	web_eval_java_script(
		const char *		mpszStepName,
		...);

  int
	web_reg_dialog(
		const char *		mpszArg1,
		...);

  int
	web_reg_cross_step_download(
		const char *		mpszArg1,
		...);

  int
	web_browser(
		const char *		mpszStepName,
		...);

  int
	web_control(
		const char *		mpszStepName,
		...);

  int
	web_set_rts_key(
		const char *		mpszArg1,
		...);

  int
	web_save_param_length(
		const char * 		mpszParamName,
		...);

  int
	web_save_timestamp_param(
		const char * 		mpszParamName,
		...);

  int
	web_load_cache(
		const char *		mpszStepName,
		...);							 
										 

  int
	web_dump_cache(
		const char *		mpszStepName,
		...);							 
										 
										 

  int
	web_reg_find_in_log(
		const char *		mpszArg1,
		...);							 
										 
										 

  int
	web_get_sockets_info(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 

  int
	web_add_cookie_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

  int
	web_hook_java_script(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

 
 
 
 
 
 
 
 
 
 
 
 
  int
	web_reg_async_attributes(
		const char *		mpszArg,
		...
	);

 
 
 
 
 
 
  int
	web_sync(
		 const char *		mpszArg1,
		 ...
	);

 
 
 
 
  int
	web_stop_async(
		const char *		mpszArg1,
		...
	);

 
 
 
 
 

 
 
 

typedef enum WEB_ASYNC_CB_RC_ENUM_T
{
	WEB_ASYNC_CB_RC_OK,				 

	WEB_ASYNC_CB_RC_ABORT_ASYNC_NOT_ERROR,
	WEB_ASYNC_CB_RC_ABORT_ASYNC_ERROR,
										 
										 
										 
										 
	WEB_ASYNC_CB_RC_ENUM_COUNT
} WEB_ASYNC_CB_RC_ENUM;

 
 
 

typedef enum WEB_CONVERS_CB_CALL_REASON_ENUM_T
{
	WEB_CONVERS_CB_CALL_REASON_BUFFER_RECEIVED,
	WEB_CONVERS_CB_CALL_REASON_END_OF_TASK,

	WEB_CONVERS_CB_CALL_REASON_ENUM_COUNT
} WEB_CONVERS_CB_CALL_REASON_ENUM;

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

typedef
int														 
	(*RequestCB_t)();

typedef
int														 
	(*ResponseBodyBufferCB_t)(
		  const char *		aLastBufferStr,
		  int				aLastBufferLen,
		  const char *		aAccumulatedStr,
		  int				aAccumulatedLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseCB_t)(
		  const char *		aResponseHeadersStr,
		  int				aResponseHeadersLen,
		  const char *		aResponseBodyStr,
		  int				aResponseBodyLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseHeadersCB_t)(
		  int				aHttpStatusCode,
		  const char *		aAccumulatedHeadersStr,
		  int				aAccumulatedHeadersLen);



 
 
 

typedef enum WEB_CONVERS_UTIL_RC_ENUM_T
{
	WEB_CONVERS_UTIL_RC_OK,
	WEB_CONVERS_UTIL_RC_CONVERS_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_TASK_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_UNAVIALABLE,
	WEB_CONVERS_UTIL_RC_INVALID_ARGUMENT,

	WEB_CONVERS_UTIL_RC_ENUM_COUNT
} WEB_CONVERS_UTIL_RC_ENUM;

 
 
 

  int					 
	web_util_set_request_url(
		  const char *		aUrlStr);

  int					 
	web_util_set_request_body(
		  const char *		aRequestBodyStr);

  int					 
	web_util_set_formatted_request_body(
		  const char *		aRequestBodyStr);

  int					 
web_util_set_request_header(
	  const char *		aRequestHeaderNameStr,
	  const char *		aRequestHeaderValueStr);

 
 
 
 
 

 
 
 
 
 

 
 
 
 
 
 
 
 

 
 
  int
web_websocket_connect(
		 const char *	mpszArg1,
		 ...
		 );


 
 
 
 
 																						
  int
web_websocket_send(
	   const char *		mpszArg1,
		...
	   );

 
 
 
 
 
 
  int
web_websocket_close(
		const char *	mpszArg1,
		...
		);

 
typedef
void														
(*OnOpen_t)(
			  const char* connectionID,  
			  const char * responseHeader,  
			  int length  
);

typedef
void														
(*OnMessage_t)(
	  const char* connectionID,  
	  int isbinary,  
	  const char * data,  
	  int length  
	);

typedef
void														
(*OnError_t)(
	  const char* connectionID,  
	  const char * message,  
	  int length  
	);

typedef
void														
(*OnClose_t)(
	  const char* connectionID,  
	  int isClosedByClient,  
	  int code,  
	  const char* reason,  
	  int length  
	 );
 
 
 
 
 





# 7 "globals.h" 2

# 1 "lrw_custom_body.h" 1



 
const char * const body_variable_1 = "BodyBinary={\"name\":\"system\",\"time\":\"2026-03-06T07:23:17.932Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":1,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_numMessages\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid"
		"\":\"0D034BBCCDD16E182AFC5E06CC216F3A\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,e"
		"xternal-stable-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R"
		"-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"eventName\":\"edgePendingContextResponses\",\"eventInfo_numMessages\":0}}\n"
		"{\"name\":\"system\",\"time\":\"2026-03-06T07:23:17.937Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":2,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_duration\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBC"
		"CDD16E182AFC5E06CC216F3A\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stabl"
		"e-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10"
		",P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"eventName\":\"TTFB\",\"eventInfo_duration\":833.8999999761581,\"eventInfo_navigationType\":\"navigate\",\"eventInfo_connectionType\":\"3g\"}}\n"
		"{\"name\":\"system\",\"time\":\"2026-03-06T07:23:17.938Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":3,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_numMessages\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034"
		"BBCCDD16E182AFC5E06CC216F3A\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-st"
		"able-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6"
		"-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"eventName\":\"edgePendingContextResponses\",\"eventInfo_numMessages\":0}}\n"
		"{\"name\":\"system\",\"time\":\"2026-03-06T07:23:17.938Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":4,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_duration\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBC"
		"CDD16E182AFC5E06CC216F3A\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stabl"
		"e-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10"
		",P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"eventName\":\"edgeMultiTabsUtilityDuration|getValidUniqueTabs\",\"eventInfo_duration\":0}}\n"
		"{\"name\":\"system\",\"time\":\"2026-03-06T07:23:17.939Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":5,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_numMessages\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034"
		"BBCCDD16E182AFC5E06CC216F3A\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-st"
		"able-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6"
		"-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"eventName\":\"edgePendingContextResponses\",\"eventInfo_numMessages\":0}}\n"
		"{\"name\":\"system\",\"time\":\"2026-03-06T07:23:17.939Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":6,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_numMessages\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034"
		"BBCCDD16E182AFC5E06CC216F3A\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-st"
		"able-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6"
		"-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"eventName\":\"edgePendingContextResponses\",\"eventInfo_numMessages\":0}}\n"
		"{\"name\":\"system\",\"time\":\"2026-03-06T07:23:17.940Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":7,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_timing\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBCCD"
		"D16E182AFC5E06CC216F3A\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-"
		"treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P"
		"-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"eventName\":\"copilotMsalInit\",\"eventInfo_initTrigger\":\"DCL\",\"eventInfo_timing\":1679.8999999761581}}\n"
		"{\"name\":\"system\",\"time\":\"2026-03-06T07:23:17.940Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":8,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_duration\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBC"
		"CDD16E182AFC5E06CC216F3A\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stabl"
		"e-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10"
		",P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"eventName\":\"edgeMultiTabsUtilityDuration|retrieveValidTabs\",\"eventInfo_duration\":328}}\n"
		"{\"name\":\"system\",\"time\":\"2026-03-06T07:23:17.941Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":9,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_duration\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBC"
		"CDD16E182AFC5E06CC216F3A\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stabl"
		"e-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10"
		",P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"eventName\":\"edgeMultiTabsUtilityDuration|retrieveLastTabs\",\"eventInfo_duration\":328.3000000715256}}\n"
		"{\"name\":\"health\",\"time\":\"2026-03-06T07:23:17.942Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":10,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_duration\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BB"
		"CCDD16E182AFC5E06CC216F3A\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stab"
		"le-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-1"
		"0,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"eventName\":\"copilotWebAuthSDKAPICall\",\"eventInfo_success\":true,\"eventInfo_apiName\":\"msal:acquireTokenStart\",\"eventInfo_duration\":0,\"eventInfo_customData\":\"{\\\\\"eventInfo_authWorkflowAccountType\\\\\":\\\\\"microsoft\\\\\",\\\\\"eventInfo_wasInBackground\\\\\":true,\\\\\"eventInfo_interactionType\\\\\":\\\\\"silent\\\\\",\\\\\"eventInfo_correlationId\\\\\":\\\\\"019cc207-6e39-7e95-8fc7-9bc75dc49e64\\\\\",\\\\\"eventInfo_redirectUri\\\\\":\\\\\"https://copilot.microsoft.com/auth/silent-callback\\\\\",\\\\\"eventInfo_cacheLookupPolicy\\\\\":0,\\\\\"eventInfo_prompt\\\\\":\\\\\"select_account\\\\\",\\\\\"eventInfo_isBrokered\\\\\":false,\\\\\"eventInfo_isPwB\\\\\":false,\\\\\"eventInfo_isNaa\\\\"
		"\":true}\"}}\n"
		"{\"name\":\"health\",\"time\":\"2026-03-06T07:23:17.942Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":11,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBCCDD16E182AFC5E06CC216F3A\",\"eventInfo_surfaceVisible\""
		":false,\"eventInfo_isCopilotMode\":true,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:951625,22f13740:1003583,ext"
		"ernalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-"
		"R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"eventName\":\"copilotWebAuthSDKAPICall\",\"eventInfo_success\":false,\"eventInfo_apiName\":\"msal:acquireTokenFailure\",\"eventInfo_customData\":\"{\\\\\"eventInfo_authWorkflowAccountType\\\\\":\\\\\"microsoft\\\\\",\\\\\"eventInfo_wasInBackground\\\\\":true,\\\\\"eventInfo_isBrokered\\\\\":false,\\\\\"eventInfo_isPwB\\\\\":false,\\\\\"eventInfo_isNaa\\\\\":true,\\\\\"eventInfo_interactionType\\\\\":\\\\\"silent\\\\\",\\\\\"eventInfo_duration\\\\\":1,\\\\\"authority\\\\\":\\\\\"https://login.microsoftonline.com/common\\\\\"}\"}}\n"
		"{\"name\":\"health\",\"time\":\"2026-03-06T07:23:17.942Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":12,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBCCDD16E182AFC5E06CC216F3A\",\"eventInfo_surfaceVisible\""
		":false,\"eventInfo_isCopilotMode\":true,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:951625,22f13740:1003583,ext"
		"ernalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-"
		"R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"eventName\":\"copilotWebAuthSDKAPICall\",\"eventInfo_success\":false,\"eventInfo_apiName\":\"msal:acquireTokenFailure\",\"eventInfo_customData\":\"{\\\\\"eventInfo_authWorkflowAccountType\\\\\":\\\\\"microsoft\\\\\",\\\\\"eventInfo_wasInBackground\\\\\":true,\\\\\"eventInfo_isBrokered\\\\\":false,\\\\\"eventInfo_isPwB\\\\\":false,\\\\\"eventInfo_isNaa\\\\\":true,\\\\\"eventInfo_interactionType\\\\\":\\\\\"silent\\\\\",\\\\\"eventInfo_subError\\\\\":null,\\\\\"eventInfo_duration\\\\\":14,\\\\\"authority\\\\\":\\\\\"https://login.microsoftonline.com/common\\\\\"}\"}}\n"
		"{\"name\":\"health\",\"time\":\"2026-03-06T07:23:17.943Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":13,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_duration\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BB"
		"CCDD16E182AFC5E06CC216F3A\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stab"
		"le-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-1"
		"0,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"eventName\":\"copilotWebAuthSDKAPICall\",\"eventInfo_success\":true,\"eventInfo_apiName\":\"msal:acquireTokenStart\",\"eventInfo_duration\":0,\"eventInfo_customData\":\"{\\\\\"eventInfo_authWorkflowAccountType\\\\\":\\\\\"microsoft\\\\\",\\\\\"eventInfo_wasInBackground\\\\\":true,\\\\\"eventInfo_interactionType\\\\\":\\\\\"silent\\\\\",\\\\\"eventInfo_correlationId\\\\\":\\\\\"019cc207-6fc3-7230-9c82-b2c3e08bedcd\\\\\",\\\\\"eventInfo_redirectUri\\\\\":\\\\\"https://copilot.microsoft.com/auth/silent-callback\\\\\",\\\\\"eventInfo_cacheLookupPolicy\\\\\":0,\\\\\"eventInfo_prompt\\\\\":\\\\\"select_account\\\\\",\\\\\"eventInfo_isBrokered\\\\\":false,\\\\\"eventInfo_isPwB\\\\\":false,\\\\\"eventInfo_isNaa\\\\"
		"\":true}\"}}\n"
		"{\"name\":\"health\",\"time\":\"2026-03-06T07:23:17.943Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":14,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBCCDD16E182AFC5E06CC216F3A\",\"eventInfo_surfaceVisible\""
		":false,\"eventInfo_isCopilotMode\":true,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:951625,22f13740:1003583,ext"
		"ernalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-"
		"R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"eventName\":\"copilotWebAuthSDKAPICall\",\"eventInfo_success\":false,\"eventInfo_apiName\":\"msal:acquireTokenFailure\",\"eventInfo_customData\":\"{\\\\\"eventInfo_authWorkflowAccountType\\\\\":\\\\\"microsoft\\\\\",\\\\\"eventInfo_wasInBackground\\\\\":true,\\\\\"eventInfo_isBrokered\\\\\":false,\\\\\"eventInfo_isPwB\\\\\":false,\\\\\"eventInfo_isNaa\\\\\":true,\\\\\"eventInfo_interactionType\\\\\":\\\\\"silent\\\\\",\\\\\"eventInfo_duration\\\\\":0,\\\\\"authority\\\\\":\\\\\"https://login.microsoftonline.com/common\\\\\"}\"}}\n"
		"{\"name\":\"health\",\"time\":\"2026-03-06T07:23:17.943Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":15,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBCCDD16E182AFC5E06CC216F3A\",\"eventInfo_surfaceVisible\""
		":false,\"eventInfo_isCopilotMode\":true,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:951625,22f13740:1003583,ext"
		"ernalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-"
		"R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"eventName\":\"copilotWebAuthSDKAPICall\",\"eventInfo_success\":false,\"eventInfo_apiName\":\"msal:acquireTokenFailure\",\"eventInfo_customData\":\"{\\\\\"eventInfo_authWorkflowAccountType\\\\\":\\\\\"microsoft\\\\\",\\\\\"eventInfo_wasInBackground\\\\\":true,\\\\\"eventInfo_isBrokered\\\\\":false,\\\\\"eventInfo_isPwB\\\\\":false,\\\\\"eventInfo_isNaa\\\\\":true,\\\\\"eventInfo_interactionType\\\\\":\\\\\"silent\\\\\",\\\\\"eventInfo_subError\\\\\":null,\\\\\"eventInfo_duration\\\\\":6,\\\\\"authority\\\\\":\\\\\"https://login.microsoftonline.com/common\\\\\"}\"}}\n"
		"{\"name\":\"health\",\"time\":\"2026-03-06T07:23:17.943Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":16,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_duration\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BB"
		"CCDD16E182AFC5E06CC216F3A\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stab"
		"le-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-1"
		"0,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"eventName\":\"copilotWebAuthSDKAPICall\",\"eventInfo_success\":true,\"eventInfo_apiName\":\"msal:acquireTokenStart\",\"eventInfo_duration\":0,\"eventInfo_customData\":\"{\\\\\"eventInfo_authWorkflowAccountType\\\\\":\\\\\"microsoft\\\\\",\\\\\"eventInfo_wasInBackground\\\\\":true,\\\\\"eventInfo_interactionType\\\\\":\\\\\"silent\\\\\",\\\\\"eventInfo_correlationId\\\\\":\\\\\"019cc207-73b0-76b8-875e-577dda8eac7e\\\\\",\\\\\"eventInfo_redirectUri\\\\\":\\\\\"https://copilot.microsoft.com/auth/silent-callback\\\\\",\\\\\"eventInfo_cacheLookupPolicy\\\\\":0,\\\\\"eventInfo_prompt\\\\\":\\\\\"select_account\\\\\",\\\\\"eventInfo_isBrokered\\\\\":false,\\\\\"eventInfo_isPwB\\\\\":false,\\\\\"eventInfo_isNaa\\\\"
		"\":true}\"}}\n"
		"{\"name\":\"health\",\"time\":\"2026-03-06T07:23:17.944Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":17,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBCCDD16E182AFC5E06CC216F3A\",\"eventInfo_surfaceVisible\""
		":false,\"eventInfo_isCopilotMode\":true,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:951625,22f13740:1003583,ext"
		"ernalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-"
		"R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"eventName\":\"copilotWebAuthSDKAPICall\",\"eventInfo_success\":false,\"eventInfo_apiName\":\"msal:acquireTokenFailure\",\"eventInfo_customData\":\"{\\\\\"eventInfo_authWorkflowAccountType\\\\\":\\\\\"microsoft\\\\\",\\\\\"eventInfo_wasInBackground\\\\\":true,\\\\\"eventInfo_isBrokered\\\\\":false,\\\\\"eventInfo_isPwB\\\\\":false,\\\\\"eventInfo_isNaa\\\\\":true,\\\\\"eventInfo_interactionType\\\\\":\\\\\"silent\\\\\",\\\\\"eventInfo_duration\\\\\":1,\\\\\"authority\\\\\":\\\\\"https://login.microsoftonline.com/common\\\\\"}\"}}\n"
		"{\"name\":\"health\",\"time\":\"2026-03-06T07:23:17.944Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":18,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBCCDD16E182AFC5E06CC216F3A\",\"eventInfo_surfaceVisible\""
		":false,\"eventInfo_isCopilotMode\":true,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:951625,22f13740:1003583,ext"
		"ernalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-"
		"R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"eventName\":\"copilotWebAuthSDKAPICall\",\"eventInfo_success\":false,\"eventInfo_apiName\":\"msal:acquireTokenFailure\",\"eventInfo_customData\":\"{\\\\\"eventInfo_authWorkflowAccountType\\\\\":\\\\\"microsoft\\\\\",\\\\\"eventInfo_wasInBackground\\\\\":true,\\\\\"eventInfo_isBrokered\\\\\":false,\\\\\"eventInfo_isPwB\\\\\":false,\\\\\"eventInfo_isNaa\\\\\":true,\\\\\"eventInfo_interactionType\\\\\":\\\\\"silent\\\\\",\\\\\"eventInfo_subError\\\\\":null,\\\\\"eventInfo_duration\\\\\":7,\\\\\"authority\\\\\":\\\\\"https://login.microsoftonline.com/common\\\\\"}\"}}\n"
		"{\"name\":\"health\",\"time\":\"2026-03-06T07:23:17.944Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":19,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBCCDD16E182AFC5E06CC216F3A\",\"eventInfo_surfaceVisible\""
		":false,\"eventInfo_isCopilotMode\":true,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:951625,22f13740:1003583,ext"
		"ernalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-"
		"R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"eventName\":\"copilotWebAuthSDKAPICall\",\"eventInfo_success\":false,\"eventInfo_apiName\":\"msal:acquireTokenOverallFailure\",\"eventInfo_errorType\":\"ClientAuthError\",\"eventInfo_errorMessage\":\"no_account_found: No account found in cache for given key.\",\"eventInfo_customData\":\"{\\\\\"eventInfo_authWorkflowAccountType\\\\\":\\\\\"microsoft\\\\\",\\\\\"eventInfo_wasInBackground\\\\\":true,\\\\\"eventInfo_requestType\\\\\":\\\\\"login\\\\\",\\\\\"eventInfo_retryAttemptCount\\\\\":3,\\\\\"eventInfo_retryStartTime\\\\\":14722.199999928474,\\\\\"eventInfo_retryEndDelay\\\\\":16128.099999904633,\\\\\"eventInfo_retryDelayTimings\\\\\":\\\\\"377,997.2999999523163\\\\\",\\\\\"eventInfo_allErrors\\\\\":\\\\\"[{\\\\\\\\\\\\\"errorType\\\\\\\\\\\\\":\\\\\\\\\\\\\"C"
		"lientAuthError\\\\\\\\\\\\\",\\\\\\\\\\\\\"errorMessage\\\\\\\\\\\\\":\\\\\\\\\\\\\"no_account_found: No account found in cache for given key.\\\\\\\\\\\\\"},{\\\\\\\\\\\\\"errorType\\\\\\\\\\\\\":\\\\\\\\\\\\\"ClientAuthError\\\\\\\\\\\\\",\\\\\\\\\\\\\"errorMessage\\\\\\\\\\\\\":\\\\\\\\\\\\\"no_account_found: No account found in cache for given key.\\\\\\\\\\\\\"},{\\\\\\\\\\\\\"errorType\\\\\\\\\\\\\":\\\\\\\\\\\\\"ClientAuthError\\\\\\\\\\\\\",\\\\\\\\\\\\\"errorMessage\\\\\\\\\\\\\":\\\\\\\\\\\\\"no_account_found: No account found in cache for given key.\\\\\\\\\\\\\"}]\\\\\",\\\\\"eventInfo_redirectUri\\\\\":\\\\\"https://copilot.microsoft.com/auth/silent-callback\\\\\",\\\\\"eventInfo_interactionType\\\\\":\\\\\"silent\\\\\",\\\\\"eventInfo_exitReason\\\\\":\\\\\"maxRetriesReached\\\\\"}\"}}\n"
		"{\"name\":\"apiresponse\",\"time\":\"2026-03-06T07:23:17.970Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":20,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_status\":{\"t\":6},\"eventInfo_duration\":{\"t\":6},\"eventInfo_responseContentLength\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edg"
		"etab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBCCDD16E182AFC5E06CC216F3A\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartn"
		"er:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-104991"
		"8-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"eventName\":\"copilotApiResponse\",\"eventInfo_path\":\"/start\",\"eventInfo_method\":\"POST\",\"eventInfo_status\":200,\"eventInfo_duration\":3735.6999999284744,\"eventInfo_responseContentLength\":13397,\"eventInfo_xCDNTraceId\":\"9d7f9d40db0b6ce0-MAA\",\"eventInfo_server\":\"cloudflare\"}}\n"
		"{\"name\":\"system\",\"time\":\"2026-03-06T07:23:18.029Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":21,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_numMessages\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D03"
		"4BBCCDD16E182AFC5E06CC216F3A\",\"userFlightIds\":\"imagegenv3,assistant-enable-answer-cards,voice-spatial,weather-cards,edgviswebground,enable-all-app-actions,promptedreasoningcombinedwithsearchpatch,promptmessagewithcards,voices78,allowanonymoususershare,share-chat-page-entry,039add1b-use-fixed-chat-layout,share-image-link,dailybriefing,pages-table,always-show-last-reaction-v2,azureconfigregexblocklist,disable-cmc-auto-reload,onedrive,suggesthangup,correct-personalization-accidental-opt-out,share-campaign,039add1b-chat-sessions-drawer,039add1b-pages-drawer,injectselfharminstructions,039add1b-refresh-token-worker,account-change-chat-reset,preload-chat-messages,1s-moc-logosize,quiz-card-suggestion,send-connected,anonymousattachmentupload,async-disclaimer-text,mem-generate-post-turn,sharecontinue,share-campaign-taeb9y,share-campaign-krq0kf,dr-editprompt-mobile,039add1b-animated-greeting-message-view,greeting-message-animation,image-fallback-thumbnail,adsidsync,think-deeper-regenerate,smart-mode-flightd-edge,n"
		"arr-icachuse,img-followup-patch,inject-user-greeting,code-edge-c,videoserp5,searchvideos-bing-fallback,searchimages-bing-fallback,edge-responding-loop-harmony-4o-1010,pay-instacart-canada,quiz-in-create-drawer,deep-research-export-file,m365-conversation-sync,deep-research-export-podcast,multiple,originaldocumentupload,web-multi-fallback-languages,share-campaign-evhqea,share-campaign-rbsrqk,share-campaign-tkzuae,share-campaign-jowp8z,share-campaign-gxcdu3,share-campaign-d2e0f5,share-campaign-dkmev6,share-campaign-coqva4,share-campaign-gez3vb,remove-extra-im-start-context,vision-in-composer-v3,deep-research-nano,export-pages-t,copilot-beta,smart-mode-default-rl,039add1b-uikit-paragraph-view,imagegenv3peakhour,onedrive-fetch,share-continue-v2,ts-dynamic-top-section-t,creator-gallery,old-search-config,thinkdeepero4minichainofthought,image-library-2,image-library-delete-image,igszcls,searchimages-cache,searchvideos-cache,pay-consistent-buy,finance-tooltip-v2,m365-pills-custom,copilot-beta-automatic-opt-in,deep-r"
		"esearch,quiz-option-shuffle,image-cards-v2,test-srm-aa-4,deep-research-promo-card,recipe-card,finance-watchlist-v2,finance-crypto,mutesuggestions,pages-link-navigation,pages-skip-page-selector,pages-file-upload,pages-suggested-followups,onedrive-graph,rm-relatedqna,dr-web-upd-w,dr-pro-nano,pay-getbuyoption-migration,pay-getrecipe-migration,pay-price-tracked,pay-shopify-checkout,sports-cards,smart-mode-reason-chat,pages-reasoning-gg,edge-autosuggest,composer-v4,039add1b-sentry-hang-rate-v2,voice-improved-courtesy-wait,quiz-harmony,sticky-conversation-mode,smart-mode-ensemble-switcher,t1_tsrv3_router,title-generation-harmony,pay-conversion-tracking,history-truncation-fix-parent,backstoryinsertall,local-cards,smart-mode-with-hapi,optimized-responding-for-cache,clarity-http-endpoint,share-image-continue,sharemanagement,labs-audio-expression-style-list-layout,nosearchimageonattachment,start-retry,ui-kit-paragraph-view-2,m365-cela-sheet,placecardprompclean-v3,title-generation-v2,eea-personalization-waiting-period"
		",useggvisionmodel,study-mode,searchimages-safe,searchvideos-safe,edge-reload-tab,attachment-suggestions-c,vision-biometric-consent,page-title-generation-v2,kill-picasso-id-on-start,zircon-flight-t,browser-actions-09092025,share-campaign-ferk5z,search-pcm,detailedpromptmetrics,file-upload-config,sidebar-settings,placecard-enhance-all,n-30-k-20,pay-ams-treatment,ceo-harmony,finance-chart-clickthrough,labs-audio-expression-scripted-mode,labs-audio-expression-mode-coachmark,labs-audio-expression-story-voice-selector,thinkdeeper5reasoningloweffort,page-title-generation-hapi,skip-preview-event,m365-pills-data-v2,labs-audio-expression-auto-style,edgevision-multitab,flash-cards,finance-earnings,page-safety-check-treatment,analyzedocuments-extendedtokens,labs-audio-expression-preset-card-fixed,lazy-with-retry,sorttoolrouterresult-others-t,character-cognitive-testing-service,voice-flower-bg,thinkdeeper5miniloweffortchainofthought,image-dynamic-width,group-conversations,share-to-invite,deep-research-share-link,cot-out"
		"put-panel,imagegen-galleryremixquota,place-near-me-fix,related-results-t1,tru-router,pay-migrate-get-checkout-option-v2,voice-safety-patch,uselongcontextmodel,kill-regenerate,speechtranscribev2,browser-automation-inc-max-loop,thinkdeeper-truncator,search-truncation,backstory-trim,suppress-inline-link-nav-dialog,voice-time-formatting,balancedfiletokens,empty-tool-instruction,think-deeper-move-tool-instructions,heycopilot-backstory,vad-buffer,pay-edge-clarity,dr-progress,labs-audio-expression-story-image,remix-suggestions,ceo-remove-search-web,healthcare-safety-patch-v3,person-card,edge-safety-prompt-treatment,share-conversation-with-attachments,image-upload-mmt,dr-summary,cross-selling-t-gpt52,ceo-optimized-loop,podcast-in-voice,track-oldest-merged-message,mem-clean-forget,url-output-sanitization,gpt5-reasoning-harmony-personality-v1,config-responder-option-by-modelname,responding-loop-for-vision-model,reduce-vision-usage,dynamic-answer-cards-ga,dr-outlinks,quiz-instant-feedback,gpt-5-on-quick-mode,safety-mi"
		"ddleware,ceo-filedownload,hide-feedback-if-no-mic-permission-on-end-call,auth-assertion,connector-consent-v2,existing-teen-enabled,voice-clear-audio-capture-listeners-on-end,dr-shared-orchestrator,memory-settings-v2,election-patch,pagecreation,add-utm-source,warnings-indepth,model-migration,route-chat-to-agent,browser-automation-instruction-gpt5,group-conversations-lazy-creation,reduce-memory-overtriggering,image-model-selector-summary,utm-tracking-use-copilot-com,checkmark-emoji-fix,groupchatnotifications,upfront-persistence,groupchat-mentions,edu-cross-sell,browser-actions-charapita,contextual-suggestions,subs-redirect-to-cmc,cef,voice-new-feedback-string,reject-tier4-start-traffic,time-patch,challenge-asn,min-adaptive-citation-t-nav,cloudflare-challenge,chat-recovery-long-streaming-timeout,enable-audio-capture-worklet,voice-memory-edf,reuse-audio-context-for-voice-output,enable-audio-out-pre-buffering-c,socket-close-track,local-inference-client-side-lb,auth0-based-user-link,knowledge-extraction-harmony,r"
		"outer-default-preload-intent,hide-conversation-dates,remove-qr,edge-shopping-enable-all-markets,deprecate_widgets_v1,edge-page-sanitization,teen-compliance,edge-ctx-consent-tool-executing,skip-reasoning-in-smart-mode,chat-client-retry,labs-remote-config,voice-name-repetition-fix,ltm-backfill-disabled,skip-append-last-user-message-again,framework-conversation-write,email-reply,voice-enable-new-audio-icon-c,backstorytool,block-image-generation-in-voice,increase-doc-attachment-max-tokens,nav-expand-all-t,remove-clarifying-prompts,readaloud-verbatim-prompt,kill-contextual-suggestions-tabs-check,podcast-project-sources-grounding,edf-store-direct-instruction,naa-has-active-account-check,computeruse-raw-cot,reduce-memory-overtrigger-location-c,search-uploaded-docs-in-project,mem-skip-preview-search,genuiskillssmallf12,searchmode-t2,browser-actions-detailed-summary,generate-flashcard-skill,browser-actions-deprecated-non-charapita,proactive-message-additional-context,searchfinance-searchquery,group-conversations-reu"
		"se-conv-id,voice-enable-read-aloud-c,edge-text-vision-treatment,max-adaptive-citations-c,user-message-copy,match-message-timestamp,edge-tab-safety-cache,voice-telemetry,m365-wxp-history-sync,kill-shopping-homepage-t,nav-card-short-url,kill-projects-creations-flash-card,computer-agent-skills,browser-remote-actions-for-tasks,conversation-compactor,planning-agent-elicitation,spd-citation-v2-mixed-format,agent-snapshots,group-conversations-unread-indicator,gpt52-reasoning-harmony,superbowl-search,autoprompt-off,earcon-only-after-first-use,voice-restart-telemetry,subs-hot-reload,jailbreakdisabled,pdp-track-price-comp-t,olympics-search,supersonic-task-preview,edf-memory-tuning,task-memory,trs-update-flight,block-document-generation-in-voice,task-notification,shopping-journeys-v2-container,shopping-feed-no-hero-image-t,fix-ftr,discovery-long-summary,avoid-edge-vision-highlight,agent-manager-registry,dicf6867,audioagent-v3,lm-arena-v2,windows-vision-highlights,journeys-generation-v2-t,shopping-jump-back-to-conversa"
		"tion-c,studio-sdk,sdk-ai-message-item,sidebar-vnext,chat-session-affinity,ltm-responding-prompt-tuning-c,topic_continuation_enabled_twice_per_week,trvlflghttf,vertex-timeout,shopping-user-memory-t,fetch-convo,shadowban,update-edge-eu-user-consent-text,genui-tier3-c,genui-ground-counterfactual,discovery-harmony-timestamp,mai-whisper-language-c,gpt51-group-chat,genui-tier4-ground-flight-c,task-notification-no-timeout,shopping-journeys-v2-container-read-c,getcameraimages,web-30s-ping,v3-courteous-wait-c,shopping-feed-thumbs-feedback-toast,conversation-search-region-routing-control,edge-dont-language-switch,upsell-selector,model-training-new-privacy,voice-spatial-info,chainofthoughteventprocessor,chat-message-preview,handle-preview-event,kill-composer-creation-button,smart-mode,smart-mode-6e0b4c6f,smart-mode-cot,smart-mode-flightc,smart-mode-v2-config,searchvideos,searchvideos-google,serpvideocard,video-cards-v2,videocardrespondinginstruction,edge-responder-loop,emit-all-inference-telemetry,responderactions-all"
		",responding-harmony-4o-v4,multi-file-upload,multiple-file-upload,unlimitedfilereasoning,grounded-edit,page-citation,pages-footnote,gpt5-calcite,responding-harmony-gpt5-v1,smart-mode-default,tool-defs-on-separate-system-message,1s-moc-keep-facets,1s-moc-more-msn,1s-wpo-dis-dnewsr,1s-wpo-dis-nopod,discover-gemfive,discover-more-news-content,discover-news-all-large-cards,discover-newsts,discover-threets,think-deeper-cot,finance-follow,finance-watchlist-ui,prg-cmc-flws,prg-cmc-fnav,improve-context-precision,ds-editprompt,ds-new-progress,smart-mode-gpt5,actionspacereducerv2,longqueryfilter,tsrv3_router,enable-history-cache-write,truncatekmessages,responding-harmony-gpt-5-nosearch,responding-harmony-gpt-5-search,placecardnavigationenabled,placecardpromptoptimizationenabled,switcher-harmony,browser-actions,browserautomationcomputeruse,browserautomationsearchweb,edgeactiondisableouter,morefileupload,sidebar-compact-nav-items,sidebar-narrow,searchplaces-enhanced-infos,searchplaces-enhanced-photos,truncatekmessages-k"
		"20,truncatekmessages-n30,pay-ams-integration-server,pay-ams-pdp,pay-ams-price-tracking,pay-ams-product-card,edge-page-safety-check,pii-scrubber,sorttoolrouterresult,relatedresults-android,relatedresults-ios,rrcitationv2,searchmode,see-more-results,toolspacereducerclassifierflight,searchweb-page3,searchweb-sd1000,searchweb-shorter,voice-search-timezone,enrich-web-grounding-with-linkedin-api,entity-info,linkedin-url,person-card-prefer-linkedin,person-cards,edge-security-template,image-ocr-hapi,merge-user-messages,deep-research-summary-v3,dr-cover-image,action-result-relaxed-json-escaping,bingify-sanitized-urls,urls-extracted-infer-event,gpt5-reasoning-harmony,thinkdeeper-gpt5reasoning-harmony-personality,dynamic-answer-cards,indepth-comparison-and-details,warnings-and-clarifications,edu-discovery-cross-sell,study-mode-mico-quiz-tutor,citation-v2,citation-v2-cards,citation-v2-nav,inline-image,inline-video,inline-video-moments,adaptive-citations,adaptive-citations-navigation,pinned-conversation,dynamic-card-sel"
		"ection-instructions,nav-all-turns,nav-cards-on-all-modes,nav-hostqcscore-filter,navigation-curated-enabled,navigation-curation-gpt4o,skip-nav-classifier,generativeui-mvpt3,genui-fiximage,genui-fiximage-12,genui-json-validator,genui-mvp,genui-preturn-refactor,genui-skills,genui-skills-small,genuimvp,searchmode-gpt51-chat-harmony,searchmode-gpt51-promptv2,edge-copilot-screenshot,edge-text-vision,kill-shopping-homepage,shopping-pdp-hide-price-history,shopping-pdp-price-tracking-fallback,sorttoolsbyfrequencyflight,shopping-feed-no-hero-image,shopping-journey-staged-orchestrator,shopping-journeys-debounce,shopping-limit-concurrency,flight-booking-skill,shopping-user-memory,generativeui-flight-status,generativeui-local-events,generativeui-prayer-vertical-timeline,generativeui-sunrise-v2,genui-core,genui-counterfactual,genui-ground-t,genui-grounding-template-selector,genui-tier2-grounding-templates,genui-turncache-templates\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"isNewUser\":false,"
		"\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:"
		"969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306"
		"-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"AppInfo_Version\":\"145.0.3800.82\",\"eventName\":\"edgePendingContextResponses\",\"eventInfo_numMessages\":0}}\n"
		"{\"name\":\"system\",\"time\":\"2026-03-06T07:23:18.148Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":22,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_numMessages\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D03"
		"4BBCCDD16E182AFC5E06CC216F3A\",\"userFlightIds\":\"imagegenv3,assistant-enable-answer-cards,voice-spatial,weather-cards,edgviswebground,enable-all-app-actions,promptedreasoningcombinedwithsearchpatch,promptmessagewithcards,voices78,allowanonymoususershare,share-chat-page-entry,039add1b-use-fixed-chat-layout,share-image-link,dailybriefing,pages-table,always-show-last-reaction-v2,azureconfigregexblocklist,disable-cmc-auto-reload,onedrive,suggesthangup,correct-personalization-accidental-opt-out,share-campaign,039add1b-chat-sessions-drawer,039add1b-pages-drawer,injectselfharminstructions,039add1b-refresh-token-worker,account-change-chat-reset,preload-chat-messages,1s-moc-logosize,quiz-card-suggestion,send-connected,anonymousattachmentupload,async-disclaimer-text,mem-generate-post-turn,sharecontinue,share-campaign-taeb9y,share-campaign-krq0kf,dr-editprompt-mobile,039add1b-animated-greeting-message-view,greeting-message-animation,image-fallback-thumbnail,adsidsync,think-deeper-regenerate,smart-mode-flightd-edge,n"
		"arr-icachuse,img-followup-patch,inject-user-greeting,code-edge-c,videoserp5,searchvideos-bing-fallback,searchimages-bing-fallback,edge-responding-loop-harmony-4o-1010,pay-instacart-canada,quiz-in-create-drawer,deep-research-export-file,m365-conversation-sync,deep-research-export-podcast,multiple,originaldocumentupload,web-multi-fallback-languages,share-campaign-evhqea,share-campaign-rbsrqk,share-campaign-tkzuae,share-campaign-jowp8z,share-campaign-gxcdu3,share-campaign-d2e0f5,share-campaign-dkmev6,share-campaign-coqva4,share-campaign-gez3vb,remove-extra-im-start-context,vision-in-composer-v3,deep-research-nano,export-pages-t,copilot-beta,smart-mode-default-rl,039add1b-uikit-paragraph-view,imagegenv3peakhour,onedrive-fetch,share-continue-v2,ts-dynamic-top-section-t,creator-gallery,old-search-config,thinkdeepero4minichainofthought,image-library-2,image-library-delete-image,igszcls,searchimages-cache,searchvideos-cache,pay-consistent-buy,finance-tooltip-v2,m365-pills-custom,copilot-beta-automatic-opt-in,deep-r"
		"esearch,quiz-option-shuffle,image-cards-v2,test-srm-aa-4,deep-research-promo-card,recipe-card,finance-watchlist-v2,finance-crypto,mutesuggestions,pages-link-navigation,pages-skip-page-selector,pages-file-upload,pages-suggested-followups,onedrive-graph,rm-relatedqna,dr-web-upd-w,dr-pro-nano,pay-getbuyoption-migration,pay-getrecipe-migration,pay-price-tracked,pay-shopify-checkout,sports-cards,smart-mode-reason-chat,pages-reasoning-gg,edge-autosuggest,composer-v4,039add1b-sentry-hang-rate-v2,voice-improved-courtesy-wait,quiz-harmony,sticky-conversation-mode,smart-mode-ensemble-switcher,t1_tsrv3_router,title-generation-harmony,pay-conversion-tracking,history-truncation-fix-parent,backstoryinsertall,local-cards,smart-mode-with-hapi,optimized-responding-for-cache,clarity-http-endpoint,share-image-continue,sharemanagement,labs-audio-expression-style-list-layout,nosearchimageonattachment,start-retry,ui-kit-paragraph-view-2,m365-cela-sheet,placecardprompclean-v3,title-generation-v2,eea-personalization-waiting-period"
		",useggvisionmodel,study-mode,searchimages-safe,searchvideos-safe,edge-reload-tab,attachment-suggestions-c,vision-biometric-consent,page-title-generation-v2,kill-picasso-id-on-start,zircon-flight-t,browser-actions-09092025,share-campaign-ferk5z,search-pcm,detailedpromptmetrics,file-upload-config,sidebar-settings,placecard-enhance-all,n-30-k-20,pay-ams-treatment,ceo-harmony,finance-chart-clickthrough,labs-audio-expression-scripted-mode,labs-audio-expression-mode-coachmark,labs-audio-expression-story-voice-selector,thinkdeeper5reasoningloweffort,page-title-generation-hapi,skip-preview-event,m365-pills-data-v2,labs-audio-expression-auto-style,edgevision-multitab,flash-cards,finance-earnings,page-safety-check-treatment,analyzedocuments-extendedtokens,labs-audio-expression-preset-card-fixed,lazy-with-retry,sorttoolrouterresult-others-t,character-cognitive-testing-service,voice-flower-bg,thinkdeeper5miniloweffortchainofthought,image-dynamic-width,group-conversations,share-to-invite,deep-research-share-link,cot-out"
		"put-panel,imagegen-galleryremixquota,place-near-me-fix,related-results-t1,tru-router,pay-migrate-get-checkout-option-v2,voice-safety-patch,uselongcontextmodel,kill-regenerate,speechtranscribev2,browser-automation-inc-max-loop,thinkdeeper-truncator,search-truncation,backstory-trim,suppress-inline-link-nav-dialog,voice-time-formatting,balancedfiletokens,empty-tool-instruction,think-deeper-move-tool-instructions,heycopilot-backstory,vad-buffer,pay-edge-clarity,dr-progress,labs-audio-expression-story-image,remix-suggestions,ceo-remove-search-web,healthcare-safety-patch-v3,person-card,edge-safety-prompt-treatment,share-conversation-with-attachments,image-upload-mmt,dr-summary,cross-selling-t-gpt52,ceo-optimized-loop,podcast-in-voice,track-oldest-merged-message,mem-clean-forget,url-output-sanitization,gpt5-reasoning-harmony-personality-v1,config-responder-option-by-modelname,responding-loop-for-vision-model,reduce-vision-usage,dynamic-answer-cards-ga,dr-outlinks,quiz-instant-feedback,gpt-5-on-quick-mode,safety-mi"
		"ddleware,ceo-filedownload,hide-feedback-if-no-mic-permission-on-end-call,auth-assertion,connector-consent-v2,existing-teen-enabled,voice-clear-audio-capture-listeners-on-end,dr-shared-orchestrator,memory-settings-v2,election-patch,pagecreation,add-utm-source,warnings-indepth,model-migration,route-chat-to-agent,browser-automation-instruction-gpt5,group-conversations-lazy-creation,reduce-memory-overtriggering,image-model-selector-summary,utm-tracking-use-copilot-com,checkmark-emoji-fix,groupchatnotifications,upfront-persistence,groupchat-mentions,edu-cross-sell,browser-actions-charapita,contextual-suggestions,subs-redirect-to-cmc,cef,voice-new-feedback-string,reject-tier4-start-traffic,time-patch,challenge-asn,min-adaptive-citation-t-nav,cloudflare-challenge,chat-recovery-long-streaming-timeout,enable-audio-capture-worklet,voice-memory-edf,reuse-audio-context-for-voice-output,enable-audio-out-pre-buffering-c,socket-close-track,local-inference-client-side-lb,auth0-based-user-link,knowledge-extraction-harmony,r"
		"outer-default-preload-intent,hide-conversation-dates,remove-qr,edge-shopping-enable-all-markets,deprecate_widgets_v1,edge-page-sanitization,teen-compliance,edge-ctx-consent-tool-executing,skip-reasoning-in-smart-mode,chat-client-retry,labs-remote-config,voice-name-repetition-fix,ltm-backfill-disabled,skip-append-last-user-message-again,framework-conversation-write,email-reply,voice-enable-new-audio-icon-c,backstorytool,block-image-generation-in-voice,increase-doc-attachment-max-tokens,nav-expand-all-t,remove-clarifying-prompts,readaloud-verbatim-prompt,kill-contextual-suggestions-tabs-check,podcast-project-sources-grounding,edf-store-direct-instruction,naa-has-active-account-check,computeruse-raw-cot,reduce-memory-overtrigger-location-c,search-uploaded-docs-in-project,mem-skip-preview-search,genuiskillssmallf12,searchmode-t2,browser-actions-detailed-summary,generate-flashcard-skill,browser-actions-deprecated-non-charapita,proactive-message-additional-context,searchfinance-searchquery,group-conversations-reu"
		"se-conv-id,voice-enable-read-aloud-c,edge-text-vision-treatment,max-adaptive-citations-c,user-message-copy,match-message-timestamp,edge-tab-safety-cache,voice-telemetry,m365-wxp-history-sync,kill-shopping-homepage-t,nav-card-short-url,kill-projects-creations-flash-card,computer-agent-skills,browser-remote-actions-for-tasks,conversation-compactor,planning-agent-elicitation,spd-citation-v2-mixed-format,agent-snapshots,group-conversations-unread-indicator,gpt52-reasoning-harmony,superbowl-search,autoprompt-off,earcon-only-after-first-use,voice-restart-telemetry,subs-hot-reload,jailbreakdisabled,pdp-track-price-comp-t,olympics-search,supersonic-task-preview,edf-memory-tuning,task-memory,trs-update-flight,block-document-generation-in-voice,task-notification,shopping-journeys-v2-container,shopping-feed-no-hero-image-t,fix-ftr,discovery-long-summary,avoid-edge-vision-highlight,agent-manager-registry,dicf6867,audioagent-v3,lm-arena-v2,windows-vision-highlights,journeys-generation-v2-t,shopping-jump-back-to-conversa"
		"tion-c,studio-sdk,sdk-ai-message-item,sidebar-vnext,chat-session-affinity,ltm-responding-prompt-tuning-c,topic_continuation_enabled_twice_per_week,trvlflghttf,vertex-timeout,shopping-user-memory-t,fetch-convo,shadowban,update-edge-eu-user-consent-text,genui-tier3-c,genui-ground-counterfactual,discovery-harmony-timestamp,mai-whisper-language-c,gpt51-group-chat,genui-tier4-ground-flight-c,task-notification-no-timeout,shopping-journeys-v2-container-read-c,getcameraimages,web-30s-ping,v3-courteous-wait-c,shopping-feed-thumbs-feedback-toast,conversation-search-region-routing-control,edge-dont-language-switch,upsell-selector,model-training-new-privacy,voice-spatial-info,chainofthoughteventprocessor,chat-message-preview,handle-preview-event,kill-composer-creation-button,smart-mode,smart-mode-6e0b4c6f,smart-mode-cot,smart-mode-flightc,smart-mode-v2-config,searchvideos,searchvideos-google,serpvideocard,video-cards-v2,videocardrespondinginstruction,edge-responder-loop,emit-all-inference-telemetry,responderactions-all"
		",responding-harmony-4o-v4,multi-file-upload,multiple-file-upload,unlimitedfilereasoning,grounded-edit,page-citation,pages-footnote,gpt5-calcite,responding-harmony-gpt5-v1,smart-mode-default,tool-defs-on-separate-system-message,1s-moc-keep-facets,1s-moc-more-msn,1s-wpo-dis-dnewsr,1s-wpo-dis-nopod,discover-gemfive,discover-more-news-content,discover-news-all-large-cards,discover-newsts,discover-threets,think-deeper-cot,finance-follow,finance-watchlist-ui,prg-cmc-flws,prg-cmc-fnav,improve-context-precision,ds-editprompt,ds-new-progress,smart-mode-gpt5,actionspacereducerv2,longqueryfilter,tsrv3_router,enable-history-cache-write,truncatekmessages,responding-harmony-gpt-5-nosearch,responding-harmony-gpt-5-search,placecardnavigationenabled,placecardpromptoptimizationenabled,switcher-harmony,browser-actions,browserautomationcomputeruse,browserautomationsearchweb,edgeactiondisableouter,morefileupload,sidebar-compact-nav-items,sidebar-narrow,searchplaces-enhanced-infos,searchplaces-enhanced-photos,truncatekmessages-k"
		"20,truncatekmessages-n30,pay-ams-integration-server,pay-ams-pdp,pay-ams-price-tracking,pay-ams-product-card,edge-page-safety-check,pii-scrubber,sorttoolrouterresult,relatedresults-android,relatedresults-ios,rrcitationv2,searchmode,see-more-results,toolspacereducerclassifierflight,searchweb-page3,searchweb-sd1000,searchweb-shorter,voice-search-timezone,enrich-web-grounding-with-linkedin-api,entity-info,linkedin-url,person-card-prefer-linkedin,person-cards,edge-security-template,image-ocr-hapi,merge-user-messages,deep-research-summary-v3,dr-cover-image,action-result-relaxed-json-escaping,bingify-sanitized-urls,urls-extracted-infer-event,gpt5-reasoning-harmony,thinkdeeper-gpt5reasoning-harmony-personality,dynamic-answer-cards,indepth-comparison-and-details,warnings-and-clarifications,edu-discovery-cross-sell,study-mode-mico-quiz-tutor,citation-v2,citation-v2-cards,citation-v2-nav,inline-image,inline-video,inline-video-moments,adaptive-citations,adaptive-citations-navigation,pinned-conversation,dynamic-card-sel"
		"ection-instructions,nav-all-turns,nav-cards-on-all-modes,nav-hostqcscore-filter,navigation-curated-enabled,navigation-curation-gpt4o,skip-nav-classifier,generativeui-mvpt3,genui-fiximage,genui-fiximage-12,genui-json-validator,genui-mvp,genui-preturn-refactor,genui-skills,genui-skills-small,genuimvp,searchmode-gpt51-chat-harmony,searchmode-gpt51-promptv2,edge-copilot-screenshot,edge-text-vision,kill-shopping-homepage,shopping-pdp-hide-price-history,shopping-pdp-price-tracking-fallback,sorttoolsbyfrequencyflight,shopping-feed-no-hero-image,shopping-journey-staged-orchestrator,shopping-journeys-debounce,shopping-limit-concurrency,flight-booking-skill,shopping-user-memory,generativeui-flight-status,generativeui-local-events,generativeui-prayer-vertical-timeline,generativeui-sunrise-v2,genui-core,genui-counterfactual,genui-ground-t,genui-grounding-template-selector,genui-tier2-grounding-templates,genui-turncache-templates\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"isNewUser\":false,"
		"\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:"
		"969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306"
		"-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"AppInfo_Version\":\"145.0.3800.82\",\"eventName\":\"edgePendingContextResponses\",\"eventInfo_numMessages\":0}}\n"
		"{\"name\":\"system\",\"time\":\"2026-03-06T07:23:18.149Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":23,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBCCDD16E182AFC5E06CC216F3A\",\"userFlightIds\":\"imagegen"
		"v3,assistant-enable-answer-cards,voice-spatial,weather-cards,edgviswebground,enable-all-app-actions,promptedreasoningcombinedwithsearchpatch,promptmessagewithcards,voices78,allowanonymoususershare,share-chat-page-entry,039add1b-use-fixed-chat-layout,share-image-link,dailybriefing,pages-table,always-show-last-reaction-v2,azureconfigregexblocklist,disable-cmc-auto-reload,onedrive,suggesthangup,correct-personalization-accidental-opt-out,share-campaign,039add1b-chat-sessions-drawer,039add1b-pages-drawer,injectselfharminstructions,039add1b-refresh-token-worker,account-change-chat-reset,preload-chat-messages,1s-moc-logosize,quiz-card-suggestion,send-connected,anonymousattachmentupload,async-disclaimer-text,mem-generate-post-turn,sharecontinue,share-campaign-taeb9y,share-campaign-krq0kf,dr-editprompt-mobile,039add1b-animated-greeting-message-view,greeting-message-animation,image-fallback-thumbnail,adsidsync,think-deeper-regenerate,smart-mode-flightd-edge,narr-icachuse,img-followup-patch,inject-user-greeting,code-e"
		"dge-c,videoserp5,searchvideos-bing-fallback,searchimages-bing-fallback,edge-responding-loop-harmony-4o-1010,pay-instacart-canada,quiz-in-create-drawer,deep-research-export-file,m365-conversation-sync,deep-research-export-podcast,multiple,originaldocumentupload,web-multi-fallback-languages,share-campaign-evhqea,share-campaign-rbsrqk,share-campaign-tkzuae,share-campaign-jowp8z,share-campaign-gxcdu3,share-campaign-d2e0f5,share-campaign-dkmev6,share-campaign-coqva4,share-campaign-gez3vb,remove-extra-im-start-context,vision-in-composer-v3,deep-research-nano,export-pages-t,copilot-beta,smart-mode-default-rl,039add1b-uikit-paragraph-view,imagegenv3peakhour,onedrive-fetch,share-continue-v2,ts-dynamic-top-section-t,creator-gallery,old-search-config,thinkdeepero4minichainofthought,image-library-2,image-library-delete-image,igszcls,searchimages-cache,searchvideos-cache,pay-consistent-buy,finance-tooltip-v2,m365-pills-custom,copilot-beta-automatic-opt-in,deep-research,quiz-option-shuffle,image-cards-v2,test-srm-aa-4,de"
		"ep-research-promo-card,recipe-card,finance-watchlist-v2,finance-crypto,mutesuggestions,pages-link-navigation,pages-skip-page-selector,pages-file-upload,pages-suggested-followups,onedrive-graph,rm-relatedqna,dr-web-upd-w,dr-pro-nano,pay-getbuyoption-migration,pay-getrecipe-migration,pay-price-tracked,pay-shopify-checkout,sports-cards,smart-mode-reason-chat,pages-reasoning-gg,edge-autosuggest,composer-v4,039add1b-sentry-hang-rate-v2,voice-improved-courtesy-wait,quiz-harmony,sticky-conversation-mode,smart-mode-ensemble-switcher,t1_tsrv3_router,title-generation-harmony,pay-conversion-tracking,history-truncation-fix-parent,backstoryinsertall,local-cards,smart-mode-with-hapi,optimized-responding-for-cache,clarity-http-endpoint,share-image-continue,sharemanagement,labs-audio-expression-style-list-layout,nosearchimageonattachment,start-retry,ui-kit-paragraph-view-2,m365-cela-sheet,placecardprompclean-v3,title-generation-v2,eea-personalization-waiting-period,useggvisionmodel,study-mode,searchimages-safe,searchvideos"
		"-safe,edge-reload-tab,attachment-suggestions-c,vision-biometric-consent,page-title-generation-v2,kill-picasso-id-on-start,zircon-flight-t,browser-actions-09092025,share-campaign-ferk5z,search-pcm,detailedpromptmetrics,file-upload-config,sidebar-settings,placecard-enhance-all,n-30-k-20,pay-ams-treatment,ceo-harmony,finance-chart-clickthrough,labs-audio-expression-scripted-mode,labs-audio-expression-mode-coachmark,labs-audio-expression-story-voice-selector,thinkdeeper5reasoningloweffort,page-title-generation-hapi,skip-preview-event,m365-pills-data-v2,labs-audio-expression-auto-style,edgevision-multitab,flash-cards,finance-earnings,page-safety-check-treatment,analyzedocuments-extendedtokens,labs-audio-expression-preset-card-fixed,lazy-with-retry,sorttoolrouterresult-others-t,character-cognitive-testing-service,voice-flower-bg,thinkdeeper5miniloweffortchainofthought,image-dynamic-width,group-conversations,share-to-invite,deep-research-share-link,cot-output-panel,imagegen-galleryremixquota,place-near-me-fix,rela"
		"ted-results-t1,tru-router,pay-migrate-get-checkout-option-v2,voice-safety-patch,uselongcontextmodel,kill-regenerate,speechtranscribev2,browser-automation-inc-max-loop,thinkdeeper-truncator,search-truncation,backstory-trim,suppress-inline-link-nav-dialog,voice-time-formatting,balancedfiletokens,empty-tool-instruction,think-deeper-move-tool-instructions,heycopilot-backstory,vad-buffer,pay-edge-clarity,dr-progress,labs-audio-expression-story-image,remix-suggestions,ceo-remove-search-web,healthcare-safety-patch-v3,person-card,edge-safety-prompt-treatment,share-conversation-with-attachments,image-upload-mmt,dr-summary,cross-selling-t-gpt52,ceo-optimized-loop,podcast-in-voice,track-oldest-merged-message,mem-clean-forget,url-output-sanitization,gpt5-reasoning-harmony-personality-v1,config-responder-option-by-modelname,responding-loop-for-vision-model,reduce-vision-usage,dynamic-answer-cards-ga,dr-outlinks,quiz-instant-feedback,gpt-5-on-quick-mode,safety-middleware,ceo-filedownload,hide-feedback-if-no-mic-permissio"
		"n-on-end-call,auth-assertion,connector-consent-v2,existing-teen-enabled,voice-clear-audio-capture-listeners-on-end,dr-shared-orchestrator,memory-settings-v2,election-patch,pagecreation,add-utm-source,warnings-indepth,model-migration,route-chat-to-agent,browser-automation-instruction-gpt5,group-conversations-lazy-creation,reduce-memory-overtriggering,image-model-selector-summary,utm-tracking-use-copilot-com,checkmark-emoji-fix,groupchatnotifications,upfront-persistence,groupchat-mentions,edu-cross-sell,browser-actions-charapita,contextual-suggestions,subs-redirect-to-cmc,cef,voice-new-feedback-string,reject-tier4-start-traffic,time-patch,challenge-asn,min-adaptive-citation-t-nav,cloudflare-challenge,chat-recovery-long-streaming-timeout,enable-audio-capture-worklet,voice-memory-edf,reuse-audio-context-for-voice-output,enable-audio-out-pre-buffering-c,socket-close-track,local-inference-client-side-lb,auth0-based-user-link,knowledge-extraction-harmony,router-default-preload-intent,hide-conversation-dates,remove"
		"-qr,edge-shopping-enable-all-markets,deprecate_widgets_v1,edge-page-sanitization,teen-compliance,edge-ctx-consent-tool-executing,skip-reasoning-in-smart-mode,chat-client-retry,labs-remote-config,voice-name-repetition-fix,ltm-backfill-disabled,skip-append-last-user-message-again,framework-conversation-write,email-reply,voice-enable-new-audio-icon-c,backstorytool,block-image-generation-in-voice,increase-doc-attachment-max-tokens,nav-expand-all-t,remove-clarifying-prompts,readaloud-verbatim-prompt,kill-contextual-suggestions-tabs-check,podcast-project-sources-grounding,edf-store-direct-instruction,naa-has-active-account-check,computeruse-raw-cot,reduce-memory-overtrigger-location-c,search-uploaded-docs-in-project,mem-skip-preview-search,genuiskillssmallf12,searchmode-t2,browser-actions-detailed-summary,generate-flashcard-skill,browser-actions-deprecated-non-charapita,proactive-message-additional-context,searchfinance-searchquery,group-conversations-reuse-conv-id,voice-enable-read-aloud-c,edge-text-vision-treat"
		"ment,max-adaptive-citations-c,user-message-copy,match-message-timestamp,edge-tab-safety-cache,voice-telemetry,m365-wxp-history-sync,kill-shopping-homepage-t,nav-card-short-url,kill-projects-creations-flash-card,computer-agent-skills,browser-remote-actions-for-tasks,conversation-compactor,planning-agent-elicitation,spd-citation-v2-mixed-format,agent-snapshots,group-conversations-unread-indicator,gpt52-reasoning-harmony,superbowl-search,autoprompt-off,earcon-only-after-first-use,voice-restart-telemetry,subs-hot-reload,jailbreakdisabled,pdp-track-price-comp-t,olympics-search,supersonic-task-preview,edf-memory-tuning,task-memory,trs-update-flight,block-document-generation-in-voice,task-notification,shopping-journeys-v2-container,shopping-feed-no-hero-image-t,fix-ftr,discovery-long-summary,avoid-edge-vision-highlight,agent-manager-registry,dicf6867,audioagent-v3,lm-arena-v2,windows-vision-highlights,journeys-generation-v2-t,shopping-jump-back-to-conversation-c,studio-sdk,sdk-ai-message-item,sidebar-vnext,chat-se"
		"ssion-affinity,ltm-responding-prompt-tuning-c,topic_continuation_enabled_twice_per_week,trvlflghttf,vertex-timeout,shopping-user-memory-t,fetch-convo,shadowban,update-edge-eu-user-consent-text,genui-tier3-c,genui-ground-counterfactual,discovery-harmony-timestamp,mai-whisper-language-c,gpt51-group-chat,genui-tier4-ground-flight-c,task-notification-no-timeout,shopping-journeys-v2-container-read-c,getcameraimages,web-30s-ping,v3-courteous-wait-c,shopping-feed-thumbs-feedback-toast,conversation-search-region-routing-control,edge-dont-language-switch,upsell-selector,model-training-new-privacy,voice-spatial-info,chainofthoughteventprocessor,chat-message-preview,handle-preview-event,kill-composer-creation-button,smart-mode,smart-mode-6e0b4c6f,smart-mode-cot,smart-mode-flightc,smart-mode-v2-config,searchvideos,searchvideos-google,serpvideocard,video-cards-v2,videocardrespondinginstruction,edge-responder-loop,emit-all-inference-telemetry,responderactions-all,responding-harmony-4o-v4,multi-file-upload,multiple-file-u"
		"pload,unlimitedfilereasoning,grounded-edit,page-citation,pages-footnote,gpt5-calcite,responding-harmony-gpt5-v1,smart-mode-default,tool-defs-on-separate-system-message,1s-moc-keep-facets,1s-moc-more-msn,1s-wpo-dis-dnewsr,1s-wpo-dis-nopod,discover-gemfive,discover-more-news-content,discover-news-all-large-cards,discover-newsts,discover-threets,think-deeper-cot,finance-follow,finance-watchlist-ui,prg-cmc-flws,prg-cmc-fnav,improve-context-precision,ds-editprompt,ds-new-progress,smart-mode-gpt5,actionspacereducerv2,longqueryfilter,tsrv3_router,enable-history-cache-write,truncatekmessages,responding-harmony-gpt-5-nosearch,responding-harmony-gpt-5-search,placecardnavigationenabled,placecardpromptoptimizationenabled,switcher-harmony,browser-actions,browserautomationcomputeruse,browserautomationsearchweb,edgeactiondisableouter,morefileupload,sidebar-compact-nav-items,sidebar-narrow,searchplaces-enhanced-infos,searchplaces-enhanced-photos,truncatekmessages-k20,truncatekmessages-n30,pay-ams-integration-server,pay-ams"
		"-pdp,pay-ams-price-tracking,pay-ams-product-card,edge-page-safety-check,pii-scrubber,sorttoolrouterresult,relatedresults-android,relatedresults-ios,rrcitationv2,searchmode,see-more-results,toolspacereducerclassifierflight,searchweb-page3,searchweb-sd1000,searchweb-shorter,voice-search-timezone,enrich-web-grounding-with-linkedin-api,entity-info,linkedin-url,person-card-prefer-linkedin,person-cards,edge-security-template,image-ocr-hapi,merge-user-messages,deep-research-summary-v3,dr-cover-image,action-result-relaxed-json-escaping,bingify-sanitized-urls,urls-extracted-infer-event,gpt5-reasoning-harmony,thinkdeeper-gpt5reasoning-harmony-personality,dynamic-answer-cards,indepth-comparison-and-details,warnings-and-clarifications,edu-discovery-cross-sell,study-mode-mico-quiz-tutor,citation-v2,citation-v2-cards,citation-v2-nav,inline-image,inline-video,inline-video-moments,adaptive-citations,adaptive-citations-navigation,pinned-conversation,dynamic-card-selection-instructions,nav-all-turns,nav-cards-on-all-modes,na"
		"v-hostqcscore-filter,navigation-curated-enabled,navigation-curation-gpt4o,skip-nav-classifier,generativeui-mvpt3,genui-fiximage,genui-fiximage-12,genui-json-validator,genui-mvp,genui-preturn-refactor,genui-skills,genui-skills-small,genuimvp,searchmode-gpt51-chat-harmony,searchmode-gpt51-promptv2,edge-copilot-screenshot,edge-text-vision,kill-shopping-homepage,shopping-pdp-hide-price-history,shopping-pdp-price-tracking-fallback,sorttoolsbyfrequencyflight,shopping-feed-no-hero-image,shopping-journey-staged-orchestrator,shopping-journeys-debounce,shopping-limit-concurrency,flight-booking-skill,shopping-user-memory,generativeui-flight-status,generativeui-local-events,generativeui-prayer-vertical-timeline,generativeui-sunrise-v2,genui-core,genui-counterfactual,genui-ground-t,genui-grounding-template-selector,genui-tier2-grounding-templates,genui-turncache-templates\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"isNewUser\":false,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"c"
		"hromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298"
		"exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-"
		"3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"AppInfo_Version\":\"145.0.3800.82\",\"eventName\":\"copilotImpression\",\"eventInfo_impressionElement\":\"composerCreateButton\",\"eventInfo_impressionScenario\":\"off\",\"eventInfo_conversationId\":\"vXq2PhARMGqYLvjWoYwWG\"}}\n"
		"{\"name\":\"system\",\"time\":\"2026-03-06T07:23:18.233Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":24,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_numMessages\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D03"
		"4BBCCDD16E182AFC5E06CC216F3A\",\"userFlightIds\":\"imagegenv3,assistant-enable-answer-cards,voice-spatial,weather-cards,edgviswebground,enable-all-app-actions,promptedreasoningcombinedwithsearchpatch,promptmessagewithcards,voices78,allowanonymoususershare,share-chat-page-entry,039add1b-use-fixed-chat-layout,share-image-link,dailybriefing,pages-table,always-show-last-reaction-v2,azureconfigregexblocklist,disable-cmc-auto-reload,onedrive,suggesthangup,correct-personalization-accidental-opt-out,share-campaign,039add1b-chat-sessions-drawer,039add1b-pages-drawer,injectselfharminstructions,039add1b-refresh-token-worker,account-change-chat-reset,preload-chat-messages,1s-moc-logosize,quiz-card-suggestion,send-connected,anonymousattachmentupload,async-disclaimer-text,mem-generate-post-turn,sharecontinue,share-campaign-taeb9y,share-campaign-krq0kf,dr-editprompt-mobile,039add1b-animated-greeting-message-view,greeting-message-animation,image-fallback-thumbnail,adsidsync,think-deeper-regenerate,smart-mode-flightd-edge,n"
		"arr-icachuse,img-followup-patch,inject-user-greeting,code-edge-c,videoserp5,searchvideos-bing-fallback,searchimages-bing-fallback,edge-responding-loop-harmony-4o-1010,pay-instacart-canada,quiz-in-create-drawer,deep-research-export-file,m365-conversation-sync,deep-research-export-podcast,multiple,originaldocumentupload,web-multi-fallback-languages,share-campaign-evhqea,share-campaign-rbsrqk,share-campaign-tkzuae,share-campaign-jowp8z,share-campaign-gxcdu3,share-campaign-d2e0f5,share-campaign-dkmev6,share-campaign-coqva4,share-campaign-gez3vb,remove-extra-im-start-context,vision-in-composer-v3,deep-research-nano,export-pages-t,copilot-beta,smart-mode-default-rl,039add1b-uikit-paragraph-view,imagegenv3peakhour,onedrive-fetch,share-continue-v2,ts-dynamic-top-section-t,creator-gallery,old-search-config,thinkdeepero4minichainofthought,image-library-2,image-library-delete-image,igszcls,searchimages-cache,searchvideos-cache,pay-consistent-buy,finance-tooltip-v2,m365-pills-custom,copilot-beta-automatic-opt-in,deep-r"
		"esearch,quiz-option-shuffle,image-cards-v2,test-srm-aa-4,deep-research-promo-card,recipe-card,finance-watchlist-v2,finance-crypto,mutesuggestions,pages-link-navigation,pages-skip-page-selector,pages-file-upload,pages-suggested-followups,onedrive-graph,rm-relatedqna,dr-web-upd-w,dr-pro-nano,pay-getbuyoption-migration,pay-getrecipe-migration,pay-price-tracked,pay-shopify-checkout,sports-cards,smart-mode-reason-chat,pages-reasoning-gg,edge-autosuggest,composer-v4,039add1b-sentry-hang-rate-v2,voice-improved-courtesy-wait,quiz-harmony,sticky-conversation-mode,smart-mode-ensemble-switcher,t1_tsrv3_router,title-generation-harmony,pay-conversion-tracking,history-truncation-fix-parent,backstoryinsertall,local-cards,smart-mode-with-hapi,optimized-responding-for-cache,clarity-http-endpoint,share-image-continue,sharemanagement,labs-audio-expression-style-list-layout,nosearchimageonattachment,start-retry,ui-kit-paragraph-view-2,m365-cela-sheet,placecardprompclean-v3,title-generation-v2,eea-personalization-waiting-period"
		",useggvisionmodel,study-mode,searchimages-safe,searchvideos-safe,edge-reload-tab,attachment-suggestions-c,vision-biometric-consent,page-title-generation-v2,kill-picasso-id-on-start,zircon-flight-t,browser-actions-09092025,share-campaign-ferk5z,search-pcm,detailedpromptmetrics,file-upload-config,sidebar-settings,placecard-enhance-all,n-30-k-20,pay-ams-treatment,ceo-harmony,finance-chart-clickthrough,labs-audio-expression-scripted-mode,labs-audio-expression-mode-coachmark,labs-audio-expression-story-voice-selector,thinkdeeper5reasoningloweffort,page-title-generation-hapi,skip-preview-event,m365-pills-data-v2,labs-audio-expression-auto-style,edgevision-multitab,flash-cards,finance-earnings,page-safety-check-treatment,analyzedocuments-extendedtokens,labs-audio-expression-preset-card-fixed,lazy-with-retry,sorttoolrouterresult-others-t,character-cognitive-testing-service,voice-flower-bg,thinkdeeper5miniloweffortchainofthought,image-dynamic-width,group-conversations,share-to-invite,deep-research-share-link,cot-out"
		"put-panel,imagegen-galleryremixquota,place-near-me-fix,related-results-t1,tru-router,pay-migrate-get-checkout-option-v2,voice-safety-patch,uselongcontextmodel,kill-regenerate,speechtranscribev2,browser-automation-inc-max-loop,thinkdeeper-truncator,search-truncation,backstory-trim,suppress-inline-link-nav-dialog,voice-time-formatting,balancedfiletokens,empty-tool-instruction,think-deeper-move-tool-instructions,heycopilot-backstory,vad-buffer,pay-edge-clarity,dr-progress,labs-audio-expression-story-image,remix-suggestions,ceo-remove-search-web,healthcare-safety-patch-v3,person-card,edge-safety-prompt-treatment,share-conversation-with-attachments,image-upload-mmt,dr-summary,cross-selling-t-gpt52,ceo-optimized-loop,podcast-in-voice,track-oldest-merged-message,mem-clean-forget,url-output-sanitization,gpt5-reasoning-harmony-personality-v1,config-responder-option-by-modelname,responding-loop-for-vision-model,reduce-vision-usage,dynamic-answer-cards-ga,dr-outlinks,quiz-instant-feedback,gpt-5-on-quick-mode,safety-mi"
		"ddleware,ceo-filedownload,hide-feedback-if-no-mic-permission-on-end-call,auth-assertion,connector-consent-v2,existing-teen-enabled,voice-clear-audio-capture-listeners-on-end,dr-shared-orchestrator,memory-settings-v2,election-patch,pagecreation,add-utm-source,warnings-indepth,model-migration,route-chat-to-agent,browser-automation-instruction-gpt5,group-conversations-lazy-creation,reduce-memory-overtriggering,image-model-selector-summary,utm-tracking-use-copilot-com,checkmark-emoji-fix,groupchatnotifications,upfront-persistence,groupchat-mentions,edu-cross-sell,browser-actions-charapita,contextual-suggestions,subs-redirect-to-cmc,cef,voice-new-feedback-string,reject-tier4-start-traffic,time-patch,challenge-asn,min-adaptive-citation-t-nav,cloudflare-challenge,chat-recovery-long-streaming-timeout,enable-audio-capture-worklet,voice-memory-edf,reuse-audio-context-for-voice-output,enable-audio-out-pre-buffering-c,socket-close-track,local-inference-client-side-lb,auth0-based-user-link,knowledge-extraction-harmony,r"
		"outer-default-preload-intent,hide-conversation-dates,remove-qr,edge-shopping-enable-all-markets,deprecate_widgets_v1,edge-page-sanitization,teen-compliance,edge-ctx-consent-tool-executing,skip-reasoning-in-smart-mode,chat-client-retry,labs-remote-config,voice-name-repetition-fix,ltm-backfill-disabled,skip-append-last-user-message-again,framework-conversation-write,email-reply,voice-enable-new-audio-icon-c,backstorytool,block-image-generation-in-voice,increase-doc-attachment-max-tokens,nav-expand-all-t,remove-clarifying-prompts,readaloud-verbatim-prompt,kill-contextual-suggestions-tabs-check,podcast-project-sources-grounding,edf-store-direct-instruction,naa-has-active-account-check,computeruse-raw-cot,reduce-memory-overtrigger-location-c,search-uploaded-docs-in-project,mem-skip-preview-search,genuiskillssmallf12,searchmode-t2,browser-actions-detailed-summary,generate-flashcard-skill,browser-actions-deprecated-non-charapita,proactive-message-additional-context,searchfinance-searchquery,group-conversations-reu"
		"se-conv-id,voice-enable-read-aloud-c,edge-text-vision-treatment,max-adaptive-citations-c,user-message-copy,match-message-timestamp,edge-tab-safety-cache,voice-telemetry,m365-wxp-history-sync,kill-shopping-homepage-t,nav-card-short-url,kill-projects-creations-flash-card,computer-agent-skills,browser-remote-actions-for-tasks,conversation-compactor,planning-agent-elicitation,spd-citation-v2-mixed-format,agent-snapshots,group-conversations-unread-indicator,gpt52-reasoning-harmony,superbowl-search,autoprompt-off,earcon-only-after-first-use,voice-restart-telemetry,subs-hot-reload,jailbreakdisabled,pdp-track-price-comp-t,olympics-search,supersonic-task-preview,edf-memory-tuning,task-memory,trs-update-flight,block-document-generation-in-voice,task-notification,shopping-journeys-v2-container,shopping-feed-no-hero-image-t,fix-ftr,discovery-long-summary,avoid-edge-vision-highlight,agent-manager-registry,dicf6867,audioagent-v3,lm-arena-v2,windows-vision-highlights,journeys-generation-v2-t,shopping-jump-back-to-conversa"
		"tion-c,studio-sdk,sdk-ai-message-item,sidebar-vnext,chat-session-affinity,ltm-responding-prompt-tuning-c,topic_continuation_enabled_twice_per_week,trvlflghttf,vertex-timeout,shopping-user-memory-t,fetch-convo,shadowban,update-edge-eu-user-consent-text,genui-tier3-c,genui-ground-counterfactual,discovery-harmony-timestamp,mai-whisper-language-c,gpt51-group-chat,genui-tier4-ground-flight-c,task-notification-no-timeout,shopping-journeys-v2-container-read-c,getcameraimages,web-30s-ping,v3-courteous-wait-c,shopping-feed-thumbs-feedback-toast,conversation-search-region-routing-control,edge-dont-language-switch,upsell-selector,model-training-new-privacy,voice-spatial-info,chainofthoughteventprocessor,chat-message-preview,handle-preview-event,kill-composer-creation-button,smart-mode,smart-mode-6e0b4c6f,smart-mode-cot,smart-mode-flightc,smart-mode-v2-config,searchvideos,searchvideos-google,serpvideocard,video-cards-v2,videocardrespondinginstruction,edge-responder-loop,emit-all-inference-telemetry,responderactions-all"
		",responding-harmony-4o-v4,multi-file-upload,multiple-file-upload,unlimitedfilereasoning,grounded-edit,page-citation,pages-footnote,gpt5-calcite,responding-harmony-gpt5-v1,smart-mode-default,tool-defs-on-separate-system-message,1s-moc-keep-facets,1s-moc-more-msn,1s-wpo-dis-dnewsr,1s-wpo-dis-nopod,discover-gemfive,discover-more-news-content,discover-news-all-large-cards,discover-newsts,discover-threets,think-deeper-cot,finance-follow,finance-watchlist-ui,prg-cmc-flws,prg-cmc-fnav,improve-context-precision,ds-editprompt,ds-new-progress,smart-mode-gpt5,actionspacereducerv2,longqueryfilter,tsrv3_router,enable-history-cache-write,truncatekmessages,responding-harmony-gpt-5-nosearch,responding-harmony-gpt-5-search,placecardnavigationenabled,placecardpromptoptimizationenabled,switcher-harmony,browser-actions,browserautomationcomputeruse,browserautomationsearchweb,edgeactiondisableouter,morefileupload,sidebar-compact-nav-items,sidebar-narrow,searchplaces-enhanced-infos,searchplaces-enhanced-photos,truncatekmessages-k"
		"20,truncatekmessages-n30,pay-ams-integration-server,pay-ams-pdp,pay-ams-price-tracking,pay-ams-product-card,edge-page-safety-check,pii-scrubber,sorttoolrouterresult,relatedresults-android,relatedresults-ios,rrcitationv2,searchmode,see-more-results,toolspacereducerclassifierflight,searchweb-page3,searchweb-sd1000,searchweb-shorter,voice-search-timezone,enrich-web-grounding-with-linkedin-api,entity-info,linkedin-url,person-card-prefer-linkedin,person-cards,edge-security-template,image-ocr-hapi,merge-user-messages,deep-research-summary-v3,dr-cover-image,action-result-relaxed-json-escaping,bingify-sanitized-urls,urls-extracted-infer-event,gpt5-reasoning-harmony,thinkdeeper-gpt5reasoning-harmony-personality,dynamic-answer-cards,indepth-comparison-and-details,warnings-and-clarifications,edu-discovery-cross-sell,study-mode-mico-quiz-tutor,citation-v2,citation-v2-cards,citation-v2-nav,inline-image,inline-video,inline-video-moments,adaptive-citations,adaptive-citations-navigation,pinned-conversation,dynamic-card-sel"
		"ection-instructions,nav-all-turns,nav-cards-on-all-modes,nav-hostqcscore-filter,navigation-curated-enabled,navigation-curation-gpt4o,skip-nav-classifier,generativeui-mvpt3,genui-fiximage,genui-fiximage-12,genui-json-validator,genui-mvp,genui-preturn-refactor,genui-skills,genui-skills-small,genuimvp,searchmode-gpt51-chat-harmony,searchmode-gpt51-promptv2,edge-copilot-screenshot,edge-text-vision,kill-shopping-homepage,shopping-pdp-hide-price-history,shopping-pdp-price-tracking-fallback,sorttoolsbyfrequencyflight,shopping-feed-no-hero-image,shopping-journey-staged-orchestrator,shopping-journeys-debounce,shopping-limit-concurrency,flight-booking-skill,shopping-user-memory,generativeui-flight-status,generativeui-local-events,generativeui-prayer-vertical-timeline,generativeui-sunrise-v2,genui-core,genui-counterfactual,genui-ground-t,genui-grounding-template-selector,genui-tier2-grounding-templates,genui-turncache-templates\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"isNewUser\":false,"
		"\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:"
		"969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306"
		"-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"AppInfo_Version\":\"145.0.3800.82\",\"eventName\":\"edgePendingContextResponses\",\"eventInfo_numMessages\":0}}\n"
		"{\"name\":\"system\",\"time\":\"2026-03-06T07:23:18.245Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":25,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_duration\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BB"
		"CCDD16E182AFC5E06CC216F3A\",\"userFlightIds\":\"imagegenv3,assistant-enable-answer-cards,voice-spatial,weather-cards,edgviswebground,enable-all-app-actions,promptedreasoningcombinedwithsearchpatch,promptmessagewithcards,voices78,allowanonymoususershare,share-chat-page-entry,039add1b-use-fixed-chat-layout,share-image-link,dailybriefing,pages-table,always-show-last-reaction-v2,azureconfigregexblocklist,disable-cmc-auto-reload,onedrive,suggesthangup,correct-personalization-accidental-opt-out,share-campaign,039add1b-chat-sessions-drawer,039add1b-pages-drawer,injectselfharminstructions,039add1b-refresh-token-worker,account-change-chat-reset,preload-chat-messages,1s-moc-logosize,quiz-card-suggestion,send-connected,anonymousattachmentupload,async-disclaimer-text,mem-generate-post-turn,sharecontinue,share-campaign-taeb9y,share-campaign-krq0kf,dr-editprompt-mobile,039add1b-animated-greeting-message-view,greeting-message-animation,image-fallback-thumbnail,adsidsync,think-deeper-regenerate,smart-mode-flightd-edge,narr"
		"-icachuse,img-followup-patch,inject-user-greeting,code-edge-c,videoserp5,searchvideos-bing-fallback,searchimages-bing-fallback,edge-responding-loop-harmony-4o-1010,pay-instacart-canada,quiz-in-create-drawer,deep-research-export-file,m365-conversation-sync,deep-research-export-podcast,multiple,originaldocumentupload,web-multi-fallback-languages,share-campaign-evhqea,share-campaign-rbsrqk,share-campaign-tkzuae,share-campaign-jowp8z,share-campaign-gxcdu3,share-campaign-d2e0f5,share-campaign-dkmev6,share-campaign-coqva4,share-campaign-gez3vb,remove-extra-im-start-context,vision-in-composer-v3,deep-research-nano,export-pages-t,copilot-beta,smart-mode-default-rl,039add1b-uikit-paragraph-view,imagegenv3peakhour,onedrive-fetch,share-continue-v2,ts-dynamic-top-section-t,creator-gallery,old-search-config,thinkdeepero4minichainofthought,image-library-2,image-library-delete-image,igszcls,searchimages-cache,searchvideos-cache,pay-consistent-buy,finance-tooltip-v2,m365-pills-custom,copilot-beta-automatic-opt-in,deep-rese"
		"arch,quiz-option-shuffle,image-cards-v2,test-srm-aa-4,deep-research-promo-card,recipe-card,finance-watchlist-v2,finance-crypto,mutesuggestions,pages-link-navigation,pages-skip-page-selector,pages-file-upload,pages-suggested-followups,onedrive-graph,rm-relatedqna,dr-web-upd-w,dr-pro-nano,pay-getbuyoption-migration,pay-getrecipe-migration,pay-price-tracked,pay-shopify-checkout,sports-cards,smart-mode-reason-chat,pages-reasoning-gg,edge-autosuggest,composer-v4,039add1b-sentry-hang-rate-v2,voice-improved-courtesy-wait,quiz-harmony,sticky-conversation-mode,smart-mode-ensemble-switcher,t1_tsrv3_router,title-generation-harmony,pay-conversion-tracking,history-truncation-fix-parent,backstoryinsertall,local-cards,smart-mode-with-hapi,optimized-responding-for-cache,clarity-http-endpoint,share-image-continue,sharemanagement,labs-audio-expression-style-list-layout,nosearchimageonattachment,start-retry,ui-kit-paragraph-view-2,m365-cela-sheet,placecardprompclean-v3,title-generation-v2,eea-personalization-waiting-period,us"
		"eggvisionmodel,study-mode,searchimages-safe,searchvideos-safe,edge-reload-tab,attachment-suggestions-c,vision-biometric-consent,page-title-generation-v2,kill-picasso-id-on-start,zircon-flight-t,browser-actions-09092025,share-campaign-ferk5z,search-pcm,detailedpromptmetrics,file-upload-config,sidebar-settings,placecard-enhance-all,n-30-k-20,pay-ams-treatment,ceo-harmony,finance-chart-clickthrough,labs-audio-expression-scripted-mode,labs-audio-expression-mode-coachmark,labs-audio-expression-story-voice-selector,thinkdeeper5reasoningloweffort,page-title-generation-hapi,skip-preview-event,m365-pills-data-v2,labs-audio-expression-auto-style,edgevision-multitab,flash-cards,finance-earnings,page-safety-check-treatment,analyzedocuments-extendedtokens,labs-audio-expression-preset-card-fixed,lazy-with-retry,sorttoolrouterresult-others-t,character-cognitive-testing-service,voice-flower-bg,thinkdeeper5miniloweffortchainofthought,image-dynamic-width,group-conversations,share-to-invite,deep-research-share-link,cot-output"
		"-panel,imagegen-galleryremixquota,place-near-me-fix,related-results-t1,tru-router,pay-migrate-get-checkout-option-v2,voice-safety-patch,uselongcontextmodel,kill-regenerate,speechtranscribev2,browser-automation-inc-max-loop,thinkdeeper-truncator,search-truncation,backstory-trim,suppress-inline-link-nav-dialog,voice-time-formatting,balancedfiletokens,empty-tool-instruction,think-deeper-move-tool-instructions,heycopilot-backstory,vad-buffer,pay-edge-clarity,dr-progress,labs-audio-expression-story-image,remix-suggestions,ceo-remove-search-web,healthcare-safety-patch-v3,person-card,edge-safety-prompt-treatment,share-conversation-with-attachments,image-upload-mmt,dr-summary,cross-selling-t-gpt52,ceo-optimized-loop,podcast-in-voice,track-oldest-merged-message,mem-clean-forget,url-output-sanitization,gpt5-reasoning-harmony-personality-v1,config-responder-option-by-modelname,responding-loop-for-vision-model,reduce-vision-usage,dynamic-answer-cards-ga,dr-outlinks,quiz-instant-feedback,gpt-5-on-quick-mode,safety-middl"
		"eware,ceo-filedownload,hide-feedback-if-no-mic-permission-on-end-call,auth-assertion,connector-consent-v2,existing-teen-enabled,voice-clear-audio-capture-listeners-on-end,dr-shared-orchestrator,memory-settings-v2,election-patch,pagecreation,add-utm-source,warnings-indepth,model-migration,route-chat-to-agent,browser-automation-instruction-gpt5,group-conversations-lazy-creation,reduce-memory-overtriggering,image-model-selector-summary,utm-tracking-use-copilot-com,checkmark-emoji-fix,groupchatnotifications,upfront-persistence,groupchat-mentions,edu-cross-sell,browser-actions-charapita,contextual-suggestions,subs-redirect-to-cmc,cef,voice-new-feedback-string,reject-tier4-start-traffic,time-patch,challenge-asn,min-adaptive-citation-t-nav,cloudflare-challenge,chat-recovery-long-streaming-timeout,enable-audio-capture-worklet,voice-memory-edf,reuse-audio-context-for-voice-output,enable-audio-out-pre-buffering-c,socket-close-track,local-inference-client-side-lb,auth0-based-user-link,knowledge-extraction-harmony,rout"
		"er-default-preload-intent,hide-conversation-dates,remove-qr,edge-shopping-enable-all-markets,deprecate_widgets_v1,edge-page-sanitization,teen-compliance,edge-ctx-consent-tool-executing,skip-reasoning-in-smart-mode,chat-client-retry,labs-remote-config,voice-name-repetition-fix,ltm-backfill-disabled,skip-append-last-user-message-again,framework-conversation-write,email-reply,voice-enable-new-audio-icon-c,backstorytool,block-image-generation-in-voice,increase-doc-attachment-max-tokens,nav-expand-all-t,remove-clarifying-prompts,readaloud-verbatim-prompt,kill-contextual-suggestions-tabs-check,podcast-project-sources-grounding,edf-store-direct-instruction,naa-has-active-account-check,computeruse-raw-cot,reduce-memory-overtrigger-location-c,search-uploaded-docs-in-project,mem-skip-preview-search,genuiskillssmallf12,searchmode-t2,browser-actions-detailed-summary,generate-flashcard-skill,browser-actions-deprecated-non-charapita,proactive-message-additional-context,searchfinance-searchquery,group-conversations-reuse-"
		"conv-id,voice-enable-read-aloud-c,edge-text-vision-treatment,max-adaptive-citations-c,user-message-copy,match-message-timestamp,edge-tab-safety-cache,voice-telemetry,m365-wxp-history-sync,kill-shopping-homepage-t,nav-card-short-url,kill-projects-creations-flash-card,computer-agent-skills,browser-remote-actions-for-tasks,conversation-compactor,planning-agent-elicitation,spd-citation-v2-mixed-format,agent-snapshots,group-conversations-unread-indicator,gpt52-reasoning-harmony,superbowl-search,autoprompt-off,earcon-only-after-first-use,voice-restart-telemetry,subs-hot-reload,jailbreakdisabled,pdp-track-price-comp-t,olympics-search,supersonic-task-preview,edf-memory-tuning,task-memory,trs-update-flight,block-document-generation-in-voice,task-notification,shopping-journeys-v2-container,shopping-feed-no-hero-image-t,fix-ftr,discovery-long-summary,avoid-edge-vision-highlight,agent-manager-registry,dicf6867,audioagent-v3,lm-arena-v2,windows-vision-highlights,journeys-generation-v2-t,shopping-jump-back-to-conversatio"
		"n-c,studio-sdk,sdk-ai-message-item,sidebar-vnext,chat-session-affinity,ltm-responding-prompt-tuning-c,topic_continuation_enabled_twice_per_week,trvlflghttf,vertex-timeout,shopping-user-memory-t,fetch-convo,shadowban,update-edge-eu-user-consent-text,genui-tier3-c,genui-ground-counterfactual,discovery-harmony-timestamp,mai-whisper-language-c,gpt51-group-chat,genui-tier4-ground-flight-c,task-notification-no-timeout,shopping-journeys-v2-container-read-c,getcameraimages,web-30s-ping,v3-courteous-wait-c,shopping-feed-thumbs-feedback-toast,conversation-search-region-routing-control,edge-dont-language-switch,upsell-selector,model-training-new-privacy,voice-spatial-info,chainofthoughteventprocessor,chat-message-preview,handle-preview-event,kill-composer-creation-button,smart-mode,smart-mode-6e0b4c6f,smart-mode-cot,smart-mode-flightc,smart-mode-v2-config,searchvideos,searchvideos-google,serpvideocard,video-cards-v2,videocardrespondinginstruction,edge-responder-loop,emit-all-inference-telemetry,responderactions-all,re"
		"sponding-harmony-4o-v4,multi-file-upload,multiple-file-upload,unlimitedfilereasoning,grounded-edit,page-citation,pages-footnote,gpt5-calcite,responding-harmony-gpt5-v1,smart-mode-default,tool-defs-on-separate-system-message,1s-moc-keep-facets,1s-moc-more-msn,1s-wpo-dis-dnewsr,1s-wpo-dis-nopod,discover-gemfive,discover-more-news-content,discover-news-all-large-cards,discover-newsts,discover-threets,think-deeper-cot,finance-follow,finance-watchlist-ui,prg-cmc-flws,prg-cmc-fnav,improve-context-precision,ds-editprompt,ds-new-progress,smart-mode-gpt5,actionspacereducerv2,longqueryfilter,tsrv3_router,enable-history-cache-write,truncatekmessages,responding-harmony-gpt-5-nosearch,responding-harmony-gpt-5-search,placecardnavigationenabled,placecardpromptoptimizationenabled,switcher-harmony,browser-actions,browserautomationcomputeruse,browserautomationsearchweb,edgeactiondisableouter,morefileupload,sidebar-compact-nav-items,sidebar-narrow,searchplaces-enhanced-infos,searchplaces-enhanced-photos,truncatekmessages-k20,"
		"truncatekmessages-n30,pay-ams-integration-server,pay-ams-pdp,pay-ams-price-tracking,pay-ams-product-card,edge-page-safety-check,pii-scrubber,sorttoolrouterresult,relatedresults-android,relatedresults-ios,rrcitationv2,searchmode,see-more-results,toolspacereducerclassifierflight,searchweb-page3,searchweb-sd1000,searchweb-shorter,voice-search-timezone,enrich-web-grounding-with-linkedin-api,entity-info,linkedin-url,person-card-prefer-linkedin,person-cards,edge-security-template,image-ocr-hapi,merge-user-messages,deep-research-summary-v3,dr-cover-image,action-result-relaxed-json-escaping,bingify-sanitized-urls,urls-extracted-infer-event,gpt5-reasoning-harmony,thinkdeeper-gpt5reasoning-harmony-personality,dynamic-answer-cards,indepth-comparison-and-details,warnings-and-clarifications,edu-discovery-cross-sell,study-mode-mico-quiz-tutor,citation-v2,citation-v2-cards,citation-v2-nav,inline-image,inline-video,inline-video-moments,adaptive-citations,adaptive-citations-navigation,pinned-conversation,dynamic-card-select"
		"ion-instructions,nav-all-turns,nav-cards-on-all-modes,nav-hostqcscore-filter,navigation-curated-enabled,navigation-curation-gpt4o,skip-nav-classifier,generativeui-mvpt3,genui-fiximage,genui-fiximage-12,genui-json-validator,genui-mvp,genui-preturn-refactor,genui-skills,genui-skills-small,genuimvp,searchmode-gpt51-chat-harmony,searchmode-gpt51-promptv2,edge-copilot-screenshot,edge-text-vision,kill-shopping-homepage,shopping-pdp-hide-price-history,shopping-pdp-price-tracking-fallback,sorttoolsbyfrequencyflight,shopping-feed-no-hero-image,shopping-journey-staged-orchestrator,shopping-journeys-debounce,shopping-limit-concurrency,flight-booking-skill,shopping-user-memory,generativeui-flight-status,generativeui-local-events,generativeui-prayer-vertical-timeline,generativeui-sunrise-v2,genui-core,genui-counterfactual,genui-ground-t,genui-grounding-template-selector,genui-tier2-grounding-templates,genui-turncache-templates\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"isNewUser\":false,\"pa"
		"thname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:9699"
		"12,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-1"
		"8,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"AppInfo_Version\":\"145.0.3800.82\",\"eventName\":\"timeToNavigate\",\"eventInfo_customData\":\"{\\\\\"routeId\\\\\":\\\\\"/\\\\\",\\\\\"pathname\\\\\":\\\\\"/\\\\\",\\\\\"isLoaded\\\\\":true,\\\\\"defaultPreload\\\\\":false}\",\"eventInfo_duration\":178.09999990463257}}\n"
		"{\"name\":\"system\",\"time\":\"2026-03-06T07:23:18.340Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":26,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_numMessages\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D03"
		"4BBCCDD16E182AFC5E06CC216F3A\",\"userFlightIds\":\"imagegenv3,assistant-enable-answer-cards,voice-spatial,weather-cards,edgviswebground,enable-all-app-actions,promptedreasoningcombinedwithsearchpatch,promptmessagewithcards,voices78,allowanonymoususershare,share-chat-page-entry,039add1b-use-fixed-chat-layout,share-image-link,dailybriefing,pages-table,always-show-last-reaction-v2,azureconfigregexblocklist,disable-cmc-auto-reload,onedrive,suggesthangup,correct-personalization-accidental-opt-out,share-campaign,039add1b-chat-sessions-drawer,039add1b-pages-drawer,injectselfharminstructions,039add1b-refresh-token-worker,account-change-chat-reset,preload-chat-messages,1s-moc-logosize,quiz-card-suggestion,send-connected,anonymousattachmentupload,async-disclaimer-text,mem-generate-post-turn,sharecontinue,share-campaign-taeb9y,share-campaign-krq0kf,dr-editprompt-mobile,039add1b-animated-greeting-message-view,greeting-message-animation,image-fallback-thumbnail,adsidsync,think-deeper-regenerate,smart-mode-flightd-edge,n"
		"arr-icachuse,img-followup-patch,inject-user-greeting,code-edge-c,videoserp5,searchvideos-bing-fallback,searchimages-bing-fallback,edge-responding-loop-harmony-4o-1010,pay-instacart-canada,quiz-in-create-drawer,deep-research-export-file,m365-conversation-sync,deep-research-export-podcast,multiple,originaldocumentupload,web-multi-fallback-languages,share-campaign-evhqea,share-campaign-rbsrqk,share-campaign-tkzuae,share-campaign-jowp8z,share-campaign-gxcdu3,share-campaign-d2e0f5,share-campaign-dkmev6,share-campaign-coqva4,share-campaign-gez3vb,remove-extra-im-start-context,vision-in-composer-v3,deep-research-nano,export-pages-t,copilot-beta,smart-mode-default-rl,039add1b-uikit-paragraph-view,imagegenv3peakhour,onedrive-fetch,share-continue-v2,ts-dynamic-top-section-t,creator-gallery,old-search-config,thinkdeepero4minichainofthought,image-library-2,image-library-delete-image,igszcls,searchimages-cache,searchvideos-cache,pay-consistent-buy,finance-tooltip-v2,m365-pills-custom,copilot-beta-automatic-opt-in,deep-r"
		"esearch,quiz-option-shuffle,image-cards-v2,test-srm-aa-4,deep-research-promo-card,recipe-card,finance-watchlist-v2,finance-crypto,mutesuggestions,pages-link-navigation,pages-skip-page-selector,pages-file-upload,pages-suggested-followups,onedrive-graph,rm-relatedqna,dr-web-upd-w,dr-pro-nano,pay-getbuyoption-migration,pay-getrecipe-migration,pay-price-tracked,pay-shopify-checkout,sports-cards,smart-mode-reason-chat,pages-reasoning-gg,edge-autosuggest,composer-v4,039add1b-sentry-hang-rate-v2,voice-improved-courtesy-wait,quiz-harmony,sticky-conversation-mode,smart-mode-ensemble-switcher,t1_tsrv3_router,title-generation-harmony,pay-conversion-tracking,history-truncation-fix-parent,backstoryinsertall,local-cards,smart-mode-with-hapi,optimized-responding-for-cache,clarity-http-endpoint,share-image-continue,sharemanagement,labs-audio-expression-style-list-layout,nosearchimageonattachment,start-retry,ui-kit-paragraph-view-2,m365-cela-sheet,placecardprompclean-v3,title-generation-v2,eea-personalization-waiting-period"
		",useggvisionmodel,study-mode,searchimages-safe,searchvideos-safe,edge-reload-tab,attachment-suggestions-c,vision-biometric-consent,page-title-generation-v2,kill-picasso-id-on-start,zircon-flight-t,browser-actions-09092025,share-campaign-ferk5z,search-pcm,detailedpromptmetrics,file-upload-config,sidebar-settings,placecard-enhance-all,n-30-k-20,pay-ams-treatment,ceo-harmony,finance-chart-clickthrough,labs-audio-expression-scripted-mode,labs-audio-expression-mode-coachmark,labs-audio-expression-story-voice-selector,thinkdeeper5reasoningloweffort,page-title-generation-hapi,skip-preview-event,m365-pills-data-v2,labs-audio-expression-auto-style,edgevision-multitab,flash-cards,finance-earnings,page-safety-check-treatment,analyzedocuments-extendedtokens,labs-audio-expression-preset-card-fixed,lazy-with-retry,sorttoolrouterresult-others-t,character-cognitive-testing-service,voice-flower-bg,thinkdeeper5miniloweffortchainofthought,image-dynamic-width,group-conversations,share-to-invite,deep-research-share-link,cot-out"
		"put-panel,imagegen-galleryremixquota,place-near-me-fix,related-results-t1,tru-router,pay-migrate-get-checkout-option-v2,voice-safety-patch,uselongcontextmodel,kill-regenerate,speechtranscribev2,browser-automation-inc-max-loop,thinkdeeper-truncator,search-truncation,backstory-trim,suppress-inline-link-nav-dialog,voice-time-formatting,balancedfiletokens,empty-tool-instruction,think-deeper-move-tool-instructions,heycopilot-backstory,vad-buffer,pay-edge-clarity,dr-progress,labs-audio-expression-story-image,remix-suggestions,ceo-remove-search-web,healthcare-safety-patch-v3,person-card,edge-safety-prompt-treatment,share-conversation-with-attachments,image-upload-mmt,dr-summary,cross-selling-t-gpt52,ceo-optimized-loop,podcast-in-voice,track-oldest-merged-message,mem-clean-forget,url-output-sanitization,gpt5-reasoning-harmony-personality-v1,config-responder-option-by-modelname,responding-loop-for-vision-model,reduce-vision-usage,dynamic-answer-cards-ga,dr-outlinks,quiz-instant-feedback,gpt-5-on-quick-mode,safety-mi"
		"ddleware,ceo-filedownload,hide-feedback-if-no-mic-permission-on-end-call,auth-assertion,connector-consent-v2,existing-teen-enabled,voice-clear-audio-capture-listeners-on-end,dr-shared-orchestrator,memory-settings-v2,election-patch,pagecreation,add-utm-source,warnings-indepth,model-migration,route-chat-to-agent,browser-automation-instruction-gpt5,group-conversations-lazy-creation,reduce-memory-overtriggering,image-model-selector-summary,utm-tracking-use-copilot-com,checkmark-emoji-fix,groupchatnotifications,upfront-persistence,groupchat-mentions,edu-cross-sell,browser-actions-charapita,contextual-suggestions,subs-redirect-to-cmc,cef,voice-new-feedback-string,reject-tier4-start-traffic,time-patch,challenge-asn,min-adaptive-citation-t-nav,cloudflare-challenge,chat-recovery-long-streaming-timeout,enable-audio-capture-worklet,voice-memory-edf,reuse-audio-context-for-voice-output,enable-audio-out-pre-buffering-c,socket-close-track,local-inference-client-side-lb,auth0-based-user-link,knowledge-extraction-harmony,r"
		"outer-default-preload-intent,hide-conversation-dates,remove-qr,edge-shopping-enable-all-markets,deprecate_widgets_v1,edge-page-sanitization,teen-compliance,edge-ctx-consent-tool-executing,skip-reasoning-in-smart-mode,chat-client-retry,labs-remote-config,voice-name-repetition-fix,ltm-backfill-disabled,skip-append-last-user-message-again,framework-conversation-write,email-reply,voice-enable-new-audio-icon-c,backstorytool,block-image-generation-in-voice,increase-doc-attachment-max-tokens,nav-expand-all-t,remove-clarifying-prompts,readaloud-verbatim-prompt,kill-contextual-suggestions-tabs-check,podcast-project-sources-grounding,edf-store-direct-instruction,naa-has-active-account-check,computeruse-raw-cot,reduce-memory-overtrigger-location-c,search-uploaded-docs-in-project,mem-skip-preview-search,genuiskillssmallf12,searchmode-t2,browser-actions-detailed-summary,generate-flashcard-skill,browser-actions-deprecated-non-charapita,proactive-message-additional-context,searchfinance-searchquery,group-conversations-reu"
		"se-conv-id,voice-enable-read-aloud-c,edge-text-vision-treatment,max-adaptive-citations-c,user-message-copy,match-message-timestamp,edge-tab-safety-cache,voice-telemetry,m365-wxp-history-sync,kill-shopping-homepage-t,nav-card-short-url,kill-projects-creations-flash-card,computer-agent-skills,browser-remote-actions-for-tasks,conversation-compactor,planning-agent-elicitation,spd-citation-v2-mixed-format,agent-snapshots,group-conversations-unread-indicator,gpt52-reasoning-harmony,superbowl-search,autoprompt-off,earcon-only-after-first-use,voice-restart-telemetry,subs-hot-reload,jailbreakdisabled,pdp-track-price-comp-t,olympics-search,supersonic-task-preview,edf-memory-tuning,task-memory,trs-update-flight,block-document-generation-in-voice,task-notification,shopping-journeys-v2-container,shopping-feed-no-hero-image-t,fix-ftr,discovery-long-summary,avoid-edge-vision-highlight,agent-manager-registry,dicf6867,audioagent-v3,lm-arena-v2,windows-vision-highlights,journeys-generation-v2-t,shopping-jump-back-to-conversa"
		"tion-c,studio-sdk,sdk-ai-message-item,sidebar-vnext,chat-session-affinity,ltm-responding-prompt-tuning-c,topic_continuation_enabled_twice_per_week,trvlflghttf,vertex-timeout,shopping-user-memory-t,fetch-convo,shadowban,update-edge-eu-user-consent-text,genui-tier3-c,genui-ground-counterfactual,discovery-harmony-timestamp,mai-whisper-language-c,gpt51-group-chat,genui-tier4-ground-flight-c,task-notification-no-timeout,shopping-journeys-v2-container-read-c,getcameraimages,web-30s-ping,v3-courteous-wait-c,shopping-feed-thumbs-feedback-toast,conversation-search-region-routing-control,edge-dont-language-switch,upsell-selector,model-training-new-privacy,voice-spatial-info,chainofthoughteventprocessor,chat-message-preview,handle-preview-event,kill-composer-creation-button,smart-mode,smart-mode-6e0b4c6f,smart-mode-cot,smart-mode-flightc,smart-mode-v2-config,searchvideos,searchvideos-google,serpvideocard,video-cards-v2,videocardrespondinginstruction,edge-responder-loop,emit-all-inference-telemetry,responderactions-all"
		",responding-harmony-4o-v4,multi-file-upload,multiple-file-upload,unlimitedfilereasoning,grounded-edit,page-citation,pages-footnote,gpt5-calcite,responding-harmony-gpt5-v1,smart-mode-default,tool-defs-on-separate-system-message,1s-moc-keep-facets,1s-moc-more-msn,1s-wpo-dis-dnewsr,1s-wpo-dis-nopod,discover-gemfive,discover-more-news-content,discover-news-all-large-cards,discover-newsts,discover-threets,think-deeper-cot,finance-follow,finance-watchlist-ui,prg-cmc-flws,prg-cmc-fnav,improve-context-precision,ds-editprompt,ds-new-progress,smart-mode-gpt5,actionspacereducerv2,longqueryfilter,tsrv3_router,enable-history-cache-write,truncatekmessages,responding-harmony-gpt-5-nosearch,responding-harmony-gpt-5-search,placecardnavigationenabled,placecardpromptoptimizationenabled,switcher-harmony,browser-actions,browserautomationcomputeruse,browserautomationsearchweb,edgeactiondisableouter,morefileupload,sidebar-compact-nav-items,sidebar-narrow,searchplaces-enhanced-infos,searchplaces-enhanced-photos,truncatekmessages-k"
		"20,truncatekmessages-n30,pay-ams-integration-server,pay-ams-pdp,pay-ams-price-tracking,pay-ams-product-card,edge-page-safety-check,pii-scrubber,sorttoolrouterresult,relatedresults-android,relatedresults-ios,rrcitationv2,searchmode,see-more-results,toolspacereducerclassifierflight,searchweb-page3,searchweb-sd1000,searchweb-shorter,voice-search-timezone,enrich-web-grounding-with-linkedin-api,entity-info,linkedin-url,person-card-prefer-linkedin,person-cards,edge-security-template,image-ocr-hapi,merge-user-messages,deep-research-summary-v3,dr-cover-image,action-result-relaxed-json-escaping,bingify-sanitized-urls,urls-extracted-infer-event,gpt5-reasoning-harmony,thinkdeeper-gpt5reasoning-harmony-personality,dynamic-answer-cards,indepth-comparison-and-details,warnings-and-clarifications,edu-discovery-cross-sell,study-mode-mico-quiz-tutor,citation-v2,citation-v2-cards,citation-v2-nav,inline-image,inline-video,inline-video-moments,adaptive-citations,adaptive-citations-navigation,pinned-conversation,dynamic-card-sel"
		"ection-instructions,nav-all-turns,nav-cards-on-all-modes,nav-hostqcscore-filter,navigation-curated-enabled,navigation-curation-gpt4o,skip-nav-classifier,generativeui-mvpt3,genui-fiximage,genui-fiximage-12,genui-json-validator,genui-mvp,genui-preturn-refactor,genui-skills,genui-skills-small,genuimvp,searchmode-gpt51-chat-harmony,searchmode-gpt51-promptv2,edge-copilot-screenshot,edge-text-vision,kill-shopping-homepage,shopping-pdp-hide-price-history,shopping-pdp-price-tracking-fallback,sorttoolsbyfrequencyflight,shopping-feed-no-hero-image,shopping-journey-staged-orchestrator,shopping-journeys-debounce,shopping-limit-concurrency,flight-booking-skill,shopping-user-memory,generativeui-flight-status,generativeui-local-events,generativeui-prayer-vertical-timeline,generativeui-sunrise-v2,genui-core,genui-counterfactual,genui-ground-t,genui-grounding-template-selector,genui-tier2-grounding-templates,genui-turncache-templates\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"isNewUser\":false,"
		"\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:"
		"969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306"
		"-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"AppInfo_Version\":\"145.0.3800.82\",\"eventName\":\"edgePendingContextResponses\",\"eventInfo_numMessages\":0}}\n"
		"{\"name\":\"system\",\"time\":\"2026-03-06T07:23:18.346Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":27,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_duration\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BB"
		"CCDD16E182AFC5E06CC216F3A\",\"userFlightIds\":\"imagegenv3,assistant-enable-answer-cards,voice-spatial,weather-cards,edgviswebground,enable-all-app-actions,promptedreasoningcombinedwithsearchpatch,promptmessagewithcards,voices78,allowanonymoususershare,share-chat-page-entry,039add1b-use-fixed-chat-layout,share-image-link,dailybriefing,pages-table,always-show-last-reaction-v2,azureconfigregexblocklist,disable-cmc-auto-reload,onedrive,suggesthangup,correct-personalization-accidental-opt-out,share-campaign,039add1b-chat-sessions-drawer,039add1b-pages-drawer,injectselfharminstructions,039add1b-refresh-token-worker,account-change-chat-reset,preload-chat-messages,1s-moc-logosize,quiz-card-suggestion,send-connected,anonymousattachmentupload,async-disclaimer-text,mem-generate-post-turn,sharecontinue,share-campaign-taeb9y,share-campaign-krq0kf,dr-editprompt-mobile,039add1b-animated-greeting-message-view,greeting-message-animation,image-fallback-thumbnail,adsidsync,think-deeper-regenerate,smart-mode-flightd-edge,narr"
		"-icachuse,img-followup-patch,inject-user-greeting,code-edge-c,videoserp5,searchvideos-bing-fallback,searchimages-bing-fallback,edge-responding-loop-harmony-4o-1010,pay-instacart-canada,quiz-in-create-drawer,deep-research-export-file,m365-conversation-sync,deep-research-export-podcast,multiple,originaldocumentupload,web-multi-fallback-languages,share-campaign-evhqea,share-campaign-rbsrqk,share-campaign-tkzuae,share-campaign-jowp8z,share-campaign-gxcdu3,share-campaign-d2e0f5,share-campaign-dkmev6,share-campaign-coqva4,share-campaign-gez3vb,remove-extra-im-start-context,vision-in-composer-v3,deep-research-nano,export-pages-t,copilot-beta,smart-mode-default-rl,039add1b-uikit-paragraph-view,imagegenv3peakhour,onedrive-fetch,share-continue-v2,ts-dynamic-top-section-t,creator-gallery,old-search-config,thinkdeepero4minichainofthought,image-library-2,image-library-delete-image,igszcls,searchimages-cache,searchvideos-cache,pay-consistent-buy,finance-tooltip-v2,m365-pills-custom,copilot-beta-automatic-opt-in,deep-rese"
		"arch,quiz-option-shuffle,image-cards-v2,test-srm-aa-4,deep-research-promo-card,recipe-card,finance-watchlist-v2,finance-crypto,mutesuggestions,pages-link-navigation,pages-skip-page-selector,pages-file-upload,pages-suggested-followups,onedrive-graph,rm-relatedqna,dr-web-upd-w,dr-pro-nano,pay-getbuyoption-migration,pay-getrecipe-migration,pay-price-tracked,pay-shopify-checkout,sports-cards,smart-mode-reason-chat,pages-reasoning-gg,edge-autosuggest,composer-v4,039add1b-sentry-hang-rate-v2,voice-improved-courtesy-wait,quiz-harmony,sticky-conversation-mode,smart-mode-ensemble-switcher,t1_tsrv3_router,title-generation-harmony,pay-conversion-tracking,history-truncation-fix-parent,backstoryinsertall,local-cards,smart-mode-with-hapi,optimized-responding-for-cache,clarity-http-endpoint,share-image-continue,sharemanagement,labs-audio-expression-style-list-layout,nosearchimageonattachment,start-retry,ui-kit-paragraph-view-2,m365-cela-sheet,placecardprompclean-v3,title-generation-v2,eea-personalization-waiting-period,us"
		"eggvisionmodel,study-mode,searchimages-safe,searchvideos-safe,edge-reload-tab,attachment-suggestions-c,vision-biometric-consent,page-title-generation-v2,kill-picasso-id-on-start,zircon-flight-t,browser-actions-09092025,share-campaign-ferk5z,search-pcm,detailedpromptmetrics,file-upload-config,sidebar-settings,placecard-enhance-all,n-30-k-20,pay-ams-treatment,ceo-harmony,finance-chart-clickthrough,labs-audio-expression-scripted-mode,labs-audio-expression-mode-coachmark,labs-audio-expression-story-voice-selector,thinkdeeper5reasoningloweffort,page-title-generation-hapi,skip-preview-event,m365-pills-data-v2,labs-audio-expression-auto-style,edgevision-multitab,flash-cards,finance-earnings,page-safety-check-treatment,analyzedocuments-extendedtokens,labs-audio-expression-preset-card-fixed,lazy-with-retry,sorttoolrouterresult-others-t,character-cognitive-testing-service,voice-flower-bg,thinkdeeper5miniloweffortchainofthought,image-dynamic-width,group-conversations,share-to-invite,deep-research-share-link,cot-output"
		"-panel,imagegen-galleryremixquota,place-near-me-fix,related-results-t1,tru-router,pay-migrate-get-checkout-option-v2,voice-safety-patch,uselongcontextmodel,kill-regenerate,speechtranscribev2,browser-automation-inc-max-loop,thinkdeeper-truncator,search-truncation,backstory-trim,suppress-inline-link-nav-dialog,voice-time-formatting,balancedfiletokens,empty-tool-instruction,think-deeper-move-tool-instructions,heycopilot-backstory,vad-buffer,pay-edge-clarity,dr-progress,labs-audio-expression-story-image,remix-suggestions,ceo-remove-search-web,healthcare-safety-patch-v3,person-card,edge-safety-prompt-treatment,share-conversation-with-attachments,image-upload-mmt,dr-summary,cross-selling-t-gpt52,ceo-optimized-loop,podcast-in-voice,track-oldest-merged-message,mem-clean-forget,url-output-sanitization,gpt5-reasoning-harmony-personality-v1,config-responder-option-by-modelname,responding-loop-for-vision-model,reduce-vision-usage,dynamic-answer-cards-ga,dr-outlinks,quiz-instant-feedback,gpt-5-on-quick-mode,safety-middl"
		"eware,ceo-filedownload,hide-feedback-if-no-mic-permission-on-end-call,auth-assertion,connector-consent-v2,existing-teen-enabled,voice-clear-audio-capture-listeners-on-end,dr-shared-orchestrator,memory-settings-v2,election-patch,pagecreation,add-utm-source,warnings-indepth,model-migration,route-chat-to-agent,browser-automation-instruction-gpt5,group-conversations-lazy-creation,reduce-memory-overtriggering,image-model-selector-summary,utm-tracking-use-copilot-com,checkmark-emoji-fix,groupchatnotifications,upfront-persistence,groupchat-mentions,edu-cross-sell,browser-actions-charapita,contextual-suggestions,subs-redirect-to-cmc,cef,voice-new-feedback-string,reject-tier4-start-traffic,time-patch,challenge-asn,min-adaptive-citation-t-nav,cloudflare-challenge,chat-recovery-long-streaming-timeout,enable-audio-capture-worklet,voice-memory-edf,reuse-audio-context-for-voice-output,enable-audio-out-pre-buffering-c,socket-close-track,local-inference-client-side-lb,auth0-based-user-link,knowledge-extraction-harmony,rout"
		"er-default-preload-intent,hide-conversation-dates,remove-qr,edge-shopping-enable-all-markets,deprecate_widgets_v1,edge-page-sanitization,teen-compliance,edge-ctx-consent-tool-executing,skip-reasoning-in-smart-mode,chat-client-retry,labs-remote-config,voice-name-repetition-fix,ltm-backfill-disabled,skip-append-last-user-message-again,framework-conversation-write,email-reply,voice-enable-new-audio-icon-c,backstorytool,block-image-generation-in-voice,increase-doc-attachment-max-tokens,nav-expand-all-t,remove-clarifying-prompts,readaloud-verbatim-prompt,kill-contextual-suggestions-tabs-check,podcast-project-sources-grounding,edf-store-direct-instruction,naa-has-active-account-check,computeruse-raw-cot,reduce-memory-overtrigger-location-c,search-uploaded-docs-in-project,mem-skip-preview-search,genuiskillssmallf12,searchmode-t2,browser-actions-detailed-summary,generate-flashcard-skill,browser-actions-deprecated-non-charapita,proactive-message-additional-context,searchfinance-searchquery,group-conversations-reuse-"
		"conv-id,voice-enable-read-aloud-c,edge-text-vision-treatment,max-adaptive-citations-c,user-message-copy,match-message-timestamp,edge-tab-safety-cache,voice-telemetry,m365-wxp-history-sync,kill-shopping-homepage-t,nav-card-short-url,kill-projects-creations-flash-card,computer-agent-skills,browser-remote-actions-for-tasks,conversation-compactor,planning-agent-elicitation,spd-citation-v2-mixed-format,agent-snapshots,group-conversations-unread-indicator,gpt52-reasoning-harmony,superbowl-search,autoprompt-off,earcon-only-after-first-use,voice-restart-telemetry,subs-hot-reload,jailbreakdisabled,pdp-track-price-comp-t,olympics-search,supersonic-task-preview,edf-memory-tuning,task-memory,trs-update-flight,block-document-generation-in-voice,task-notification,shopping-journeys-v2-container,shopping-feed-no-hero-image-t,fix-ftr,discovery-long-summary,avoid-edge-vision-highlight,agent-manager-registry,dicf6867,audioagent-v3,lm-arena-v2,windows-vision-highlights,journeys-generation-v2-t,shopping-jump-back-to-conversatio"
		"n-c,studio-sdk,sdk-ai-message-item,sidebar-vnext,chat-session-affinity,ltm-responding-prompt-tuning-c,topic_continuation_enabled_twice_per_week,trvlflghttf,vertex-timeout,shopping-user-memory-t,fetch-convo,shadowban,update-edge-eu-user-consent-text,genui-tier3-c,genui-ground-counterfactual,discovery-harmony-timestamp,mai-whisper-language-c,gpt51-group-chat,genui-tier4-ground-flight-c,task-notification-no-timeout,shopping-journeys-v2-container-read-c,getcameraimages,web-30s-ping,v3-courteous-wait-c,shopping-feed-thumbs-feedback-toast,conversation-search-region-routing-control,edge-dont-language-switch,upsell-selector,model-training-new-privacy,voice-spatial-info,chainofthoughteventprocessor,chat-message-preview,handle-preview-event,kill-composer-creation-button,smart-mode,smart-mode-6e0b4c6f,smart-mode-cot,smart-mode-flightc,smart-mode-v2-config,searchvideos,searchvideos-google,serpvideocard,video-cards-v2,videocardrespondinginstruction,edge-responder-loop,emit-all-inference-telemetry,responderactions-all,re"
		"sponding-harmony-4o-v4,multi-file-upload,multiple-file-upload,unlimitedfilereasoning,grounded-edit,page-citation,pages-footnote,gpt5-calcite,responding-harmony-gpt5-v1,smart-mode-default,tool-defs-on-separate-system-message,1s-moc-keep-facets,1s-moc-more-msn,1s-wpo-dis-dnewsr,1s-wpo-dis-nopod,discover-gemfive,discover-more-news-content,discover-news-all-large-cards,discover-newsts,discover-threets,think-deeper-cot,finance-follow,finance-watchlist-ui,prg-cmc-flws,prg-cmc-fnav,improve-context-precision,ds-editprompt,ds-new-progress,smart-mode-gpt5,actionspacereducerv2,longqueryfilter,tsrv3_router,enable-history-cache-write,truncatekmessages,responding-harmony-gpt-5-nosearch,responding-harmony-gpt-5-search,placecardnavigationenabled,placecardpromptoptimizationenabled,switcher-harmony,browser-actions,browserautomationcomputeruse,browserautomationsearchweb,edgeactiondisableouter,morefileupload,sidebar-compact-nav-items,sidebar-narrow,searchplaces-enhanced-infos,searchplaces-enhanced-photos,truncatekmessages-k20,"
		"truncatekmessages-n30,pay-ams-integration-server,pay-ams-pdp,pay-ams-price-tracking,pay-ams-product-card,edge-page-safety-check,pii-scrubber,sorttoolrouterresult,relatedresults-android,relatedresults-ios,rrcitationv2,searchmode,see-more-results,toolspacereducerclassifierflight,searchweb-page3,searchweb-sd1000,searchweb-shorter,voice-search-timezone,enrich-web-grounding-with-linkedin-api,entity-info,linkedin-url,person-card-prefer-linkedin,person-cards,edge-security-template,image-ocr-hapi,merge-user-messages,deep-research-summary-v3,dr-cover-image,action-result-relaxed-json-escaping,bingify-sanitized-urls,urls-extracted-infer-event,gpt5-reasoning-harmony,thinkdeeper-gpt5reasoning-harmony-personality,dynamic-answer-cards,indepth-comparison-and-details,warnings-and-clarifications,edu-discovery-cross-sell,study-mode-mico-quiz-tutor,citation-v2,citation-v2-cards,citation-v2-nav,inline-image,inline-video,inline-video-moments,adaptive-citations,adaptive-citations-navigation,pinned-conversation,dynamic-card-select"
		"ion-instructions,nav-all-turns,nav-cards-on-all-modes,nav-hostqcscore-filter,navigation-curated-enabled,navigation-curation-gpt4o,skip-nav-classifier,generativeui-mvpt3,genui-fiximage,genui-fiximage-12,genui-json-validator,genui-mvp,genui-preturn-refactor,genui-skills,genui-skills-small,genuimvp,searchmode-gpt51-chat-harmony,searchmode-gpt51-promptv2,edge-copilot-screenshot,edge-text-vision,kill-shopping-homepage,shopping-pdp-hide-price-history,shopping-pdp-price-tracking-fallback,sorttoolsbyfrequencyflight,shopping-feed-no-hero-image,shopping-journey-staged-orchestrator,shopping-journeys-debounce,shopping-limit-concurrency,flight-booking-skill,shopping-user-memory,generativeui-flight-status,generativeui-local-events,generativeui-prayer-vertical-timeline,generativeui-sunrise-v2,genui-core,genui-counterfactual,genui-ground-t,genui-grounding-template-selector,genui-tier2-grounding-templates,genui-turncache-templates\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"isNewUser\":false,\"pa"
		"thname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:9699"
		"12,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-1"
		"8,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"AppInfo_Version\":\"145.0.3800.82\",\"eventName\":\"copilotFeatureLatency\",\"eventInfo_scenario\":\"UseStartLatency\",\"eventInfo_duration\":5638.199999928474,\"eventInfo_customData\":\"{\\\\\"success\\\\\":true}\"}}\n"
		"{\"name\":\"system\",\"time\":\"2026-03-06T07:23:18.444Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":28,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBCCDD16E182AFC5E06CC216F3A\",\"userFlightIds\":\"imagegen"
		"v3,assistant-enable-answer-cards,voice-spatial,weather-cards,edgviswebground,enable-all-app-actions,promptedreasoningcombinedwithsearchpatch,promptmessagewithcards,voices78,allowanonymoususershare,share-chat-page-entry,039add1b-use-fixed-chat-layout,share-image-link,dailybriefing,pages-table,always-show-last-reaction-v2,azureconfigregexblocklist,disable-cmc-auto-reload,onedrive,suggesthangup,correct-personalization-accidental-opt-out,share-campaign,039add1b-chat-sessions-drawer,039add1b-pages-drawer,injectselfharminstructions,039add1b-refresh-token-worker,account-change-chat-reset,preload-chat-messages,1s-moc-logosize,quiz-card-suggestion,send-connected,anonymousattachmentupload,async-disclaimer-text,mem-generate-post-turn,sharecontinue,share-campaign-taeb9y,share-campaign-krq0kf,dr-editprompt-mobile,039add1b-animated-greeting-message-view,greeting-message-animation,image-fallback-thumbnail,adsidsync,think-deeper-regenerate,smart-mode-flightd-edge,narr-icachuse,img-followup-patch,inject-user-greeting,code-e"
		"dge-c,videoserp5,searchvideos-bing-fallback,searchimages-bing-fallback,edge-responding-loop-harmony-4o-1010,pay-instacart-canada,quiz-in-create-drawer,deep-research-export-file,m365-conversation-sync,deep-research-export-podcast,multiple,originaldocumentupload,web-multi-fallback-languages,share-campaign-evhqea,share-campaign-rbsrqk,share-campaign-tkzuae,share-campaign-jowp8z,share-campaign-gxcdu3,share-campaign-d2e0f5,share-campaign-dkmev6,share-campaign-coqva4,share-campaign-gez3vb,remove-extra-im-start-context,vision-in-composer-v3,deep-research-nano,export-pages-t,copilot-beta,smart-mode-default-rl,039add1b-uikit-paragraph-view,imagegenv3peakhour,onedrive-fetch,share-continue-v2,ts-dynamic-top-section-t,creator-gallery,old-search-config,thinkdeepero4minichainofthought,image-library-2,image-library-delete-image,igszcls,searchimages-cache,searchvideos-cache,pay-consistent-buy,finance-tooltip-v2,m365-pills-custom,copilot-beta-automatic-opt-in,deep-research,quiz-option-shuffle,image-cards-v2,test-srm-aa-4,de"
		"ep-research-promo-card,recipe-card,finance-watchlist-v2,finance-crypto,mutesuggestions,pages-link-navigation,pages-skip-page-selector,pages-file-upload,pages-suggested-followups,onedrive-graph,rm-relatedqna,dr-web-upd-w,dr-pro-nano,pay-getbuyoption-migration,pay-getrecipe-migration,pay-price-tracked,pay-shopify-checkout,sports-cards,smart-mode-reason-chat,pages-reasoning-gg,edge-autosuggest,composer-v4,039add1b-sentry-hang-rate-v2,voice-improved-courtesy-wait,quiz-harmony,sticky-conversation-mode,smart-mode-ensemble-switcher,t1_tsrv3_router,title-generation-harmony,pay-conversion-tracking,history-truncation-fix-parent,backstoryinsertall,local-cards,smart-mode-with-hapi,optimized-responding-for-cache,clarity-http-endpoint,share-image-continue,sharemanagement,labs-audio-expression-style-list-layout,nosearchimageonattachment,start-retry,ui-kit-paragraph-view-2,m365-cela-sheet,placecardprompclean-v3,title-generation-v2,eea-personalization-waiting-period,useggvisionmodel,study-mode,searchimages-safe,searchvideos"
		"-safe,edge-reload-tab,attachment-suggestions-c,vision-biometric-consent,page-title-generation-v2,kill-picasso-id-on-start,zircon-flight-t,browser-actions-09092025,share-campaign-ferk5z,search-pcm,detailedpromptmetrics,file-upload-config,sidebar-settings,placecard-enhance-all,n-30-k-20,pay-ams-treatment,ceo-harmony,finance-chart-clickthrough,labs-audio-expression-scripted-mode,labs-audio-expression-mode-coachmark,labs-audio-expression-story-voice-selector,thinkdeeper5reasoningloweffort,page-title-generation-hapi,skip-preview-event,m365-pills-data-v2,labs-audio-expression-auto-style,edgevision-multitab,flash-cards,finance-earnings,page-safety-check-treatment,analyzedocuments-extendedtokens,labs-audio-expression-preset-card-fixed,lazy-with-retry,sorttoolrouterresult-others-t,character-cognitive-testing-service,voice-flower-bg,thinkdeeper5miniloweffortchainofthought,image-dynamic-width,group-conversations,share-to-invite,deep-research-share-link,cot-output-panel,imagegen-galleryremixquota,place-near-me-fix,rela"
		"ted-results-t1,tru-router,pay-migrate-get-checkout-option-v2,voice-safety-patch,uselongcontextmodel,kill-regenerate,speechtranscribev2,browser-automation-inc-max-loop,thinkdeeper-truncator,search-truncation,backstory-trim,suppress-inline-link-nav-dialog,voice-time-formatting,balancedfiletokens,empty-tool-instruction,think-deeper-move-tool-instructions,heycopilot-backstory,vad-buffer,pay-edge-clarity,dr-progress,labs-audio-expression-story-image,remix-suggestions,ceo-remove-search-web,healthcare-safety-patch-v3,person-card,edge-safety-prompt-treatment,share-conversation-with-attachments,image-upload-mmt,dr-summary,cross-selling-t-gpt52,ceo-optimized-loop,podcast-in-voice,track-oldest-merged-message,mem-clean-forget,url-output-sanitization,gpt5-reasoning-harmony-personality-v1,config-responder-option-by-modelname,responding-loop-for-vision-model,reduce-vision-usage,dynamic-answer-cards-ga,dr-outlinks,quiz-instant-feedback,gpt-5-on-quick-mode,safety-middleware,ceo-filedownload,hide-feedback-if-no-mic-permissio"
		"n-on-end-call,auth-assertion,connector-consent-v2,existing-teen-enabled,voice-clear-audio-capture-listeners-on-end,dr-shared-orchestrator,memory-settings-v2,election-patch,pagecreation,add-utm-source,warnings-indepth,model-migration,route-chat-to-agent,browser-automation-instruction-gpt5,group-conversations-lazy-creation,reduce-memory-overtriggering,image-model-selector-summary,utm-tracking-use-copilot-com,checkmark-emoji-fix,groupchatnotifications,upfront-persistence,groupchat-mentions,edu-cross-sell,browser-actions-charapita,contextual-suggestions,subs-redirect-to-cmc,cef,voice-new-feedback-string,reject-tier4-start-traffic,time-patch,challenge-asn,min-adaptive-citation-t-nav,cloudflare-challenge,chat-recovery-long-streaming-timeout,enable-audio-capture-worklet,voice-memory-edf,reuse-audio-context-for-voice-output,enable-audio-out-pre-buffering-c,socket-close-track,local-inference-client-side-lb,auth0-based-user-link,knowledge-extraction-harmony,router-default-preload-intent,hide-conversation-dates,remove"
		"-qr,edge-shopping-enable-all-markets,deprecate_widgets_v1,edge-page-sanitization,teen-compliance,edge-ctx-consent-tool-executing,skip-reasoning-in-smart-mode,chat-client-retry,labs-remote-config,voice-name-repetition-fix,ltm-backfill-disabled,skip-append-last-user-message-again,framework-conversation-write,email-reply,voice-enable-new-audio-icon-c,backstorytool,block-image-generation-in-voice,increase-doc-attachment-max-tokens,nav-expand-all-t,remove-clarifying-prompts,readaloud-verbatim-prompt,kill-contextual-suggestions-tabs-check,podcast-project-sources-grounding,edf-store-direct-instruction,naa-has-active-account-check,computeruse-raw-cot,reduce-memory-overtrigger-location-c,search-uploaded-docs-in-project,mem-skip-preview-search,genuiskillssmallf12,searchmode-t2,browser-actions-detailed-summary,generate-flashcard-skill,browser-actions-deprecated-non-charapita,proactive-message-additional-context,searchfinance-searchquery,group-conversations-reuse-conv-id,voice-enable-read-aloud-c,edge-text-vision-treat"
		"ment,max-adaptive-citations-c,user-message-copy,match-message-timestamp,edge-tab-safety-cache,voice-telemetry,m365-wxp-history-sync,kill-shopping-homepage-t,nav-card-short-url,kill-projects-creations-flash-card,computer-agent-skills,browser-remote-actions-for-tasks,conversation-compactor,planning-agent-elicitation,spd-citation-v2-mixed-format,agent-snapshots,group-conversations-unread-indicator,gpt52-reasoning-harmony,superbowl-search,autoprompt-off,earcon-only-after-first-use,voice-restart-telemetry,subs-hot-reload,jailbreakdisabled,pdp-track-price-comp-t,olympics-search,supersonic-task-preview,edf-memory-tuning,task-memory,trs-update-flight,block-document-generation-in-voice,task-notification,shopping-journeys-v2-container,shopping-feed-no-hero-image-t,fix-ftr,discovery-long-summary,avoid-edge-vision-highlight,agent-manager-registry,dicf6867,audioagent-v3,lm-arena-v2,windows-vision-highlights,journeys-generation-v2-t,shopping-jump-back-to-conversation-c,studio-sdk,sdk-ai-message-item,sidebar-vnext,chat-se"
		"ssion-affinity,ltm-responding-prompt-tuning-c,topic_continuation_enabled_twice_per_week,trvlflghttf,vertex-timeout,shopping-user-memory-t,fetch-convo,shadowban,update-edge-eu-user-consent-text,genui-tier3-c,genui-ground-counterfactual,discovery-harmony-timestamp,mai-whisper-language-c,gpt51-group-chat,genui-tier4-ground-flight-c,task-notification-no-timeout,shopping-journeys-v2-container-read-c,getcameraimages,web-30s-ping,v3-courteous-wait-c,shopping-feed-thumbs-feedback-toast,conversation-search-region-routing-control,edge-dont-language-switch,upsell-selector,model-training-new-privacy,voice-spatial-info,chainofthoughteventprocessor,chat-message-preview,handle-preview-event,kill-composer-creation-button,smart-mode,smart-mode-6e0b4c6f,smart-mode-cot,smart-mode-flightc,smart-mode-v2-config,searchvideos,searchvideos-google,serpvideocard,video-cards-v2,videocardrespondinginstruction,edge-responder-loop,emit-all-inference-telemetry,responderactions-all,responding-harmony-4o-v4,multi-file-upload,multiple-file-u"
		"pload,unlimitedfilereasoning,grounded-edit,page-citation,pages-footnote,gpt5-calcite,responding-harmony-gpt5-v1,smart-mode-default,tool-defs-on-separate-system-message,1s-moc-keep-facets,1s-moc-more-msn,1s-wpo-dis-dnewsr,1s-wpo-dis-nopod,discover-gemfive,discover-more-news-content,discover-news-all-large-cards,discover-newsts,discover-threets,think-deeper-cot,finance-follow,finance-watchlist-ui,prg-cmc-flws,prg-cmc-fnav,improve-context-precision,ds-editprompt,ds-new-progress,smart-mode-gpt5,actionspacereducerv2,longqueryfilter,tsrv3_router,enable-history-cache-write,truncatekmessages,responding-harmony-gpt-5-nosearch,responding-harmony-gpt-5-search,placecardnavigationenabled,placecardpromptoptimizationenabled,switcher-harmony,browser-actions,browserautomationcomputeruse,browserautomationsearchweb,edgeactiondisableouter,morefileupload,sidebar-compact-nav-items,sidebar-narrow,searchplaces-enhanced-infos,searchplaces-enhanced-photos,truncatekmessages-k20,truncatekmessages-n30,pay-ams-integration-server,pay-ams"
		"-pdp,pay-ams-price-tracking,pay-ams-product-card,edge-page-safety-check,pii-scrubber,sorttoolrouterresult,relatedresults-android,relatedresults-ios,rrcitationv2,searchmode,see-more-results,toolspacereducerclassifierflight,searchweb-page3,searchweb-sd1000,searchweb-shorter,voice-search-timezone,enrich-web-grounding-with-linkedin-api,entity-info,linkedin-url,person-card-prefer-linkedin,person-cards,edge-security-template,image-ocr-hapi,merge-user-messages,deep-research-summary-v3,dr-cover-image,action-result-relaxed-json-escaping,bingify-sanitized-urls,urls-extracted-infer-event,gpt5-reasoning-harmony,thinkdeeper-gpt5reasoning-harmony-personality,dynamic-answer-cards,indepth-comparison-and-details,warnings-and-clarifications,edu-discovery-cross-sell,study-mode-mico-quiz-tutor,citation-v2,citation-v2-cards,citation-v2-nav,inline-image,inline-video,inline-video-moments,adaptive-citations,adaptive-citations-navigation,pinned-conversation,dynamic-card-selection-instructions,nav-all-turns,nav-cards-on-all-modes,na"
		"v-hostqcscore-filter,navigation-curated-enabled,navigation-curation-gpt4o,skip-nav-classifier,generativeui-mvpt3,genui-fiximage,genui-fiximage-12,genui-json-validator,genui-mvp,genui-preturn-refactor,genui-skills,genui-skills-small,genuimvp,searchmode-gpt51-chat-harmony,searchmode-gpt51-promptv2,edge-copilot-screenshot,edge-text-vision,kill-shopping-homepage,shopping-pdp-hide-price-history,shopping-pdp-price-tracking-fallback,sorttoolsbyfrequencyflight,shopping-feed-no-hero-image,shopping-journey-staged-orchestrator,shopping-journeys-debounce,shopping-limit-concurrency,flight-booking-skill,shopping-user-memory,generativeui-flight-status,generativeui-local-events,generativeui-prayer-vertical-timeline,generativeui-sunrise-v2,genui-core,genui-counterfactual,genui-ground-t,genui-grounding-template-selector,genui-tier2-grounding-templates,genui-turncache-templates\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"isNewUser\":false,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"c"
		"hromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298"
		"exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-"
		"3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"AppInfo_Version\":\"145.0.3800.82\",\"eventName\":\"copilotImpression\",\"eventInfo_impressionScenario\":\"smart\",\"eventInfo_impressionPage\":\"chatPage\",\"eventInfo_impressionElement\":\"composerModeButton\"}}" ;
 
const char * const body_variable_2 = "BodyBinary={\"name\":\"apiresponse\",\"time\":\"2026-03-06T07:23:18.481Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":29,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_status\":{\"t\":6},\"eventInfo_duration\":{\"t\":6},\"eventInfo_responseContentLength\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surfa"
		"ce\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBCCDD16E182AFC5E06CC216F3A\",\"userFlightIds\":\"imagegenv3,assistant-enable-answer-cards,voice-spatial,weather-cards,edgviswebground,enable-all-app-actions,promptedreasoningcombinedwithsearchpatch,promptmessagewithcards,voices78,allowanonymoususershare,share-chat-page-entry,039add1b-use-fixed-chat-layout,share-image-link,dailybriefing,pages-table,always-show-last-reaction-v2,azureconfigregexblocklist,disable-cmc-auto-reload,onedrive,suggesthangup,correct-personalization-accidental-opt-out,share-campaign,039add1b-chat-sessions-drawer,039add1b-pages-drawer,injectselfharminstructions,039add1b-refresh-token-worker,account-change-chat-reset,preload-chat-messages,1s-moc-logosize,quiz-card-suggestion,send-connected,anonymousattachmentupload,async-disclaimer-text,mem-generate-post-turn,sharecontinue,share-campaign-taeb9y,share-campaign-krq0kf,dr-editprompt-mobile,039add1b-animated-greeting-message-view,greeting-message-anima"
		"tion,image-fallback-thumbnail,adsidsync,think-deeper-regenerate,smart-mode-flightd-edge,narr-icachuse,img-followup-patch,inject-user-greeting,code-edge-c,videoserp5,searchvideos-bing-fallback,searchimages-bing-fallback,edge-responding-loop-harmony-4o-1010,pay-instacart-canada,quiz-in-create-drawer,deep-research-export-file,m365-conversation-sync,deep-research-export-podcast,multiple,originaldocumentupload,web-multi-fallback-languages,share-campaign-evhqea,share-campaign-rbsrqk,share-campaign-tkzuae,share-campaign-jowp8z,share-campaign-gxcdu3,share-campaign-d2e0f5,share-campaign-dkmev6,share-campaign-coqva4,share-campaign-gez3vb,remove-extra-im-start-context,vision-in-composer-v3,deep-research-nano,export-pages-t,copilot-beta,smart-mode-default-rl,039add1b-uikit-paragraph-view,imagegenv3peakhour,onedrive-fetch,share-continue-v2,ts-dynamic-top-section-t,creator-gallery,old-search-config,thinkdeepero4minichainofthought,image-library-2,image-library-delete-image,igszcls,searchimages-cache,searchvideos-cache,pay"
		"-consistent-buy,finance-tooltip-v2,m365-pills-custom,copilot-beta-automatic-opt-in,deep-research,quiz-option-shuffle,image-cards-v2,test-srm-aa-4,deep-research-promo-card,recipe-card,finance-watchlist-v2,finance-crypto,mutesuggestions,pages-link-navigation,pages-skip-page-selector,pages-file-upload,pages-suggested-followups,onedrive-graph,rm-relatedqna,dr-web-upd-w,dr-pro-nano,pay-getbuyoption-migration,pay-getrecipe-migration,pay-price-tracked,pay-shopify-checkout,sports-cards,smart-mode-reason-chat,pages-reasoning-gg,edge-autosuggest,composer-v4,039add1b-sentry-hang-rate-v2,voice-improved-courtesy-wait,quiz-harmony,sticky-conversation-mode,smart-mode-ensemble-switcher,t1_tsrv3_router,title-generation-harmony,pay-conversion-tracking,history-truncation-fix-parent,backstoryinsertall,local-cards,smart-mode-with-hapi,optimized-responding-for-cache,clarity-http-endpoint,share-image-continue,sharemanagement,labs-audio-expression-style-list-layout,nosearchimageonattachment,start-retry,ui-kit-paragraph-view-2,m365"
		"-cela-sheet,placecardprompclean-v3,title-generation-v2,eea-personalization-waiting-period,useggvisionmodel,study-mode,searchimages-safe,searchvideos-safe,edge-reload-tab,attachment-suggestions-c,vision-biometric-consent,page-title-generation-v2,kill-picasso-id-on-start,zircon-flight-t,browser-actions-09092025,share-campaign-ferk5z,search-pcm,detailedpromptmetrics,file-upload-config,sidebar-settings,placecard-enhance-all,n-30-k-20,pay-ams-treatment,ceo-harmony,finance-chart-clickthrough,labs-audio-expression-scripted-mode,labs-audio-expression-mode-coachmark,labs-audio-expression-story-voice-selector,thinkdeeper5reasoningloweffort,page-title-generation-hapi,skip-preview-event,m365-pills-data-v2,labs-audio-expression-auto-style,edgevision-multitab,flash-cards,finance-earnings,page-safety-check-treatment,analyzedocuments-extendedtokens,labs-audio-expression-preset-card-fixed,lazy-with-retry,sorttoolrouterresult-others-t,character-cognitive-testing-service,voice-flower-bg,thinkdeeper5miniloweffortchainofthought"
		",image-dynamic-width,group-conversations,share-to-invite,deep-research-share-link,cot-output-panel,imagegen-galleryremixquota,place-near-me-fix,related-results-t1,tru-router,pay-migrate-get-checkout-option-v2,voice-safety-patch,uselongcontextmodel,kill-regenerate,speechtranscribev2,browser-automation-inc-max-loop,thinkdeeper-truncator,search-truncation,backstory-trim,suppress-inline-link-nav-dialog,voice-time-formatting,balancedfiletokens,empty-tool-instruction,think-deeper-move-tool-instructions,heycopilot-backstory,vad-buffer,pay-edge-clarity,dr-progress,labs-audio-expression-story-image,remix-suggestions,ceo-remove-search-web,healthcare-safety-patch-v3,person-card,edge-safety-prompt-treatment,share-conversation-with-attachments,image-upload-mmt,dr-summary,cross-selling-t-gpt52,ceo-optimized-loop,podcast-in-voice,track-oldest-merged-message,mem-clean-forget,url-output-sanitization,gpt5-reasoning-harmony-personality-v1,config-responder-option-by-modelname,responding-loop-for-vision-model,reduce-vision-usag"
		"e,dynamic-answer-cards-ga,dr-outlinks,quiz-instant-feedback,gpt-5-on-quick-mode,safety-middleware,ceo-filedownload,hide-feedback-if-no-mic-permission-on-end-call,auth-assertion,connector-consent-v2,existing-teen-enabled,voice-clear-audio-capture-listeners-on-end,dr-shared-orchestrator,memory-settings-v2,election-patch,pagecreation,add-utm-source,warnings-indepth,model-migration,route-chat-to-agent,browser-automation-instruction-gpt5,group-conversations-lazy-creation,reduce-memory-overtriggering,image-model-selector-summary,utm-tracking-use-copilot-com,checkmark-emoji-fix,groupchatnotifications,upfront-persistence,groupchat-mentions,edu-cross-sell,browser-actions-charapita,contextual-suggestions,subs-redirect-to-cmc,cef,voice-new-feedback-string,reject-tier4-start-traffic,time-patch,challenge-asn,min-adaptive-citation-t-nav,cloudflare-challenge,chat-recovery-long-streaming-timeout,enable-audio-capture-worklet,voice-memory-edf,reuse-audio-context-for-voice-output,enable-audio-out-pre-buffering-c,socket-close-"
		"track,local-inference-client-side-lb,auth0-based-user-link,knowledge-extraction-harmony,router-default-preload-intent,hide-conversation-dates,remove-qr,edge-shopping-enable-all-markets,deprecate_widgets_v1,edge-page-sanitization,teen-compliance,edge-ctx-consent-tool-executing,skip-reasoning-in-smart-mode,chat-client-retry,labs-remote-config,voice-name-repetition-fix,ltm-backfill-disabled,skip-append-last-user-message-again,framework-conversation-write,email-reply,voice-enable-new-audio-icon-c,backstorytool,block-image-generation-in-voice,increase-doc-attachment-max-tokens,nav-expand-all-t,remove-clarifying-prompts,readaloud-verbatim-prompt,kill-contextual-suggestions-tabs-check,podcast-project-sources-grounding,edf-store-direct-instruction,naa-has-active-account-check,computeruse-raw-cot,reduce-memory-overtrigger-location-c,search-uploaded-docs-in-project,mem-skip-preview-search,genuiskillssmallf12,searchmode-t2,browser-actions-detailed-summary,generate-flashcard-skill,browser-actions-deprecated-non-charapi"
		"ta,proactive-message-additional-context,searchfinance-searchquery,group-conversations-reuse-conv-id,voice-enable-read-aloud-c,edge-text-vision-treatment,max-adaptive-citations-c,user-message-copy,match-message-timestamp,edge-tab-safety-cache,voice-telemetry,m365-wxp-history-sync,kill-shopping-homepage-t,nav-card-short-url,kill-projects-creations-flash-card,computer-agent-skills,browser-remote-actions-for-tasks,conversation-compactor,planning-agent-elicitation,spd-citation-v2-mixed-format,agent-snapshots,group-conversations-unread-indicator,gpt52-reasoning-harmony,superbowl-search,autoprompt-off,earcon-only-after-first-use,voice-restart-telemetry,subs-hot-reload,jailbreakdisabled,pdp-track-price-comp-t,olympics-search,supersonic-task-preview,edf-memory-tuning,task-memory,trs-update-flight,block-document-generation-in-voice,task-notification,shopping-journeys-v2-container,shopping-feed-no-hero-image-t,fix-ftr,discovery-long-summary,avoid-edge-vision-highlight,agent-manager-registry,dicf6867,audioagent-v3,lm-a"
		"rena-v2,windows-vision-highlights,journeys-generation-v2-t,shopping-jump-back-to-conversation-c,studio-sdk,sdk-ai-message-item,sidebar-vnext,chat-session-affinity,ltm-responding-prompt-tuning-c,topic_continuation_enabled_twice_per_week,trvlflghttf,vertex-timeout,shopping-user-memory-t,fetch-convo,shadowban,update-edge-eu-user-consent-text,genui-tier3-c,genui-ground-counterfactual,discovery-harmony-timestamp,mai-whisper-language-c,gpt51-group-chat,genui-tier4-ground-flight-c,task-notification-no-timeout,shopping-journeys-v2-container-read-c,getcameraimages,web-30s-ping,v3-courteous-wait-c,shopping-feed-thumbs-feedback-toast,conversation-search-region-routing-control,edge-dont-language-switch,upsell-selector,model-training-new-privacy,voice-spatial-info,chainofthoughteventprocessor,chat-message-preview,handle-preview-event,kill-composer-creation-button,smart-mode,smart-mode-6e0b4c6f,smart-mode-cot,smart-mode-flightc,smart-mode-v2-config,searchvideos,searchvideos-google,serpvideocard,video-cards-v2,videocardre"
		"spondinginstruction,edge-responder-loop,emit-all-inference-telemetry,responderactions-all,responding-harmony-4o-v4,multi-file-upload,multiple-file-upload,unlimitedfilereasoning,grounded-edit,page-citation,pages-footnote,gpt5-calcite,responding-harmony-gpt5-v1,smart-mode-default,tool-defs-on-separate-system-message,1s-moc-keep-facets,1s-moc-more-msn,1s-wpo-dis-dnewsr,1s-wpo-dis-nopod,discover-gemfive,discover-more-news-content,discover-news-all-large-cards,discover-newsts,discover-threets,think-deeper-cot,finance-follow,finance-watchlist-ui,prg-cmc-flws,prg-cmc-fnav,improve-context-precision,ds-editprompt,ds-new-progress,smart-mode-gpt5,actionspacereducerv2,longqueryfilter,tsrv3_router,enable-history-cache-write,truncatekmessages,responding-harmony-gpt-5-nosearch,responding-harmony-gpt-5-search,placecardnavigationenabled,placecardpromptoptimizationenabled,switcher-harmony,browser-actions,browserautomationcomputeruse,browserautomationsearchweb,edgeactiondisableouter,morefileupload,sidebar-compact-nav-items,si"
		"debar-narrow,searchplaces-enhanced-infos,searchplaces-enhanced-photos,truncatekmessages-k20,truncatekmessages-n30,pay-ams-integration-server,pay-ams-pdp,pay-ams-price-tracking,pay-ams-product-card,edge-page-safety-check,pii-scrubber,sorttoolrouterresult,relatedresults-android,relatedresults-ios,rrcitationv2,searchmode,see-more-results,toolspacereducerclassifierflight,searchweb-page3,searchweb-sd1000,searchweb-shorter,voice-search-timezone,enrich-web-grounding-with-linkedin-api,entity-info,linkedin-url,person-card-prefer-linkedin,person-cards,edge-security-template,image-ocr-hapi,merge-user-messages,deep-research-summary-v3,dr-cover-image,action-result-relaxed-json-escaping,bingify-sanitized-urls,urls-extracted-infer-event,gpt5-reasoning-harmony,thinkdeeper-gpt5reasoning-harmony-personality,dynamic-answer-cards,indepth-comparison-and-details,warnings-and-clarifications,edu-discovery-cross-sell,study-mode-mico-quiz-tutor,citation-v2,citation-v2-cards,citation-v2-nav,inline-image,inline-video,inline-video-mome"
		"nts,adaptive-citations,adaptive-citations-navigation,pinned-conversation,dynamic-card-selection-instructions,nav-all-turns,nav-cards-on-all-modes,nav-hostqcscore-filter,navigation-curated-enabled,navigation-curation-gpt4o,skip-nav-classifier,generativeui-mvpt3,genui-fiximage,genui-fiximage-12,genui-json-validator,genui-mvp,genui-preturn-refactor,genui-skills,genui-skills-small,genuimvp,searchmode-gpt51-chat-harmony,searchmode-gpt51-promptv2,edge-copilot-screenshot,edge-text-vision,kill-shopping-homepage,shopping-pdp-hide-price-history,shopping-pdp-price-tracking-fallback,sorttoolsbyfrequencyflight,shopping-feed-no-hero-image,shopping-journey-staged-orchestrator,shopping-journeys-debounce,shopping-limit-concurrency,flight-booking-skill,shopping-user-memory,generativeui-flight-status,generativeui-local-events,generativeui-prayer-vertical-timeline,generativeui-sunrise-v2,genui-core,genui-counterfactual,genui-ground-t,genui-grounding-template-selector,genui-tier2-grounding-templates,genui-turncache-templates\","
		"\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"isNewUser\":false,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treat"
		"ment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-15"
		"99889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"AppInfo_Version\":\"145.0.3800.82\",\"eventName\":\"copilotApiResponse\",\"eventInfo_path\":\"/conversations/*/history\",\"eventInfo_method\":\"GET\",\"eventInfo_status\":200,\"eventInfo_duration\":223.89999997615814,\"eventInfo_responseContentLength\":26,\"eventInfo_xCDNTraceId\":\"9d7f9d43184f6ce0-MAA\",\"eventInfo_server\":\"cloudflare\"}}\n"
		"{\"name\":\"apiresponse\",\"time\":\"2026-03-06T07:23:23.296Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":30,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_status\":{\"t\":6},\"eventInfo_duration\":{\"t\":6},\"eventInfo_responseContentLength\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edg"
		"etab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBCCDD16E182AFC5E06CC216F3A\",\"userFlightIds\":\"imagegenv3,assistant-enable-answer-cards,voice-spatial,weather-cards,edgviswebground,enable-all-app-actions,promptedreasoningcombinedwithsearchpatch,promptmessagewithcards,voices78,allowanonymoususershare,share-chat-page-entry,039add1b-use-fixed-chat-layout,share-image-link,dailybriefing,pages-table,always-show-last-reaction-v2,azureconfigregexblocklist,disable-cmc-auto-reload,onedrive,suggesthangup,correct-personalization-accidental-opt-out,share-campaign,039add1b-chat-sessions-drawer,039add1b-pages-drawer,injectselfharminstructions,039add1b-refresh-token-worker,account-change-chat-reset,preload-chat-messages,1s-moc-logosize,quiz-card-suggestion,send-connected,anonymousattachmentupload,async-disclaimer-text,mem-generate-post-turn,sharecontinue,share-campaign-taeb9y,share-campaign-krq0kf,dr-editprompt-mobile,039add1b-animated-greeting-message-view,greeting-message-animation,image"
		"-fallback-thumbnail,adsidsync,think-deeper-regenerate,smart-mode-flightd-edge,narr-icachuse,img-followup-patch,inject-user-greeting,code-edge-c,videoserp5,searchvideos-bing-fallback,searchimages-bing-fallback,edge-responding-loop-harmony-4o-1010,pay-instacart-canada,quiz-in-create-drawer,deep-research-export-file,m365-conversation-sync,deep-research-export-podcast,multiple,originaldocumentupload,web-multi-fallback-languages,share-campaign-evhqea,share-campaign-rbsrqk,share-campaign-tkzuae,share-campaign-jowp8z,share-campaign-gxcdu3,share-campaign-d2e0f5,share-campaign-dkmev6,share-campaign-coqva4,share-campaign-gez3vb,remove-extra-im-start-context,vision-in-composer-v3,deep-research-nano,export-pages-t,copilot-beta,smart-mode-default-rl,039add1b-uikit-paragraph-view,imagegenv3peakhour,onedrive-fetch,share-continue-v2,ts-dynamic-top-section-t,creator-gallery,old-search-config,thinkdeepero4minichainofthought,image-library-2,image-library-delete-image,igszcls,searchimages-cache,searchvideos-cache,pay-consisten"
		"t-buy,finance-tooltip-v2,m365-pills-custom,copilot-beta-automatic-opt-in,deep-research,quiz-option-shuffle,image-cards-v2,test-srm-aa-4,deep-research-promo-card,recipe-card,finance-watchlist-v2,finance-crypto,mutesuggestions,pages-link-navigation,pages-skip-page-selector,pages-file-upload,pages-suggested-followups,onedrive-graph,rm-relatedqna,dr-web-upd-w,dr-pro-nano,pay-getbuyoption-migration,pay-getrecipe-migration,pay-price-tracked,pay-shopify-checkout,sports-cards,smart-mode-reason-chat,pages-reasoning-gg,edge-autosuggest,composer-v4,039add1b-sentry-hang-rate-v2,voice-improved-courtesy-wait,quiz-harmony,sticky-conversation-mode,smart-mode-ensemble-switcher,t1_tsrv3_router,title-generation-harmony,pay-conversion-tracking,history-truncation-fix-parent,backstoryinsertall,local-cards,smart-mode-with-hapi,optimized-responding-for-cache,clarity-http-endpoint,share-image-continue,sharemanagement,labs-audio-expression-style-list-layout,nosearchimageonattachment,start-retry,ui-kit-paragraph-view-2,m365-cela-shee"
		"t,placecardprompclean-v3,title-generation-v2,eea-personalization-waiting-period,useggvisionmodel,study-mode,searchimages-safe,searchvideos-safe,edge-reload-tab,attachment-suggestions-c,vision-biometric-consent,page-title-generation-v2,kill-picasso-id-on-start,zircon-flight-t,browser-actions-09092025,share-campaign-ferk5z,search-pcm,detailedpromptmetrics,file-upload-config,sidebar-settings,placecard-enhance-all,n-30-k-20,pay-ams-treatment,ceo-harmony,finance-chart-clickthrough,labs-audio-expression-scripted-mode,labs-audio-expression-mode-coachmark,labs-audio-expression-story-voice-selector,thinkdeeper5reasoningloweffort,page-title-generation-hapi,skip-preview-event,m365-pills-data-v2,labs-audio-expression-auto-style,edgevision-multitab,flash-cards,finance-earnings,page-safety-check-treatment,analyzedocuments-extendedtokens,labs-audio-expression-preset-card-fixed,lazy-with-retry,sorttoolrouterresult-others-t,character-cognitive-testing-service,voice-flower-bg,thinkdeeper5miniloweffortchainofthought,image-dyn"
		"amic-width,group-conversations,share-to-invite,deep-research-share-link,cot-output-panel,imagegen-galleryremixquota,place-near-me-fix,related-results-t1,tru-router,pay-migrate-get-checkout-option-v2,voice-safety-patch,uselongcontextmodel,kill-regenerate,speechtranscribev2,browser-automation-inc-max-loop,thinkdeeper-truncator,search-truncation,backstory-trim,suppress-inline-link-nav-dialog,voice-time-formatting,balancedfiletokens,empty-tool-instruction,think-deeper-move-tool-instructions,heycopilot-backstory,vad-buffer,pay-edge-clarity,dr-progress,labs-audio-expression-story-image,remix-suggestions,ceo-remove-search-web,healthcare-safety-patch-v3,person-card,edge-safety-prompt-treatment,share-conversation-with-attachments,image-upload-mmt,dr-summary,cross-selling-t-gpt52,ceo-optimized-loop,podcast-in-voice,track-oldest-merged-message,mem-clean-forget,url-output-sanitization,gpt5-reasoning-harmony-personality-v1,config-responder-option-by-modelname,responding-loop-for-vision-model,reduce-vision-usage,dynamic-"
		"answer-cards-ga,dr-outlinks,quiz-instant-feedback,gpt-5-on-quick-mode,safety-middleware,ceo-filedownload,hide-feedback-if-no-mic-permission-on-end-call,auth-assertion,connector-consent-v2,existing-teen-enabled,voice-clear-audio-capture-listeners-on-end,dr-shared-orchestrator,memory-settings-v2,election-patch,pagecreation,add-utm-source,warnings-indepth,model-migration,route-chat-to-agent,browser-automation-instruction-gpt5,group-conversations-lazy-creation,reduce-memory-overtriggering,image-model-selector-summary,utm-tracking-use-copilot-com,checkmark-emoji-fix,groupchatnotifications,upfront-persistence,groupchat-mentions,edu-cross-sell,browser-actions-charapita,contextual-suggestions,subs-redirect-to-cmc,cef,voice-new-feedback-string,reject-tier4-start-traffic,time-patch,challenge-asn,min-adaptive-citation-t-nav,cloudflare-challenge,chat-recovery-long-streaming-timeout,enable-audio-capture-worklet,voice-memory-edf,reuse-audio-context-for-voice-output,enable-audio-out-pre-buffering-c,socket-close-track,loca"
		"l-inference-client-side-lb,auth0-based-user-link,knowledge-extraction-harmony,router-default-preload-intent,hide-conversation-dates,remove-qr,edge-shopping-enable-all-markets,deprecate_widgets_v1,edge-page-sanitization,teen-compliance,edge-ctx-consent-tool-executing,skip-reasoning-in-smart-mode,chat-client-retry,labs-remote-config,voice-name-repetition-fix,ltm-backfill-disabled,skip-append-last-user-message-again,framework-conversation-write,email-reply,voice-enable-new-audio-icon-c,backstorytool,block-image-generation-in-voice,increase-doc-attachment-max-tokens,nav-expand-all-t,remove-clarifying-prompts,readaloud-verbatim-prompt,kill-contextual-suggestions-tabs-check,podcast-project-sources-grounding,edf-store-direct-instruction,naa-has-active-account-check,computeruse-raw-cot,reduce-memory-overtrigger-location-c,search-uploaded-docs-in-project,mem-skip-preview-search,genuiskillssmallf12,searchmode-t2,browser-actions-detailed-summary,generate-flashcard-skill,browser-actions-deprecated-non-charapita,proacti"
		"ve-message-additional-context,searchfinance-searchquery,group-conversations-reuse-conv-id,voice-enable-read-aloud-c,edge-text-vision-treatment,max-adaptive-citations-c,user-message-copy,match-message-timestamp,edge-tab-safety-cache,voice-telemetry,m365-wxp-history-sync,kill-shopping-homepage-t,nav-card-short-url,kill-projects-creations-flash-card,computer-agent-skills,browser-remote-actions-for-tasks,conversation-compactor,planning-agent-elicitation,spd-citation-v2-mixed-format,agent-snapshots,group-conversations-unread-indicator,gpt52-reasoning-harmony,superbowl-search,autoprompt-off,earcon-only-after-first-use,voice-restart-telemetry,subs-hot-reload,jailbreakdisabled,pdp-track-price-comp-t,olympics-search,supersonic-task-preview,edf-memory-tuning,task-memory,trs-update-flight,block-document-generation-in-voice,task-notification,shopping-journeys-v2-container,shopping-feed-no-hero-image-t,fix-ftr,discovery-long-summary,avoid-edge-vision-highlight,agent-manager-registry,dicf6867,audioagent-v3,lm-arena-v2,wi"
		"ndows-vision-highlights,journeys-generation-v2-t,shopping-jump-back-to-conversation-c,studio-sdk,sdk-ai-message-item,sidebar-vnext,chat-session-affinity,ltm-responding-prompt-tuning-c,topic_continuation_enabled_twice_per_week,trvlflghttf,vertex-timeout,shopping-user-memory-t,fetch-convo,shadowban,update-edge-eu-user-consent-text,genui-tier3-c,genui-ground-counterfactual,discovery-harmony-timestamp,mai-whisper-language-c,gpt51-group-chat,genui-tier4-ground-flight-c,task-notification-no-timeout,shopping-journeys-v2-container-read-c,getcameraimages,web-30s-ping,v3-courteous-wait-c,shopping-feed-thumbs-feedback-toast,conversation-search-region-routing-control,edge-dont-language-switch,upsell-selector,model-training-new-privacy,voice-spatial-info,chainofthoughteventprocessor,chat-message-preview,handle-preview-event,kill-composer-creation-button,smart-mode,smart-mode-6e0b4c6f,smart-mode-cot,smart-mode-flightc,smart-mode-v2-config,searchvideos,searchvideos-google,serpvideocard,video-cards-v2,videocardrespondingin"
		"struction,edge-responder-loop,emit-all-inference-telemetry,responderactions-all,responding-harmony-4o-v4,multi-file-upload,multiple-file-upload,unlimitedfilereasoning,grounded-edit,page-citation,pages-footnote,gpt5-calcite,responding-harmony-gpt5-v1,smart-mode-default,tool-defs-on-separate-system-message,1s-moc-keep-facets,1s-moc-more-msn,1s-wpo-dis-dnewsr,1s-wpo-dis-nopod,discover-gemfive,discover-more-news-content,discover-news-all-large-cards,discover-newsts,discover-threets,think-deeper-cot,finance-follow,finance-watchlist-ui,prg-cmc-flws,prg-cmc-fnav,improve-context-precision,ds-editprompt,ds-new-progress,smart-mode-gpt5,actionspacereducerv2,longqueryfilter,tsrv3_router,enable-history-cache-write,truncatekmessages,responding-harmony-gpt-5-nosearch,responding-harmony-gpt-5-search,placecardnavigationenabled,placecardpromptoptimizationenabled,switcher-harmony,browser-actions,browserautomationcomputeruse,browserautomationsearchweb,edgeactiondisableouter,morefileupload,sidebar-compact-nav-items,sidebar-narr"
		"ow,searchplaces-enhanced-infos,searchplaces-enhanced-photos,truncatekmessages-k20,truncatekmessages-n30,pay-ams-integration-server,pay-ams-pdp,pay-ams-price-tracking,pay-ams-product-card,edge-page-safety-check,pii-scrubber,sorttoolrouterresult,relatedresults-android,relatedresults-ios,rrcitationv2,searchmode,see-more-results,toolspacereducerclassifierflight,searchweb-page3,searchweb-sd1000,searchweb-shorter,voice-search-timezone,enrich-web-grounding-with-linkedin-api,entity-info,linkedin-url,person-card-prefer-linkedin,person-cards,edge-security-template,image-ocr-hapi,merge-user-messages,deep-research-summary-v3,dr-cover-image,action-result-relaxed-json-escaping,bingify-sanitized-urls,urls-extracted-infer-event,gpt5-reasoning-harmony,thinkdeeper-gpt5reasoning-harmony-personality,dynamic-answer-cards,indepth-comparison-and-details,warnings-and-clarifications,edu-discovery-cross-sell,study-mode-mico-quiz-tutor,citation-v2,citation-v2-cards,citation-v2-nav,inline-image,inline-video,inline-video-moments,adapti"
		"ve-citations,adaptive-citations-navigation,pinned-conversation,dynamic-card-selection-instructions,nav-all-turns,nav-cards-on-all-modes,nav-hostqcscore-filter,navigation-curated-enabled,navigation-curation-gpt4o,skip-nav-classifier,generativeui-mvpt3,genui-fiximage,genui-fiximage-12,genui-json-validator,genui-mvp,genui-preturn-refactor,genui-skills,genui-skills-small,genuimvp,searchmode-gpt51-chat-harmony,searchmode-gpt51-promptv2,edge-copilot-screenshot,edge-text-vision,kill-shopping-homepage,shopping-pdp-hide-price-history,shopping-pdp-price-tracking-fallback,sorttoolsbyfrequencyflight,shopping-feed-no-hero-image,shopping-journey-staged-orchestrator,shopping-journeys-debounce,shopping-limit-concurrency,flight-booking-skill,shopping-user-memory,generativeui-flight-status,generativeui-local-events,generativeui-prayer-vertical-timeline,generativeui-sunrise-v2,genui-core,genui-counterfactual,genui-ground-t,genui-grounding-template-selector,genui-tier2-grounding-templates,genui-turncache-templates\",\"eventInf"
		"o_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"isNewUser\":false,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:98967"
		"5,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-1"
		"8,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"AppInfo_Version\":\"145.0.3800.82\",\"eventName\":\"copilotApiResponse\",\"eventInfo_path\":\"/config\",\"eventInfo_method\":\"GET\",\"eventInfo_status\":200,\"eventInfo_duration\":4827.600000023842,\"eventInfo_responseContentLength\":36105,\"eventInfo_xCDNTraceId\":\"9d7f9d447bdb6ce0-MAA\",\"eventInfo_server\":\"cloudflare\"}}\n"
		"{\"name\":\"apiresponse\",\"time\":\"2026-03-06T07:23:23.297Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":31,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_status\":{\"t\":6},\"eventInfo_duration\":{\"t\":6},\"eventInfo_responseContentLength\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edg"
		"etab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBCCDD16E182AFC5E06CC216F3A\",\"userFlightIds\":\"imagegenv3,assistant-enable-answer-cards,voice-spatial,weather-cards,edgviswebground,enable-all-app-actions,promptedreasoningcombinedwithsearchpatch,promptmessagewithcards,voices78,allowanonymoususershare,share-chat-page-entry,039add1b-use-fixed-chat-layout,share-image-link,dailybriefing,pages-table,always-show-last-reaction-v2,azureconfigregexblocklist,disable-cmc-auto-reload,onedrive,suggesthangup,correct-personalization-accidental-opt-out,share-campaign,039add1b-chat-sessions-drawer,039add1b-pages-drawer,injectselfharminstructions,039add1b-refresh-token-worker,account-change-chat-reset,preload-chat-messages,1s-moc-logosize,quiz-card-suggestion,send-connected,anonymousattachmentupload,async-disclaimer-text,mem-generate-post-turn,sharecontinue,share-campaign-taeb9y,share-campaign-krq0kf,dr-editprompt-mobile,039add1b-animated-greeting-message-view,greeting-message-animation,image"
		"-fallback-thumbnail,adsidsync,think-deeper-regenerate,smart-mode-flightd-edge,narr-icachuse,img-followup-patch,inject-user-greeting,code-edge-c,videoserp5,searchvideos-bing-fallback,searchimages-bing-fallback,edge-responding-loop-harmony-4o-1010,pay-instacart-canada,quiz-in-create-drawer,deep-research-export-file,m365-conversation-sync,deep-research-export-podcast,multiple,originaldocumentupload,web-multi-fallback-languages,share-campaign-evhqea,share-campaign-rbsrqk,share-campaign-tkzuae,share-campaign-jowp8z,share-campaign-gxcdu3,share-campaign-d2e0f5,share-campaign-dkmev6,share-campaign-coqva4,share-campaign-gez3vb,remove-extra-im-start-context,vision-in-composer-v3,deep-research-nano,export-pages-t,copilot-beta,smart-mode-default-rl,039add1b-uikit-paragraph-view,imagegenv3peakhour,onedrive-fetch,share-continue-v2,ts-dynamic-top-section-t,creator-gallery,old-search-config,thinkdeepero4minichainofthought,image-library-2,image-library-delete-image,igszcls,searchimages-cache,searchvideos-cache,pay-consisten"
		"t-buy,finance-tooltip-v2,m365-pills-custom,copilot-beta-automatic-opt-in,deep-research,quiz-option-shuffle,image-cards-v2,test-srm-aa-4,deep-research-promo-card,recipe-card,finance-watchlist-v2,finance-crypto,mutesuggestions,pages-link-navigation,pages-skip-page-selector,pages-file-upload,pages-suggested-followups,onedrive-graph,rm-relatedqna,dr-web-upd-w,dr-pro-nano,pay-getbuyoption-migration,pay-getrecipe-migration,pay-price-tracked,pay-shopify-checkout,sports-cards,smart-mode-reason-chat,pages-reasoning-gg,edge-autosuggest,composer-v4,039add1b-sentry-hang-rate-v2,voice-improved-courtesy-wait,quiz-harmony,sticky-conversation-mode,smart-mode-ensemble-switcher,t1_tsrv3_router,title-generation-harmony,pay-conversion-tracking,history-truncation-fix-parent,backstoryinsertall,local-cards,smart-mode-with-hapi,optimized-responding-for-cache,clarity-http-endpoint,share-image-continue,sharemanagement,labs-audio-expression-style-list-layout,nosearchimageonattachment,start-retry,ui-kit-paragraph-view-2,m365-cela-shee"
		"t,placecardprompclean-v3,title-generation-v2,eea-personalization-waiting-period,useggvisionmodel,study-mode,searchimages-safe,searchvideos-safe,edge-reload-tab,attachment-suggestions-c,vision-biometric-consent,page-title-generation-v2,kill-picasso-id-on-start,zircon-flight-t,browser-actions-09092025,share-campaign-ferk5z,search-pcm,detailedpromptmetrics,file-upload-config,sidebar-settings,placecard-enhance-all,n-30-k-20,pay-ams-treatment,ceo-harmony,finance-chart-clickthrough,labs-audio-expression-scripted-mode,labs-audio-expression-mode-coachmark,labs-audio-expression-story-voice-selector,thinkdeeper5reasoningloweffort,page-title-generation-hapi,skip-preview-event,m365-pills-data-v2,labs-audio-expression-auto-style,edgevision-multitab,flash-cards,finance-earnings,page-safety-check-treatment,analyzedocuments-extendedtokens,labs-audio-expression-preset-card-fixed,lazy-with-retry,sorttoolrouterresult-others-t,character-cognitive-testing-service,voice-flower-bg,thinkdeeper5miniloweffortchainofthought,image-dyn"
		"amic-width,group-conversations,share-to-invite,deep-research-share-link,cot-output-panel,imagegen-galleryremixquota,place-near-me-fix,related-results-t1,tru-router,pay-migrate-get-checkout-option-v2,voice-safety-patch,uselongcontextmodel,kill-regenerate,speechtranscribev2,browser-automation-inc-max-loop,thinkdeeper-truncator,search-truncation,backstory-trim,suppress-inline-link-nav-dialog,voice-time-formatting,balancedfiletokens,empty-tool-instruction,think-deeper-move-tool-instructions,heycopilot-backstory,vad-buffer,pay-edge-clarity,dr-progress,labs-audio-expression-story-image,remix-suggestions,ceo-remove-search-web,healthcare-safety-patch-v3,person-card,edge-safety-prompt-treatment,share-conversation-with-attachments,image-upload-mmt,dr-summary,cross-selling-t-gpt52,ceo-optimized-loop,podcast-in-voice,track-oldest-merged-message,mem-clean-forget,url-output-sanitization,gpt5-reasoning-harmony-personality-v1,config-responder-option-by-modelname,responding-loop-for-vision-model,reduce-vision-usage,dynamic-"
		"answer-cards-ga,dr-outlinks,quiz-instant-feedback,gpt-5-on-quick-mode,safety-middleware,ceo-filedownload,hide-feedback-if-no-mic-permission-on-end-call,auth-assertion,connector-consent-v2,existing-teen-enabled,voice-clear-audio-capture-listeners-on-end,dr-shared-orchestrator,memory-settings-v2,election-patch,pagecreation,add-utm-source,warnings-indepth,model-migration,route-chat-to-agent,browser-automation-instruction-gpt5,group-conversations-lazy-creation,reduce-memory-overtriggering,image-model-selector-summary,utm-tracking-use-copilot-com,checkmark-emoji-fix,groupchatnotifications,upfront-persistence,groupchat-mentions,edu-cross-sell,browser-actions-charapita,contextual-suggestions,subs-redirect-to-cmc,cef,voice-new-feedback-string,reject-tier4-start-traffic,time-patch,challenge-asn,min-adaptive-citation-t-nav,cloudflare-challenge,chat-recovery-long-streaming-timeout,enable-audio-capture-worklet,voice-memory-edf,reuse-audio-context-for-voice-output,enable-audio-out-pre-buffering-c,socket-close-track,loca"
		"l-inference-client-side-lb,auth0-based-user-link,knowledge-extraction-harmony,router-default-preload-intent,hide-conversation-dates,remove-qr,edge-shopping-enable-all-markets,deprecate_widgets_v1,edge-page-sanitization,teen-compliance,edge-ctx-consent-tool-executing,skip-reasoning-in-smart-mode,chat-client-retry,labs-remote-config,voice-name-repetition-fix,ltm-backfill-disabled,skip-append-last-user-message-again,framework-conversation-write,email-reply,voice-enable-new-audio-icon-c,backstorytool,block-image-generation-in-voice,increase-doc-attachment-max-tokens,nav-expand-all-t,remove-clarifying-prompts,readaloud-verbatim-prompt,kill-contextual-suggestions-tabs-check,podcast-project-sources-grounding,edf-store-direct-instruction,naa-has-active-account-check,computeruse-raw-cot,reduce-memory-overtrigger-location-c,search-uploaded-docs-in-project,mem-skip-preview-search,genuiskillssmallf12,searchmode-t2,browser-actions-detailed-summary,generate-flashcard-skill,browser-actions-deprecated-non-charapita,proacti"
		"ve-message-additional-context,searchfinance-searchquery,group-conversations-reuse-conv-id,voice-enable-read-aloud-c,edge-text-vision-treatment,max-adaptive-citations-c,user-message-copy,match-message-timestamp,edge-tab-safety-cache,voice-telemetry,m365-wxp-history-sync,kill-shopping-homepage-t,nav-card-short-url,kill-projects-creations-flash-card,computer-agent-skills,browser-remote-actions-for-tasks,conversation-compactor,planning-agent-elicitation,spd-citation-v2-mixed-format,agent-snapshots,group-conversations-unread-indicator,gpt52-reasoning-harmony,superbowl-search,autoprompt-off,earcon-only-after-first-use,voice-restart-telemetry,subs-hot-reload,jailbreakdisabled,pdp-track-price-comp-t,olympics-search,supersonic-task-preview,edf-memory-tuning,task-memory,trs-update-flight,block-document-generation-in-voice,task-notification,shopping-journeys-v2-container,shopping-feed-no-hero-image-t,fix-ftr,discovery-long-summary,avoid-edge-vision-highlight,agent-manager-registry,dicf6867,audioagent-v3,lm-arena-v2,wi"
		"ndows-vision-highlights,journeys-generation-v2-t,shopping-jump-back-to-conversation-c,studio-sdk,sdk-ai-message-item,sidebar-vnext,chat-session-affinity,ltm-responding-prompt-tuning-c,topic_continuation_enabled_twice_per_week,trvlflghttf,vertex-timeout,shopping-user-memory-t,fetch-convo,shadowban,update-edge-eu-user-consent-text,genui-tier3-c,genui-ground-counterfactual,discovery-harmony-timestamp,mai-whisper-language-c,gpt51-group-chat,genui-tier4-ground-flight-c,task-notification-no-timeout,shopping-journeys-v2-container-read-c,getcameraimages,web-30s-ping,v3-courteous-wait-c,shopping-feed-thumbs-feedback-toast,conversation-search-region-routing-control,edge-dont-language-switch,upsell-selector,model-training-new-privacy,voice-spatial-info,chainofthoughteventprocessor,chat-message-preview,handle-preview-event,kill-composer-creation-button,smart-mode,smart-mode-6e0b4c6f,smart-mode-cot,smart-mode-flightc,smart-mode-v2-config,searchvideos,searchvideos-google,serpvideocard,video-cards-v2,videocardrespondingin"
		"struction,edge-responder-loop,emit-all-inference-telemetry,responderactions-all,responding-harmony-4o-v4,multi-file-upload,multiple-file-upload,unlimitedfilereasoning,grounded-edit,page-citation,pages-footnote,gpt5-calcite,responding-harmony-gpt5-v1,smart-mode-default,tool-defs-on-separate-system-message,1s-moc-keep-facets,1s-moc-more-msn,1s-wpo-dis-dnewsr,1s-wpo-dis-nopod,discover-gemfive,discover-more-news-content,discover-news-all-large-cards,discover-newsts,discover-threets,think-deeper-cot,finance-follow,finance-watchlist-ui,prg-cmc-flws,prg-cmc-fnav,improve-context-precision,ds-editprompt,ds-new-progress,smart-mode-gpt5,actionspacereducerv2,longqueryfilter,tsrv3_router,enable-history-cache-write,truncatekmessages,responding-harmony-gpt-5-nosearch,responding-harmony-gpt-5-search,placecardnavigationenabled,placecardpromptoptimizationenabled,switcher-harmony,browser-actions,browserautomationcomputeruse,browserautomationsearchweb,edgeactiondisableouter,morefileupload,sidebar-compact-nav-items,sidebar-narr"
		"ow,searchplaces-enhanced-infos,searchplaces-enhanced-photos,truncatekmessages-k20,truncatekmessages-n30,pay-ams-integration-server,pay-ams-pdp,pay-ams-price-tracking,pay-ams-product-card,edge-page-safety-check,pii-scrubber,sorttoolrouterresult,relatedresults-android,relatedresults-ios,rrcitationv2,searchmode,see-more-results,toolspacereducerclassifierflight,searchweb-page3,searchweb-sd1000,searchweb-shorter,voice-search-timezone,enrich-web-grounding-with-linkedin-api,entity-info,linkedin-url,person-card-prefer-linkedin,person-cards,edge-security-template,image-ocr-hapi,merge-user-messages,deep-research-summary-v3,dr-cover-image,action-result-relaxed-json-escaping,bingify-sanitized-urls,urls-extracted-infer-event,gpt5-reasoning-harmony,thinkdeeper-gpt5reasoning-harmony-personality,dynamic-answer-cards,indepth-comparison-and-details,warnings-and-clarifications,edu-discovery-cross-sell,study-mode-mico-quiz-tutor,citation-v2,citation-v2-cards,citation-v2-nav,inline-image,inline-video,inline-video-moments,adapti"
		"ve-citations,adaptive-citations-navigation,pinned-conversation,dynamic-card-selection-instructions,nav-all-turns,nav-cards-on-all-modes,nav-hostqcscore-filter,navigation-curated-enabled,navigation-curation-gpt4o,skip-nav-classifier,generativeui-mvpt3,genui-fiximage,genui-fiximage-12,genui-json-validator,genui-mvp,genui-preturn-refactor,genui-skills,genui-skills-small,genuimvp,searchmode-gpt51-chat-harmony,searchmode-gpt51-promptv2,edge-copilot-screenshot,edge-text-vision,kill-shopping-homepage,shopping-pdp-hide-price-history,shopping-pdp-price-tracking-fallback,sorttoolsbyfrequencyflight,shopping-feed-no-hero-image,shopping-journey-staged-orchestrator,shopping-journeys-debounce,shopping-limit-concurrency,flight-booking-skill,shopping-user-memory,generativeui-flight-status,generativeui-local-events,generativeui-prayer-vertical-timeline,generativeui-sunrise-v2,genui-core,genui-counterfactual,genui-ground-t,genui-grounding-template-selector,genui-tier2-grounding-templates,genui-turncache-templates\",\"eventInf"
		"o_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"isNewUser\":false,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:98967"
		"5,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-1"
		"8,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"AppInfo_Version\":\"145.0.3800.82\",\"eventName\":\"copilotApiResponse\",\"eventInfo_path\":\"/user/install-status\",\"eventInfo_method\":\"GET\",\"eventInfo_status\":200,\"eventInfo_duration\":4829.199999928474,\"eventInfo_responseContentLength\":30,\"eventInfo_xCDNTraceId\":\"9d7f9d447bd96ce0-MAA\",\"eventInfo_server\":\"cloudflare\"}}\n"
		"{\"name\":\"apiresponse\",\"time\":\"2026-03-06T07:23:23.298Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":32,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_status\":{\"t\":6},\"eventInfo_duration\":{\"t\":6},\"eventInfo_responseContentLength\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edg"
		"etab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBCCDD16E182AFC5E06CC216F3A\",\"userFlightIds\":\"imagegenv3,assistant-enable-answer-cards,voice-spatial,weather-cards,edgviswebground,enable-all-app-actions,promptedreasoningcombinedwithsearchpatch,promptmessagewithcards,voices78,allowanonymoususershare,share-chat-page-entry,039add1b-use-fixed-chat-layout,share-image-link,dailybriefing,pages-table,always-show-last-reaction-v2,azureconfigregexblocklist,disable-cmc-auto-reload,onedrive,suggesthangup,correct-personalization-accidental-opt-out,share-campaign,039add1b-chat-sessions-drawer,039add1b-pages-drawer,injectselfharminstructions,039add1b-refresh-token-worker,account-change-chat-reset,preload-chat-messages,1s-moc-logosize,quiz-card-suggestion,send-connected,anonymousattachmentupload,async-disclaimer-text,mem-generate-post-turn,sharecontinue,share-campaign-taeb9y,share-campaign-krq0kf,dr-editprompt-mobile,039add1b-animated-greeting-message-view,greeting-message-animation,image"
		"-fallback-thumbnail,adsidsync,think-deeper-regenerate,smart-mode-flightd-edge,narr-icachuse,img-followup-patch,inject-user-greeting,code-edge-c,videoserp5,searchvideos-bing-fallback,searchimages-bing-fallback,edge-responding-loop-harmony-4o-1010,pay-instacart-canada,quiz-in-create-drawer,deep-research-export-file,m365-conversation-sync,deep-research-export-podcast,multiple,originaldocumentupload,web-multi-fallback-languages,share-campaign-evhqea,share-campaign-rbsrqk,share-campaign-tkzuae,share-campaign-jowp8z,share-campaign-gxcdu3,share-campaign-d2e0f5,share-campaign-dkmev6,share-campaign-coqva4,share-campaign-gez3vb,remove-extra-im-start-context,vision-in-composer-v3,deep-research-nano,export-pages-t,copilot-beta,smart-mode-default-rl,039add1b-uikit-paragraph-view,imagegenv3peakhour,onedrive-fetch,share-continue-v2,ts-dynamic-top-section-t,creator-gallery,old-search-config,thinkdeepero4minichainofthought,image-library-2,image-library-delete-image,igszcls,searchimages-cache,searchvideos-cache,pay-consisten"
		"t-buy,finance-tooltip-v2,m365-pills-custom,copilot-beta-automatic-opt-in,deep-research,quiz-option-shuffle,image-cards-v2,test-srm-aa-4,deep-research-promo-card,recipe-card,finance-watchlist-v2,finance-crypto,mutesuggestions,pages-link-navigation,pages-skip-page-selector,pages-file-upload,pages-suggested-followups,onedrive-graph,rm-relatedqna,dr-web-upd-w,dr-pro-nano,pay-getbuyoption-migration,pay-getrecipe-migration,pay-price-tracked,pay-shopify-checkout,sports-cards,smart-mode-reason-chat,pages-reasoning-gg,edge-autosuggest,composer-v4,039add1b-sentry-hang-rate-v2,voice-improved-courtesy-wait,quiz-harmony,sticky-conversation-mode,smart-mode-ensemble-switcher,t1_tsrv3_router,title-generation-harmony,pay-conversion-tracking,history-truncation-fix-parent,backstoryinsertall,local-cards,smart-mode-with-hapi,optimized-responding-for-cache,clarity-http-endpoint,share-image-continue,sharemanagement,labs-audio-expression-style-list-layout,nosearchimageonattachment,start-retry,ui-kit-paragraph-view-2,m365-cela-shee"
		"t,placecardprompclean-v3,title-generation-v2,eea-personalization-waiting-period,useggvisionmodel,study-mode,searchimages-safe,searchvideos-safe,edge-reload-tab,attachment-suggestions-c,vision-biometric-consent,page-title-generation-v2,kill-picasso-id-on-start,zircon-flight-t,browser-actions-09092025,share-campaign-ferk5z,search-pcm,detailedpromptmetrics,file-upload-config,sidebar-settings,placecard-enhance-all,n-30-k-20,pay-ams-treatment,ceo-harmony,finance-chart-clickthrough,labs-audio-expression-scripted-mode,labs-audio-expression-mode-coachmark,labs-audio-expression-story-voice-selector,thinkdeeper5reasoningloweffort,page-title-generation-hapi,skip-preview-event,m365-pills-data-v2,labs-audio-expression-auto-style,edgevision-multitab,flash-cards,finance-earnings,page-safety-check-treatment,analyzedocuments-extendedtokens,labs-audio-expression-preset-card-fixed,lazy-with-retry,sorttoolrouterresult-others-t,character-cognitive-testing-service,voice-flower-bg,thinkdeeper5miniloweffortchainofthought,image-dyn"
		"amic-width,group-conversations,share-to-invite,deep-research-share-link,cot-output-panel,imagegen-galleryremixquota,place-near-me-fix,related-results-t1,tru-router,pay-migrate-get-checkout-option-v2,voice-safety-patch,uselongcontextmodel,kill-regenerate,speechtranscribev2,browser-automation-inc-max-loop,thinkdeeper-truncator,search-truncation,backstory-trim,suppress-inline-link-nav-dialog,voice-time-formatting,balancedfiletokens,empty-tool-instruction,think-deeper-move-tool-instructions,heycopilot-backstory,vad-buffer,pay-edge-clarity,dr-progress,labs-audio-expression-story-image,remix-suggestions,ceo-remove-search-web,healthcare-safety-patch-v3,person-card,edge-safety-prompt-treatment,share-conversation-with-attachments,image-upload-mmt,dr-summary,cross-selling-t-gpt52,ceo-optimized-loop,podcast-in-voice,track-oldest-merged-message,mem-clean-forget,url-output-sanitization,gpt5-reasoning-harmony-personality-v1,config-responder-option-by-modelname,responding-loop-for-vision-model,reduce-vision-usage,dynamic-"
		"answer-cards-ga,dr-outlinks,quiz-instant-feedback,gpt-5-on-quick-mode,safety-middleware,ceo-filedownload,hide-feedback-if-no-mic-permission-on-end-call,auth-assertion,connector-consent-v2,existing-teen-enabled,voice-clear-audio-capture-listeners-on-end,dr-shared-orchestrator,memory-settings-v2,election-patch,pagecreation,add-utm-source,warnings-indepth,model-migration,route-chat-to-agent,browser-automation-instruction-gpt5,group-conversations-lazy-creation,reduce-memory-overtriggering,image-model-selector-summary,utm-tracking-use-copilot-com,checkmark-emoji-fix,groupchatnotifications,upfront-persistence,groupchat-mentions,edu-cross-sell,browser-actions-charapita,contextual-suggestions,subs-redirect-to-cmc,cef,voice-new-feedback-string,reject-tier4-start-traffic,time-patch,challenge-asn,min-adaptive-citation-t-nav,cloudflare-challenge,chat-recovery-long-streaming-timeout,enable-audio-capture-worklet,voice-memory-edf,reuse-audio-context-for-voice-output,enable-audio-out-pre-buffering-c,socket-close-track,loca"
		"l-inference-client-side-lb,auth0-based-user-link,knowledge-extraction-harmony,router-default-preload-intent,hide-conversation-dates,remove-qr,edge-shopping-enable-all-markets,deprecate_widgets_v1,edge-page-sanitization,teen-compliance,edge-ctx-consent-tool-executing,skip-reasoning-in-smart-mode,chat-client-retry,labs-remote-config,voice-name-repetition-fix,ltm-backfill-disabled,skip-append-last-user-message-again,framework-conversation-write,email-reply,voice-enable-new-audio-icon-c,backstorytool,block-image-generation-in-voice,increase-doc-attachment-max-tokens,nav-expand-all-t,remove-clarifying-prompts,readaloud-verbatim-prompt,kill-contextual-suggestions-tabs-check,podcast-project-sources-grounding,edf-store-direct-instruction,naa-has-active-account-check,computeruse-raw-cot,reduce-memory-overtrigger-location-c,search-uploaded-docs-in-project,mem-skip-preview-search,genuiskillssmallf12,searchmode-t2,browser-actions-detailed-summary,generate-flashcard-skill,browser-actions-deprecated-non-charapita,proacti"
		"ve-message-additional-context,searchfinance-searchquery,group-conversations-reuse-conv-id,voice-enable-read-aloud-c,edge-text-vision-treatment,max-adaptive-citations-c,user-message-copy,match-message-timestamp,edge-tab-safety-cache,voice-telemetry,m365-wxp-history-sync,kill-shopping-homepage-t,nav-card-short-url,kill-projects-creations-flash-card,computer-agent-skills,browser-remote-actions-for-tasks,conversation-compactor,planning-agent-elicitation,spd-citation-v2-mixed-format,agent-snapshots,group-conversations-unread-indicator,gpt52-reasoning-harmony,superbowl-search,autoprompt-off,earcon-only-after-first-use,voice-restart-telemetry,subs-hot-reload,jailbreakdisabled,pdp-track-price-comp-t,olympics-search,supersonic-task-preview,edf-memory-tuning,task-memory,trs-update-flight,block-document-generation-in-voice,task-notification,shopping-journeys-v2-container,shopping-feed-no-hero-image-t,fix-ftr,discovery-long-summary,avoid-edge-vision-highlight,agent-manager-registry,dicf6867,audioagent-v3,lm-arena-v2,wi"
		"ndows-vision-highlights,journeys-generation-v2-t,shopping-jump-back-to-conversation-c,studio-sdk,sdk-ai-message-item,sidebar-vnext,chat-session-affinity,ltm-responding-prompt-tuning-c,topic_continuation_enabled_twice_per_week,trvlflghttf,vertex-timeout,shopping-user-memory-t,fetch-convo,shadowban,update-edge-eu-user-consent-text,genui-tier3-c,genui-ground-counterfactual,discovery-harmony-timestamp,mai-whisper-language-c,gpt51-group-chat,genui-tier4-ground-flight-c,task-notification-no-timeout,shopping-journeys-v2-container-read-c,getcameraimages,web-30s-ping,v3-courteous-wait-c,shopping-feed-thumbs-feedback-toast,conversation-search-region-routing-control,edge-dont-language-switch,upsell-selector,model-training-new-privacy,voice-spatial-info,chainofthoughteventprocessor,chat-message-preview,handle-preview-event,kill-composer-creation-button,smart-mode,smart-mode-6e0b4c6f,smart-mode-cot,smart-mode-flightc,smart-mode-v2-config,searchvideos,searchvideos-google,serpvideocard,video-cards-v2,videocardrespondingin"
		"struction,edge-responder-loop,emit-all-inference-telemetry,responderactions-all,responding-harmony-4o-v4,multi-file-upload,multiple-file-upload,unlimitedfilereasoning,grounded-edit,page-citation,pages-footnote,gpt5-calcite,responding-harmony-gpt5-v1,smart-mode-default,tool-defs-on-separate-system-message,1s-moc-keep-facets,1s-moc-more-msn,1s-wpo-dis-dnewsr,1s-wpo-dis-nopod,discover-gemfive,discover-more-news-content,discover-news-all-large-cards,discover-newsts,discover-threets,think-deeper-cot,finance-follow,finance-watchlist-ui,prg-cmc-flws,prg-cmc-fnav,improve-context-precision,ds-editprompt,ds-new-progress,smart-mode-gpt5,actionspacereducerv2,longqueryfilter,tsrv3_router,enable-history-cache-write,truncatekmessages,responding-harmony-gpt-5-nosearch,responding-harmony-gpt-5-search,placecardnavigationenabled,placecardpromptoptimizationenabled,switcher-harmony,browser-actions,browserautomationcomputeruse,browserautomationsearchweb,edgeactiondisableouter,morefileupload,sidebar-compact-nav-items,sidebar-narr"
		"ow,searchplaces-enhanced-infos,searchplaces-enhanced-photos,truncatekmessages-k20,truncatekmessages-n30,pay-ams-integration-server,pay-ams-pdp,pay-ams-price-tracking,pay-ams-product-card,edge-page-safety-check,pii-scrubber,sorttoolrouterresult,relatedresults-android,relatedresults-ios,rrcitationv2,searchmode,see-more-results,toolspacereducerclassifierflight,searchweb-page3,searchweb-sd1000,searchweb-shorter,voice-search-timezone,enrich-web-grounding-with-linkedin-api,entity-info,linkedin-url,person-card-prefer-linkedin,person-cards,edge-security-template,image-ocr-hapi,merge-user-messages,deep-research-summary-v3,dr-cover-image,action-result-relaxed-json-escaping,bingify-sanitized-urls,urls-extracted-infer-event,gpt5-reasoning-harmony,thinkdeeper-gpt5reasoning-harmony-personality,dynamic-answer-cards,indepth-comparison-and-details,warnings-and-clarifications,edu-discovery-cross-sell,study-mode-mico-quiz-tutor,citation-v2,citation-v2-cards,citation-v2-nav,inline-image,inline-video,inline-video-moments,adapti"
		"ve-citations,adaptive-citations-navigation,pinned-conversation,dynamic-card-selection-instructions,nav-all-turns,nav-cards-on-all-modes,nav-hostqcscore-filter,navigation-curated-enabled,navigation-curation-gpt4o,skip-nav-classifier,generativeui-mvpt3,genui-fiximage,genui-fiximage-12,genui-json-validator,genui-mvp,genui-preturn-refactor,genui-skills,genui-skills-small,genuimvp,searchmode-gpt51-chat-harmony,searchmode-gpt51-promptv2,edge-copilot-screenshot,edge-text-vision,kill-shopping-homepage,shopping-pdp-hide-price-history,shopping-pdp-price-tracking-fallback,sorttoolsbyfrequencyflight,shopping-feed-no-hero-image,shopping-journey-staged-orchestrator,shopping-journeys-debounce,shopping-limit-concurrency,flight-booking-skill,shopping-user-memory,generativeui-flight-status,generativeui-local-events,generativeui-prayer-vertical-timeline,generativeui-sunrise-v2,genui-core,genui-counterfactual,genui-ground-t,genui-grounding-template-selector,genui-tier2-grounding-templates,genui-turncache-templates\",\"eventInf"
		"o_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"isNewUser\":false,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:98967"
		"5,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-1"
		"8,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"AppInfo_Version\":\"145.0.3800.82\",\"eventName\":\"copilotApiResponse\",\"eventInfo_path\":\"/user/settings\",\"eventInfo_method\":\"GET\",\"eventInfo_status\":200,\"eventInfo_duration\":4830,\"eventInfo_responseContentLength\":505,\"eventInfo_xCDNTraceId\":\"9d7f9d447bd46ce0-MAA\",\"eventInfo_server\":\"cloudflare\"}}\n"
		"{\"name\":\"apiresponse\",\"time\":\"2026-03-06T07:23:23.299Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":33,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_status\":{\"t\":6},\"eventInfo_duration\":{\"t\":6},\"eventInfo_responseContentLength\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edg"
		"etab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBCCDD16E182AFC5E06CC216F3A\",\"userFlightIds\":\"imagegenv3,assistant-enable-answer-cards,voice-spatial,weather-cards,edgviswebground,enable-all-app-actions,promptedreasoningcombinedwithsearchpatch,promptmessagewithcards,voices78,allowanonymoususershare,share-chat-page-entry,039add1b-use-fixed-chat-layout,share-image-link,dailybriefing,pages-table,always-show-last-reaction-v2,azureconfigregexblocklist,disable-cmc-auto-reload,onedrive,suggesthangup,correct-personalization-accidental-opt-out,share-campaign,039add1b-chat-sessions-drawer,039add1b-pages-drawer,injectselfharminstructions,039add1b-refresh-token-worker,account-change-chat-reset,preload-chat-messages,1s-moc-logosize,quiz-card-suggestion,send-connected,anonymousattachmentupload,async-disclaimer-text,mem-generate-post-turn,sharecontinue,share-campaign-taeb9y,share-campaign-krq0kf,dr-editprompt-mobile,039add1b-animated-greeting-message-view,greeting-message-animation,image"
		"-fallback-thumbnail,adsidsync,think-deeper-regenerate,smart-mode-flightd-edge,narr-icachuse,img-followup-patch,inject-user-greeting,code-edge-c,videoserp5,searchvideos-bing-fallback,searchimages-bing-fallback,edge-responding-loop-harmony-4o-1010,pay-instacart-canada,quiz-in-create-drawer,deep-research-export-file,m365-conversation-sync,deep-research-export-podcast,multiple,originaldocumentupload,web-multi-fallback-languages,share-campaign-evhqea,share-campaign-rbsrqk,share-campaign-tkzuae,share-campaign-jowp8z,share-campaign-gxcdu3,share-campaign-d2e0f5,share-campaign-dkmev6,share-campaign-coqva4,share-campaign-gez3vb,remove-extra-im-start-context,vision-in-composer-v3,deep-research-nano,export-pages-t,copilot-beta,smart-mode-default-rl,039add1b-uikit-paragraph-view,imagegenv3peakhour,onedrive-fetch,share-continue-v2,ts-dynamic-top-section-t,creator-gallery,old-search-config,thinkdeepero4minichainofthought,image-library-2,image-library-delete-image,igszcls,searchimages-cache,searchvideos-cache,pay-consisten"
		"t-buy,finance-tooltip-v2,m365-pills-custom,copilot-beta-automatic-opt-in,deep-research,quiz-option-shuffle,image-cards-v2,test-srm-aa-4,deep-research-promo-card,recipe-card,finance-watchlist-v2,finance-crypto,mutesuggestions,pages-link-navigation,pages-skip-page-selector,pages-file-upload,pages-suggested-followups,onedrive-graph,rm-relatedqna,dr-web-upd-w,dr-pro-nano,pay-getbuyoption-migration,pay-getrecipe-migration,pay-price-tracked,pay-shopify-checkout,sports-cards,smart-mode-reason-chat,pages-reasoning-gg,edge-autosuggest,composer-v4,039add1b-sentry-hang-rate-v2,voice-improved-courtesy-wait,quiz-harmony,sticky-conversation-mode,smart-mode-ensemble-switcher,t1_tsrv3_router,title-generation-harmony,pay-conversion-tracking,history-truncation-fix-parent,backstoryinsertall,local-cards,smart-mode-with-hapi,optimized-responding-for-cache,clarity-http-endpoint,share-image-continue,sharemanagement,labs-audio-expression-style-list-layout,nosearchimageonattachment,start-retry,ui-kit-paragraph-view-2,m365-cela-shee"
		"t,placecardprompclean-v3,title-generation-v2,eea-personalization-waiting-period,useggvisionmodel,study-mode,searchimages-safe,searchvideos-safe,edge-reload-tab,attachment-suggestions-c,vision-biometric-consent,page-title-generation-v2,kill-picasso-id-on-start,zircon-flight-t,browser-actions-09092025,share-campaign-ferk5z,search-pcm,detailedpromptmetrics,file-upload-config,sidebar-settings,placecard-enhance-all,n-30-k-20,pay-ams-treatment,ceo-harmony,finance-chart-clickthrough,labs-audio-expression-scripted-mode,labs-audio-expression-mode-coachmark,labs-audio-expression-story-voice-selector,thinkdeeper5reasoningloweffort,page-title-generation-hapi,skip-preview-event,m365-pills-data-v2,labs-audio-expression-auto-style,edgevision-multitab,flash-cards,finance-earnings,page-safety-check-treatment,analyzedocuments-extendedtokens,labs-audio-expression-preset-card-fixed,lazy-with-retry,sorttoolrouterresult-others-t,character-cognitive-testing-service,voice-flower-bg,thinkdeeper5miniloweffortchainofthought,image-dyn"
		"amic-width,group-conversations,share-to-invite,deep-research-share-link,cot-output-panel,imagegen-galleryremixquota,place-near-me-fix,related-results-t1,tru-router,pay-migrate-get-checkout-option-v2,voice-safety-patch,uselongcontextmodel,kill-regenerate,speechtranscribev2,browser-automation-inc-max-loop,thinkdeeper-truncator,search-truncation,backstory-trim,suppress-inline-link-nav-dialog,voice-time-formatting,balancedfiletokens,empty-tool-instruction,think-deeper-move-tool-instructions,heycopilot-backstory,vad-buffer,pay-edge-clarity,dr-progress,labs-audio-expression-story-image,remix-suggestions,ceo-remove-search-web,healthcare-safety-patch-v3,person-card,edge-safety-prompt-treatment,share-conversation-with-attachments,image-upload-mmt,dr-summary,cross-selling-t-gpt52,ceo-optimized-loop,podcast-in-voice,track-oldest-merged-message,mem-clean-forget,url-output-sanitization,gpt5-reasoning-harmony-personality-v1,config-responder-option-by-modelname,responding-loop-for-vision-model,reduce-vision-usage,dynamic-"
		"answer-cards-ga,dr-outlinks,quiz-instant-feedback,gpt-5-on-quick-mode,safety-middleware,ceo-filedownload,hide-feedback-if-no-mic-permission-on-end-call,auth-assertion,connector-consent-v2,existing-teen-enabled,voice-clear-audio-capture-listeners-on-end,dr-shared-orchestrator,memory-settings-v2,election-patch,pagecreation,add-utm-source,warnings-indepth,model-migration,route-chat-to-agent,browser-automation-instruction-gpt5,group-conversations-lazy-creation,reduce-memory-overtriggering,image-model-selector-summary,utm-tracking-use-copilot-com,checkmark-emoji-fix,groupchatnotifications,upfront-persistence,groupchat-mentions,edu-cross-sell,browser-actions-charapita,contextual-suggestions,subs-redirect-to-cmc,cef,voice-new-feedback-string,reject-tier4-start-traffic,time-patch,challenge-asn,min-adaptive-citation-t-nav,cloudflare-challenge,chat-recovery-long-streaming-timeout,enable-audio-capture-worklet,voice-memory-edf,reuse-audio-context-for-voice-output,enable-audio-out-pre-buffering-c,socket-close-track,loca"
		"l-inference-client-side-lb,auth0-based-user-link,knowledge-extraction-harmony,router-default-preload-intent,hide-conversation-dates,remove-qr,edge-shopping-enable-all-markets,deprecate_widgets_v1,edge-page-sanitization,teen-compliance,edge-ctx-consent-tool-executing,skip-reasoning-in-smart-mode,chat-client-retry,labs-remote-config,voice-name-repetition-fix,ltm-backfill-disabled,skip-append-last-user-message-again,framework-conversation-write,email-reply,voice-enable-new-audio-icon-c,backstorytool,block-image-generation-in-voice,increase-doc-attachment-max-tokens,nav-expand-all-t,remove-clarifying-prompts,readaloud-verbatim-prompt,kill-contextual-suggestions-tabs-check,podcast-project-sources-grounding,edf-store-direct-instruction,naa-has-active-account-check,computeruse-raw-cot,reduce-memory-overtrigger-location-c,search-uploaded-docs-in-project,mem-skip-preview-search,genuiskillssmallf12,searchmode-t2,browser-actions-detailed-summary,generate-flashcard-skill,browser-actions-deprecated-non-charapita,proacti"
		"ve-message-additional-context,searchfinance-searchquery,group-conversations-reuse-conv-id,voice-enable-read-aloud-c,edge-text-vision-treatment,max-adaptive-citations-c,user-message-copy,match-message-timestamp,edge-tab-safety-cache,voice-telemetry,m365-wxp-history-sync,kill-shopping-homepage-t,nav-card-short-url,kill-projects-creations-flash-card,computer-agent-skills,browser-remote-actions-for-tasks,conversation-compactor,planning-agent-elicitation,spd-citation-v2-mixed-format,agent-snapshots,group-conversations-unread-indicator,gpt52-reasoning-harmony,superbowl-search,autoprompt-off,earcon-only-after-first-use,voice-restart-telemetry,subs-hot-reload,jailbreakdisabled,pdp-track-price-comp-t,olympics-search,supersonic-task-preview,edf-memory-tuning,task-memory,trs-update-flight,block-document-generation-in-voice,task-notification,shopping-journeys-v2-container,shopping-feed-no-hero-image-t,fix-ftr,discovery-long-summary,avoid-edge-vision-highlight,agent-manager-registry,dicf6867,audioagent-v3,lm-arena-v2,wi"
		"ndows-vision-highlights,journeys-generation-v2-t,shopping-jump-back-to-conversation-c,studio-sdk,sdk-ai-message-item,sidebar-vnext,chat-session-affinity,ltm-responding-prompt-tuning-c,topic_continuation_enabled_twice_per_week,trvlflghttf,vertex-timeout,shopping-user-memory-t,fetch-convo,shadowban,update-edge-eu-user-consent-text,genui-tier3-c,genui-ground-counterfactual,discovery-harmony-timestamp,mai-whisper-language-c,gpt51-group-chat,genui-tier4-ground-flight-c,task-notification-no-timeout,shopping-journeys-v2-container-read-c,getcameraimages,web-30s-ping,v3-courteous-wait-c,shopping-feed-thumbs-feedback-toast,conversation-search-region-routing-control,edge-dont-language-switch,upsell-selector,model-training-new-privacy,voice-spatial-info,chainofthoughteventprocessor,chat-message-preview,handle-preview-event,kill-composer-creation-button,smart-mode,smart-mode-6e0b4c6f,smart-mode-cot,smart-mode-flightc,smart-mode-v2-config,searchvideos,searchvideos-google,serpvideocard,video-cards-v2,videocardrespondingin"
		"struction,edge-responder-loop,emit-all-inference-telemetry,responderactions-all,responding-harmony-4o-v4,multi-file-upload,multiple-file-upload,unlimitedfilereasoning,grounded-edit,page-citation,pages-footnote,gpt5-calcite,responding-harmony-gpt5-v1,smart-mode-default,tool-defs-on-separate-system-message,1s-moc-keep-facets,1s-moc-more-msn,1s-wpo-dis-dnewsr,1s-wpo-dis-nopod,discover-gemfive,discover-more-news-content,discover-news-all-large-cards,discover-newsts,discover-threets,think-deeper-cot,finance-follow,finance-watchlist-ui,prg-cmc-flws,prg-cmc-fnav,improve-context-precision,ds-editprompt,ds-new-progress,smart-mode-gpt5,actionspacereducerv2,longqueryfilter,tsrv3_router,enable-history-cache-write,truncatekmessages,responding-harmony-gpt-5-nosearch,responding-harmony-gpt-5-search,placecardnavigationenabled,placecardpromptoptimizationenabled,switcher-harmony,browser-actions,browserautomationcomputeruse,browserautomationsearchweb,edgeactiondisableouter,morefileupload,sidebar-compact-nav-items,sidebar-narr"
		"ow,searchplaces-enhanced-infos,searchplaces-enhanced-photos,truncatekmessages-k20,truncatekmessages-n30,pay-ams-integration-server,pay-ams-pdp,pay-ams-price-tracking,pay-ams-product-card,edge-page-safety-check,pii-scrubber,sorttoolrouterresult,relatedresults-android,relatedresults-ios,rrcitationv2,searchmode,see-more-results,toolspacereducerclassifierflight,searchweb-page3,searchweb-sd1000,searchweb-shorter,voice-search-timezone,enrich-web-grounding-with-linkedin-api,entity-info,linkedin-url,person-card-prefer-linkedin,person-cards,edge-security-template,image-ocr-hapi,merge-user-messages,deep-research-summary-v3,dr-cover-image,action-result-relaxed-json-escaping,bingify-sanitized-urls,urls-extracted-infer-event,gpt5-reasoning-harmony,thinkdeeper-gpt5reasoning-harmony-personality,dynamic-answer-cards,indepth-comparison-and-details,warnings-and-clarifications,edu-discovery-cross-sell,study-mode-mico-quiz-tutor,citation-v2,citation-v2-cards,citation-v2-nav,inline-image,inline-video,inline-video-moments,adapti"
		"ve-citations,adaptive-citations-navigation,pinned-conversation,dynamic-card-selection-instructions,nav-all-turns,nav-cards-on-all-modes,nav-hostqcscore-filter,navigation-curated-enabled,navigation-curation-gpt4o,skip-nav-classifier,generativeui-mvpt3,genui-fiximage,genui-fiximage-12,genui-json-validator,genui-mvp,genui-preturn-refactor,genui-skills,genui-skills-small,genuimvp,searchmode-gpt51-chat-harmony,searchmode-gpt51-promptv2,edge-copilot-screenshot,edge-text-vision,kill-shopping-homepage,shopping-pdp-hide-price-history,shopping-pdp-price-tracking-fallback,sorttoolsbyfrequencyflight,shopping-feed-no-hero-image,shopping-journey-staged-orchestrator,shopping-journeys-debounce,shopping-limit-concurrency,flight-booking-skill,shopping-user-memory,generativeui-flight-status,generativeui-local-events,generativeui-prayer-vertical-timeline,generativeui-sunrise-v2,genui-core,genui-counterfactual,genui-ground-t,genui-grounding-template-selector,genui-tier2-grounding-templates,genui-turncache-templates\",\"eventInf"
		"o_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"isNewUser\":false,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:98967"
		"5,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-1"
		"8,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"AppInfo_Version\":\"145.0.3800.82\",\"eventName\":\"copilotApiResponse\",\"eventInfo_path\":\"/user\",\"eventInfo_method\":\"GET\",\"eventInfo_status\":200,\"eventInfo_duration\":4830.5,\"eventInfo_responseContentLength\":681,\"eventInfo_xCDNTraceId\":\"9d7f9d447bcb6ce0-MAA\",\"eventInfo_server\":\"cloudflare\"}}\n"
		"{\"name\":\"apiresponse\",\"time\":\"2026-03-06T07:23:23.299Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":34,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_status\":{\"t\":6},\"eventInfo_duration\":{\"t\":6},\"eventInfo_responseContentLength\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edg"
		"etab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBCCDD16E182AFC5E06CC216F3A\",\"userFlightIds\":\"imagegenv3,assistant-enable-answer-cards,voice-spatial,weather-cards,edgviswebground,enable-all-app-actions,promptedreasoningcombinedwithsearchpatch,promptmessagewithcards,voices78,allowanonymoususershare,share-chat-page-entry,039add1b-use-fixed-chat-layout,share-image-link,dailybriefing,pages-table,always-show-last-reaction-v2,azureconfigregexblocklist,disable-cmc-auto-reload,onedrive,suggesthangup,correct-personalization-accidental-opt-out,share-campaign,039add1b-chat-sessions-drawer,039add1b-pages-drawer,injectselfharminstructions,039add1b-refresh-token-worker,account-change-chat-reset,preload-chat-messages,1s-moc-logosize,quiz-card-suggestion,send-connected,anonymousattachmentupload,async-disclaimer-text,mem-generate-post-turn,sharecontinue,share-campaign-taeb9y,share-campaign-krq0kf,dr-editprompt-mobile,039add1b-animated-greeting-message-view,greeting-message-animation,image"
		"-fallback-thumbnail,adsidsync,think-deeper-regenerate,smart-mode-flightd-edge,narr-icachuse,img-followup-patch,inject-user-greeting,code-edge-c,videoserp5,searchvideos-bing-fallback,searchimages-bing-fallback,edge-responding-loop-harmony-4o-1010,pay-instacart-canada,quiz-in-create-drawer,deep-research-export-file,m365-conversation-sync,deep-research-export-podcast,multiple,originaldocumentupload,web-multi-fallback-languages,share-campaign-evhqea,share-campaign-rbsrqk,share-campaign-tkzuae,share-campaign-jowp8z,share-campaign-gxcdu3,share-campaign-d2e0f5,share-campaign-dkmev6,share-campaign-coqva4,share-campaign-gez3vb,remove-extra-im-start-context,vision-in-composer-v3,deep-research-nano,export-pages-t,copilot-beta,smart-mode-default-rl,039add1b-uikit-paragraph-view,imagegenv3peakhour,onedrive-fetch,share-continue-v2,ts-dynamic-top-section-t,creator-gallery,old-search-config,thinkdeepero4minichainofthought,image-library-2,image-library-delete-image,igszcls,searchimages-cache,searchvideos-cache,pay-consisten"
		"t-buy,finance-tooltip-v2,m365-pills-custom,copilot-beta-automatic-opt-in,deep-research,quiz-option-shuffle,image-cards-v2,test-srm-aa-4,deep-research-promo-card,recipe-card,finance-watchlist-v2,finance-crypto,mutesuggestions,pages-link-navigation,pages-skip-page-selector,pages-file-upload,pages-suggested-followups,onedrive-graph,rm-relatedqna,dr-web-upd-w,dr-pro-nano,pay-getbuyoption-migration,pay-getrecipe-migration,pay-price-tracked,pay-shopify-checkout,sports-cards,smart-mode-reason-chat,pages-reasoning-gg,edge-autosuggest,composer-v4,039add1b-sentry-hang-rate-v2,voice-improved-courtesy-wait,quiz-harmony,sticky-conversation-mode,smart-mode-ensemble-switcher,t1_tsrv3_router,title-generation-harmony,pay-conversion-tracking,history-truncation-fix-parent,backstoryinsertall,local-cards,smart-mode-with-hapi,optimized-responding-for-cache,clarity-http-endpoint,share-image-continue,sharemanagement,labs-audio-expression-style-list-layout,nosearchimageonattachment,start-retry,ui-kit-paragraph-view-2,m365-cela-shee"
		"t,placecardprompclean-v3,title-generation-v2,eea-personalization-waiting-period,useggvisionmodel,study-mode,searchimages-safe,searchvideos-safe,edge-reload-tab,attachment-suggestions-c,vision-biometric-consent,page-title-generation-v2,kill-picasso-id-on-start,zircon-flight-t,browser-actions-09092025,share-campaign-ferk5z,search-pcm,detailedpromptmetrics,file-upload-config,sidebar-settings,placecard-enhance-all,n-30-k-20,pay-ams-treatment,ceo-harmony,finance-chart-clickthrough,labs-audio-expression-scripted-mode,labs-audio-expression-mode-coachmark,labs-audio-expression-story-voice-selector,thinkdeeper5reasoningloweffort,page-title-generation-hapi,skip-preview-event,m365-pills-data-v2,labs-audio-expression-auto-style,edgevision-multitab,flash-cards,finance-earnings,page-safety-check-treatment,analyzedocuments-extendedtokens,labs-audio-expression-preset-card-fixed,lazy-with-retry,sorttoolrouterresult-others-t,character-cognitive-testing-service,voice-flower-bg,thinkdeeper5miniloweffortchainofthought,image-dyn"
		"amic-width,group-conversations,share-to-invite,deep-research-share-link,cot-output-panel,imagegen-galleryremixquota,place-near-me-fix,related-results-t1,tru-router,pay-migrate-get-checkout-option-v2,voice-safety-patch,uselongcontextmodel,kill-regenerate,speechtranscribev2,browser-automation-inc-max-loop,thinkdeeper-truncator,search-truncation,backstory-trim,suppress-inline-link-nav-dialog,voice-time-formatting,balancedfiletokens,empty-tool-instruction,think-deeper-move-tool-instructions,heycopilot-backstory,vad-buffer,pay-edge-clarity,dr-progress,labs-audio-expression-story-image,remix-suggestions,ceo-remove-search-web,healthcare-safety-patch-v3,person-card,edge-safety-prompt-treatment,share-conversation-with-attachments,image-upload-mmt,dr-summary,cross-selling-t-gpt52,ceo-optimized-loop,podcast-in-voice,track-oldest-merged-message,mem-clean-forget,url-output-sanitization,gpt5-reasoning-harmony-personality-v1,config-responder-option-by-modelname,responding-loop-for-vision-model,reduce-vision-usage,dynamic-"
		"answer-cards-ga,dr-outlinks,quiz-instant-feedback,gpt-5-on-quick-mode,safety-middleware,ceo-filedownload,hide-feedback-if-no-mic-permission-on-end-call,auth-assertion,connector-consent-v2,existing-teen-enabled,voice-clear-audio-capture-listeners-on-end,dr-shared-orchestrator,memory-settings-v2,election-patch,pagecreation,add-utm-source,warnings-indepth,model-migration,route-chat-to-agent,browser-automation-instruction-gpt5,group-conversations-lazy-creation,reduce-memory-overtriggering,image-model-selector-summary,utm-tracking-use-copilot-com,checkmark-emoji-fix,groupchatnotifications,upfront-persistence,groupchat-mentions,edu-cross-sell,browser-actions-charapita,contextual-suggestions,subs-redirect-to-cmc,cef,voice-new-feedback-string,reject-tier4-start-traffic,time-patch,challenge-asn,min-adaptive-citation-t-nav,cloudflare-challenge,chat-recovery-long-streaming-timeout,enable-audio-capture-worklet,voice-memory-edf,reuse-audio-context-for-voice-output,enable-audio-out-pre-buffering-c,socket-close-track,loca"
		"l-inference-client-side-lb,auth0-based-user-link,knowledge-extraction-harmony,router-default-preload-intent,hide-conversation-dates,remove-qr,edge-shopping-enable-all-markets,deprecate_widgets_v1,edge-page-sanitization,teen-compliance,edge-ctx-consent-tool-executing,skip-reasoning-in-smart-mode,chat-client-retry,labs-remote-config,voice-name-repetition-fix,ltm-backfill-disabled,skip-append-last-user-message-again,framework-conversation-write,email-reply,voice-enable-new-audio-icon-c,backstorytool,block-image-generation-in-voice,increase-doc-attachment-max-tokens,nav-expand-all-t,remove-clarifying-prompts,readaloud-verbatim-prompt,kill-contextual-suggestions-tabs-check,podcast-project-sources-grounding,edf-store-direct-instruction,naa-has-active-account-check,computeruse-raw-cot,reduce-memory-overtrigger-location-c,search-uploaded-docs-in-project,mem-skip-preview-search,genuiskillssmallf12,searchmode-t2,browser-actions-detailed-summary,generate-flashcard-skill,browser-actions-deprecated-non-charapita,proacti"
		"ve-message-additional-context,searchfinance-searchquery,group-conversations-reuse-conv-id,voice-enable-read-aloud-c,edge-text-vision-treatment,max-adaptive-citations-c,user-message-copy,match-message-timestamp,edge-tab-safety-cache,voice-telemetry,m365-wxp-history-sync,kill-shopping-homepage-t,nav-card-short-url,kill-projects-creations-flash-card,computer-agent-skills,browser-remote-actions-for-tasks,conversation-compactor,planning-agent-elicitation,spd-citation-v2-mixed-format,agent-snapshots,group-conversations-unread-indicator,gpt52-reasoning-harmony,superbowl-search,autoprompt-off,earcon-only-after-first-use,voice-restart-telemetry,subs-hot-reload,jailbreakdisabled,pdp-track-price-comp-t,olympics-search,supersonic-task-preview,edf-memory-tuning,task-memory,trs-update-flight,block-document-generation-in-voice,task-notification,shopping-journeys-v2-container,shopping-feed-no-hero-image-t,fix-ftr,discovery-long-summary,avoid-edge-vision-highlight,agent-manager-registry,dicf6867,audioagent-v3,lm-arena-v2,wi"
		"ndows-vision-highlights,journeys-generation-v2-t,shopping-jump-back-to-conversation-c,studio-sdk,sdk-ai-message-item,sidebar-vnext,chat-session-affinity,ltm-responding-prompt-tuning-c,topic_continuation_enabled_twice_per_week,trvlflghttf,vertex-timeout,shopping-user-memory-t,fetch-convo,shadowban,update-edge-eu-user-consent-text,genui-tier3-c,genui-ground-counterfactual,discovery-harmony-timestamp,mai-whisper-language-c,gpt51-group-chat,genui-tier4-ground-flight-c,task-notification-no-timeout,shopping-journeys-v2-container-read-c,getcameraimages,web-30s-ping,v3-courteous-wait-c,shopping-feed-thumbs-feedback-toast,conversation-search-region-routing-control,edge-dont-language-switch,upsell-selector,model-training-new-privacy,voice-spatial-info,chainofthoughteventprocessor,chat-message-preview,handle-preview-event,kill-composer-creation-button,smart-mode,smart-mode-6e0b4c6f,smart-mode-cot,smart-mode-flightc,smart-mode-v2-config,searchvideos,searchvideos-google,serpvideocard,video-cards-v2,videocardrespondingin"
		"struction,edge-responder-loop,emit-all-inference-telemetry,responderactions-all,responding-harmony-4o-v4,multi-file-upload,multiple-file-upload,unlimitedfilereasoning,grounded-edit,page-citation,pages-footnote,gpt5-calcite,responding-harmony-gpt5-v1,smart-mode-default,tool-defs-on-separate-system-message,1s-moc-keep-facets,1s-moc-more-msn,1s-wpo-dis-dnewsr,1s-wpo-dis-nopod,discover-gemfive,discover-more-news-content,discover-news-all-large-cards,discover-newsts,discover-threets,think-deeper-cot,finance-follow,finance-watchlist-ui,prg-cmc-flws,prg-cmc-fnav,improve-context-precision,ds-editprompt,ds-new-progress,smart-mode-gpt5,actionspacereducerv2,longqueryfilter,tsrv3_router,enable-history-cache-write,truncatekmessages,responding-harmony-gpt-5-nosearch,responding-harmony-gpt-5-search,placecardnavigationenabled,placecardpromptoptimizationenabled,switcher-harmony,browser-actions,browserautomationcomputeruse,browserautomationsearchweb,edgeactiondisableouter,morefileupload,sidebar-compact-nav-items,sidebar-narr"
		"ow,searchplaces-enhanced-infos,searchplaces-enhanced-photos,truncatekmessages-k20,truncatekmessages-n30,pay-ams-integration-server,pay-ams-pdp,pay-ams-price-tracking,pay-ams-product-card,edge-page-safety-check,pii-scrubber,sorttoolrouterresult,relatedresults-android,relatedresults-ios,rrcitationv2,searchmode,see-more-results,toolspacereducerclassifierflight,searchweb-page3,searchweb-sd1000,searchweb-shorter,voice-search-timezone,enrich-web-grounding-with-linkedin-api,entity-info,linkedin-url,person-card-prefer-linkedin,person-cards,edge-security-template,image-ocr-hapi,merge-user-messages,deep-research-summary-v3,dr-cover-image,action-result-relaxed-json-escaping,bingify-sanitized-urls,urls-extracted-infer-event,gpt5-reasoning-harmony,thinkdeeper-gpt5reasoning-harmony-personality,dynamic-answer-cards,indepth-comparison-and-details,warnings-and-clarifications,edu-discovery-cross-sell,study-mode-mico-quiz-tutor,citation-v2,citation-v2-cards,citation-v2-nav,inline-image,inline-video,inline-video-moments,adapti"
		"ve-citations,adaptive-citations-navigation,pinned-conversation,dynamic-card-selection-instructions,nav-all-turns,nav-cards-on-all-modes,nav-hostqcscore-filter,navigation-curated-enabled,navigation-curation-gpt4o,skip-nav-classifier,generativeui-mvpt3,genui-fiximage,genui-fiximage-12,genui-json-validator,genui-mvp,genui-preturn-refactor,genui-skills,genui-skills-small,genuimvp,searchmode-gpt51-chat-harmony,searchmode-gpt51-promptv2,edge-copilot-screenshot,edge-text-vision,kill-shopping-homepage,shopping-pdp-hide-price-history,shopping-pdp-price-tracking-fallback,sorttoolsbyfrequencyflight,shopping-feed-no-hero-image,shopping-journey-staged-orchestrator,shopping-journeys-debounce,shopping-limit-concurrency,flight-booking-skill,shopping-user-memory,generativeui-flight-status,generativeui-local-events,generativeui-prayer-vertical-timeline,generativeui-sunrise-v2,genui-core,genui-counterfactual,genui-ground-t,genui-grounding-template-selector,genui-tier2-grounding-templates,genui-turncache-templates\",\"eventInf"
		"o_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"isNewUser\":false,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:98967"
		"5,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-1"
		"8,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"AppInfo_Version\":\"145.0.3800.82\",\"eventName\":\"copilotApiResponse\",\"eventInfo_path\":\"/library/recent\",\"eventInfo_method\":\"GET\",\"eventInfo_status\":200,\"eventInfo_duration\":4829.800000071526,\"eventInfo_responseContentLength\":26,\"eventInfo_xCDNTraceId\":\"9d7f9d447bdc6ce0-MAA\",\"eventInfo_server\":\"cloudflare\"}}\n"
		"{\"name\":\"apiresponse\",\"time\":\"2026-03-06T07:23:23.302Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":35,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_status\":{\"t\":6},\"eventInfo_duration\":{\"t\":6},\"eventInfo_responseContentLength\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edg"
		"etab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBCCDD16E182AFC5E06CC216F3A\",\"userFlightIds\":\"imagegenv3,assistant-enable-answer-cards,voice-spatial,weather-cards,edgviswebground,enable-all-app-actions,promptedreasoningcombinedwithsearchpatch,promptmessagewithcards,voices78,allowanonymoususershare,share-chat-page-entry,039add1b-use-fixed-chat-layout,share-image-link,dailybriefing,pages-table,always-show-last-reaction-v2,azureconfigregexblocklist,disable-cmc-auto-reload,onedrive,suggesthangup,correct-personalization-accidental-opt-out,share-campaign,039add1b-chat-sessions-drawer,039add1b-pages-drawer,injectselfharminstructions,039add1b-refresh-token-worker,account-change-chat-reset,preload-chat-messages,1s-moc-logosize,quiz-card-suggestion,send-connected,anonymousattachmentupload,async-disclaimer-text,mem-generate-post-turn,sharecontinue,share-campaign-taeb9y,share-campaign-krq0kf,dr-editprompt-mobile,039add1b-animated-greeting-message-view,greeting-message-animation,image"
		"-fallback-thumbnail,adsidsync,think-deeper-regenerate,smart-mode-flightd-edge,narr-icachuse,img-followup-patch,inject-user-greeting,code-edge-c,videoserp5,searchvideos-bing-fallback,searchimages-bing-fallback,edge-responding-loop-harmony-4o-1010,pay-instacart-canada,quiz-in-create-drawer,deep-research-export-file,m365-conversation-sync,deep-research-export-podcast,multiple,originaldocumentupload,web-multi-fallback-languages,share-campaign-evhqea,share-campaign-rbsrqk,share-campaign-tkzuae,share-campaign-jowp8z,share-campaign-gxcdu3,share-campaign-d2e0f5,share-campaign-dkmev6,share-campaign-coqva4,share-campaign-gez3vb,remove-extra-im-start-context,vision-in-composer-v3,deep-research-nano,export-pages-t,copilot-beta,smart-mode-default-rl,039add1b-uikit-paragraph-view,imagegenv3peakhour,onedrive-fetch,share-continue-v2,ts-dynamic-top-section-t,creator-gallery,old-search-config,thinkdeepero4minichainofthought,image-library-2,image-library-delete-image,igszcls,searchimages-cache,searchvideos-cache,pay-consisten"
		"t-buy,finance-tooltip-v2,m365-pills-custom,copilot-beta-automatic-opt-in,deep-research,quiz-option-shuffle,image-cards-v2,test-srm-aa-4,deep-research-promo-card,recipe-card,finance-watchlist-v2,finance-crypto,mutesuggestions,pages-link-navigation,pages-skip-page-selector,pages-file-upload,pages-suggested-followups,onedrive-graph,rm-relatedqna,dr-web-upd-w,dr-pro-nano,pay-getbuyoption-migration,pay-getrecipe-migration,pay-price-tracked,pay-shopify-checkout,sports-cards,smart-mode-reason-chat,pages-reasoning-gg,edge-autosuggest,composer-v4,039add1b-sentry-hang-rate-v2,voice-improved-courtesy-wait,quiz-harmony,sticky-conversation-mode,smart-mode-ensemble-switcher,t1_tsrv3_router,title-generation-harmony,pay-conversion-tracking,history-truncation-fix-parent,backstoryinsertall,local-cards,smart-mode-with-hapi,optimized-responding-for-cache,clarity-http-endpoint,share-image-continue,sharemanagement,labs-audio-expression-style-list-layout,nosearchimageonattachment,start-retry,ui-kit-paragraph-view-2,m365-cela-shee"
		"t,placecardprompclean-v3,title-generation-v2,eea-personalization-waiting-period,useggvisionmodel,study-mode,searchimages-safe,searchvideos-safe,edge-reload-tab,attachment-suggestions-c,vision-biometric-consent,page-title-generation-v2,kill-picasso-id-on-start,zircon-flight-t,browser-actions-09092025,share-campaign-ferk5z,search-pcm,detailedpromptmetrics,file-upload-config,sidebar-settings,placecard-enhance-all,n-30-k-20,pay-ams-treatment,ceo-harmony,finance-chart-clickthrough,labs-audio-expression-scripted-mode,labs-audio-expression-mode-coachmark,labs-audio-expression-story-voice-selector,thinkdeeper5reasoningloweffort,page-title-generation-hapi,skip-preview-event,m365-pills-data-v2,labs-audio-expression-auto-style,edgevision-multitab,flash-cards,finance-earnings,page-safety-check-treatment,analyzedocuments-extendedtokens,labs-audio-expression-preset-card-fixed,lazy-with-retry,sorttoolrouterresult-others-t,character-cognitive-testing-service,voice-flower-bg,thinkdeeper5miniloweffortchainofthought,image-dyn"
		"amic-width,group-conversations,share-to-invite,deep-research-share-link,cot-output-panel,imagegen-galleryremixquota,place-near-me-fix,related-results-t1,tru-router,pay-migrate-get-checkout-option-v2,voice-safety-patch,uselongcontextmodel,kill-regenerate,speechtranscribev2,browser-automation-inc-max-loop,thinkdeeper-truncator,search-truncation,backstory-trim,suppress-inline-link-nav-dialog,voice-time-formatting,balancedfiletokens,empty-tool-instruction,think-deeper-move-tool-instructions,heycopilot-backstory,vad-buffer,pay-edge-clarity,dr-progress,labs-audio-expression-story-image,remix-suggestions,ceo-remove-search-web,healthcare-safety-patch-v3,person-card,edge-safety-prompt-treatment,share-conversation-with-attachments,image-upload-mmt,dr-summary,cross-selling-t-gpt52,ceo-optimized-loop,podcast-in-voice,track-oldest-merged-message,mem-clean-forget,url-output-sanitization,gpt5-reasoning-harmony-personality-v1,config-responder-option-by-modelname,responding-loop-for-vision-model,reduce-vision-usage,dynamic-"
		"answer-cards-ga,dr-outlinks,quiz-instant-feedback,gpt-5-on-quick-mode,safety-middleware,ceo-filedownload,hide-feedback-if-no-mic-permission-on-end-call,auth-assertion,connector-consent-v2,existing-teen-enabled,voice-clear-audio-capture-listeners-on-end,dr-shared-orchestrator,memory-settings-v2,election-patch,pagecreation,add-utm-source,warnings-indepth,model-migration,route-chat-to-agent,browser-automation-instruction-gpt5,group-conversations-lazy-creation,reduce-memory-overtriggering,image-model-selector-summary,utm-tracking-use-copilot-com,checkmark-emoji-fix,groupchatnotifications,upfront-persistence,groupchat-mentions,edu-cross-sell,browser-actions-charapita,contextual-suggestions,subs-redirect-to-cmc,cef,voice-new-feedback-string,reject-tier4-start-traffic,time-patch,challenge-asn,min-adaptive-citation-t-nav,cloudflare-challenge,chat-recovery-long-streaming-timeout,enable-audio-capture-worklet,voice-memory-edf,reuse-audio-context-for-voice-output,enable-audio-out-pre-buffering-c,socket-close-track,loca"
		"l-inference-client-side-lb,auth0-based-user-link,knowledge-extraction-harmony,router-default-preload-intent,hide-conversation-dates,remove-qr,edge-shopping-enable-all-markets,deprecate_widgets_v1,edge-page-sanitization,teen-compliance,edge-ctx-consent-tool-executing,skip-reasoning-in-smart-mode,chat-client-retry,labs-remote-config,voice-name-repetition-fix,ltm-backfill-disabled,skip-append-last-user-message-again,framework-conversation-write,email-reply,voice-enable-new-audio-icon-c,backstorytool,block-image-generation-in-voice,increase-doc-attachment-max-tokens,nav-expand-all-t,remove-clarifying-prompts,readaloud-verbatim-prompt,kill-contextual-suggestions-tabs-check,podcast-project-sources-grounding,edf-store-direct-instruction,naa-has-active-account-check,computeruse-raw-cot,reduce-memory-overtrigger-location-c,search-uploaded-docs-in-project,mem-skip-preview-search,genuiskillssmallf12,searchmode-t2,browser-actions-detailed-summary,generate-flashcard-skill,browser-actions-deprecated-non-charapita,proacti"
		"ve-message-additional-context,searchfinance-searchquery,group-conversations-reuse-conv-id,voice-enable-read-aloud-c,edge-text-vision-treatment,max-adaptive-citations-c,user-message-copy,match-message-timestamp,edge-tab-safety-cache,voice-telemetry,m365-wxp-history-sync,kill-shopping-homepage-t,nav-card-short-url,kill-projects-creations-flash-card,computer-agent-skills,browser-remote-actions-for-tasks,conversation-compactor,planning-agent-elicitation,spd-citation-v2-mixed-format,agent-snapshots,group-conversations-unread-indicator,gpt52-reasoning-harmony,superbowl-search,autoprompt-off,earcon-only-after-first-use,voice-restart-telemetry,subs-hot-reload,jailbreakdisabled,pdp-track-price-comp-t,olympics-search,supersonic-task-preview,edf-memory-tuning,task-memory,trs-update-flight,block-document-generation-in-voice,task-notification,shopping-journeys-v2-container,shopping-feed-no-hero-image-t,fix-ftr,discovery-long-summary,avoid-edge-vision-highlight,agent-manager-registry,dicf6867,audioagent-v3,lm-arena-v2,wi"
		"ndows-vision-highlights,journeys-generation-v2-t,shopping-jump-back-to-conversation-c,studio-sdk,sdk-ai-message-item,sidebar-vnext,chat-session-affinity,ltm-responding-prompt-tuning-c,topic_continuation_enabled_twice_per_week,trvlflghttf,vertex-timeout,shopping-user-memory-t,fetch-convo,shadowban,update-edge-eu-user-consent-text,genui-tier3-c,genui-ground-counterfactual,discovery-harmony-timestamp,mai-whisper-language-c,gpt51-group-chat,genui-tier4-ground-flight-c,task-notification-no-timeout,shopping-journeys-v2-container-read-c,getcameraimages,web-30s-ping,v3-courteous-wait-c,shopping-feed-thumbs-feedback-toast,conversation-search-region-routing-control,edge-dont-language-switch,upsell-selector,model-training-new-privacy,voice-spatial-info,chainofthoughteventprocessor,chat-message-preview,handle-preview-event,kill-composer-creation-button,smart-mode,smart-mode-6e0b4c6f,smart-mode-cot,smart-mode-flightc,smart-mode-v2-config,searchvideos,searchvideos-google,serpvideocard,video-cards-v2,videocardrespondingin"
		"struction,edge-responder-loop,emit-all-inference-telemetry,responderactions-all,responding-harmony-4o-v4,multi-file-upload,multiple-file-upload,unlimitedfilereasoning,grounded-edit,page-citation,pages-footnote,gpt5-calcite,responding-harmony-gpt5-v1,smart-mode-default,tool-defs-on-separate-system-message,1s-moc-keep-facets,1s-moc-more-msn,1s-wpo-dis-dnewsr,1s-wpo-dis-nopod,discover-gemfive,discover-more-news-content,discover-news-all-large-cards,discover-newsts,discover-threets,think-deeper-cot,finance-follow,finance-watchlist-ui,prg-cmc-flws,prg-cmc-fnav,improve-context-precision,ds-editprompt,ds-new-progress,smart-mode-gpt5,actionspacereducerv2,longqueryfilter,tsrv3_router,enable-history-cache-write,truncatekmessages,responding-harmony-gpt-5-nosearch,responding-harmony-gpt-5-search,placecardnavigationenabled,placecardpromptoptimizationenabled,switcher-harmony,browser-actions,browserautomationcomputeruse,browserautomationsearchweb,edgeactiondisableouter,morefileupload,sidebar-compact-nav-items,sidebar-narr"
		"ow,searchplaces-enhanced-infos,searchplaces-enhanced-photos,truncatekmessages-k20,truncatekmessages-n30,pay-ams-integration-server,pay-ams-pdp,pay-ams-price-tracking,pay-ams-product-card,edge-page-safety-check,pii-scrubber,sorttoolrouterresult,relatedresults-android,relatedresults-ios,rrcitationv2,searchmode,see-more-results,toolspacereducerclassifierflight,searchweb-page3,searchweb-sd1000,searchweb-shorter,voice-search-timezone,enrich-web-grounding-with-linkedin-api,entity-info,linkedin-url,person-card-prefer-linkedin,person-cards,edge-security-template,image-ocr-hapi,merge-user-messages,deep-research-summary-v3,dr-cover-image,action-result-relaxed-json-escaping,bingify-sanitized-urls,urls-extracted-infer-event,gpt5-reasoning-harmony,thinkdeeper-gpt5reasoning-harmony-personality,dynamic-answer-cards,indepth-comparison-and-details,warnings-and-clarifications,edu-discovery-cross-sell,study-mode-mico-quiz-tutor,citation-v2,citation-v2-cards,citation-v2-nav,inline-image,inline-video,inline-video-moments,adapti"
		"ve-citations,adaptive-citations-navigation,pinned-conversation,dynamic-card-selection-instructions,nav-all-turns,nav-cards-on-all-modes,nav-hostqcscore-filter,navigation-curated-enabled,navigation-curation-gpt4o,skip-nav-classifier,generativeui-mvpt3,genui-fiximage,genui-fiximage-12,genui-json-validator,genui-mvp,genui-preturn-refactor,genui-skills,genui-skills-small,genuimvp,searchmode-gpt51-chat-harmony,searchmode-gpt51-promptv2,edge-copilot-screenshot,edge-text-vision,kill-shopping-homepage,shopping-pdp-hide-price-history,shopping-pdp-price-tracking-fallback,sorttoolsbyfrequencyflight,shopping-feed-no-hero-image,shopping-journey-staged-orchestrator,shopping-journeys-debounce,shopping-limit-concurrency,flight-booking-skill,shopping-user-memory,generativeui-flight-status,generativeui-local-events,generativeui-prayer-vertical-timeline,generativeui-sunrise-v2,genui-core,genui-counterfactual,genui-ground-t,genui-grounding-template-selector,genui-tier2-grounding-templates,genui-turncache-templates\",\"eventInf"
		"o_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"isNewUser\":false,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:98967"
		"5,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-1"
		"8,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"AppInfo_Version\":\"145.0.3800.82\",\"eventName\":\"copilotApiResponse\",\"eventInfo_path\":\"/conversations\",\"eventInfo_method\":\"GET\",\"eventInfo_status\":200,\"eventInfo_duration\":4832.5,\"eventInfo_responseContentLength\":1295,\"eventInfo_xCDNTraceId\":\"9d7f9d447bc76ce0-MAA\",\"eventInfo_server\":\"cloudflare\"}}\n"
		"{\"name\":\"system\",\"time\":\"2026-03-06T07:23:23.309Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":36,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBCCDD16E182AFC5E06CC216F3A\",\"userFlightIds\":\"imagegen"
		"v3,assistant-enable-answer-cards,voice-spatial,weather-cards,edgviswebground,enable-all-app-actions,promptedreasoningcombinedwithsearchpatch,promptmessagewithcards,voices78,allowanonymoususershare,share-chat-page-entry,039add1b-use-fixed-chat-layout,share-image-link,dailybriefing,pages-table,always-show-last-reaction-v2,azureconfigregexblocklist,disable-cmc-auto-reload,onedrive,suggesthangup,correct-personalization-accidental-opt-out,share-campaign,039add1b-chat-sessions-drawer,039add1b-pages-drawer,injectselfharminstructions,039add1b-refresh-token-worker,account-change-chat-reset,preload-chat-messages,1s-moc-logosize,quiz-card-suggestion,send-connected,anonymousattachmentupload,async-disclaimer-text,mem-generate-post-turn,sharecontinue,share-campaign-taeb9y,share-campaign-krq0kf,dr-editprompt-mobile,039add1b-animated-greeting-message-view,greeting-message-animation,image-fallback-thumbnail,adsidsync,think-deeper-regenerate,smart-mode-flightd-edge,narr-icachuse,img-followup-patch,inject-user-greeting,code-e"
		"dge-c,videoserp5,searchvideos-bing-fallback,searchimages-bing-fallback,edge-responding-loop-harmony-4o-1010,pay-instacart-canada,quiz-in-create-drawer,deep-research-export-file,m365-conversation-sync,deep-research-export-podcast,multiple,originaldocumentupload,web-multi-fallback-languages,share-campaign-evhqea,share-campaign-rbsrqk,share-campaign-tkzuae,share-campaign-jowp8z,share-campaign-gxcdu3,share-campaign-d2e0f5,share-campaign-dkmev6,share-campaign-coqva4,share-campaign-gez3vb,remove-extra-im-start-context,vision-in-composer-v3,deep-research-nano,export-pages-t,copilot-beta,smart-mode-default-rl,039add1b-uikit-paragraph-view,imagegenv3peakhour,onedrive-fetch,share-continue-v2,ts-dynamic-top-section-t,creator-gallery,old-search-config,thinkdeepero4minichainofthought,image-library-2,image-library-delete-image,igszcls,searchimages-cache,searchvideos-cache,pay-consistent-buy,finance-tooltip-v2,m365-pills-custom,copilot-beta-automatic-opt-in,deep-research,quiz-option-shuffle,image-cards-v2,test-srm-aa-4,de"
		"ep-research-promo-card,recipe-card,finance-watchlist-v2,finance-crypto,mutesuggestions,pages-link-navigation,pages-skip-page-selector,pages-file-upload,pages-suggested-followups,onedrive-graph,rm-relatedqna,dr-web-upd-w,dr-pro-nano,pay-getbuyoption-migration,pay-getrecipe-migration,pay-price-tracked,pay-shopify-checkout,sports-cards,smart-mode-reason-chat,pages-reasoning-gg,edge-autosuggest,composer-v4,039add1b-sentry-hang-rate-v2,voice-improved-courtesy-wait,quiz-harmony,sticky-conversation-mode,smart-mode-ensemble-switcher,t1_tsrv3_router,title-generation-harmony,pay-conversion-tracking,history-truncation-fix-parent,backstoryinsertall,local-cards,smart-mode-with-hapi,optimized-responding-for-cache,clarity-http-endpoint,share-image-continue,sharemanagement,labs-audio-expression-style-list-layout,nosearchimageonattachment,start-retry,ui-kit-paragraph-view-2,m365-cela-sheet,placecardprompclean-v3,title-generation-v2,eea-personalization-waiting-period,useggvisionmodel,study-mode,searchimages-safe,searchvideos"
		"-safe,edge-reload-tab,attachment-suggestions-c,vision-biometric-consent,page-title-generation-v2,kill-picasso-id-on-start,zircon-flight-t,browser-actions-09092025,share-campaign-ferk5z,search-pcm,detailedpromptmetrics,file-upload-config,sidebar-settings,placecard-enhance-all,n-30-k-20,pay-ams-treatment,ceo-harmony,finance-chart-clickthrough,labs-audio-expression-scripted-mode,labs-audio-expression-mode-coachmark,labs-audio-expression-story-voice-selector,thinkdeeper5reasoningloweffort,page-title-generation-hapi,skip-preview-event,m365-pills-data-v2,labs-audio-expression-auto-style,edgevision-multitab,flash-cards,finance-earnings,page-safety-check-treatment,analyzedocuments-extendedtokens,labs-audio-expression-preset-card-fixed,lazy-with-retry,sorttoolrouterresult-others-t,character-cognitive-testing-service,voice-flower-bg,thinkdeeper5miniloweffortchainofthought,image-dynamic-width,group-conversations,share-to-invite,deep-research-share-link,cot-output-panel,imagegen-galleryremixquota,place-near-me-fix,rela"
		"ted-results-t1,tru-router,pay-migrate-get-checkout-option-v2,voice-safety-patch,uselongcontextmodel,kill-regenerate,speechtranscribev2,browser-automation-inc-max-loop,thinkdeeper-truncator,search-truncation,backstory-trim,suppress-inline-link-nav-dialog,voice-time-formatting,balancedfiletokens,empty-tool-instruction,think-deeper-move-tool-instructions,heycopilot-backstory,vad-buffer,pay-edge-clarity,dr-progress,labs-audio-expression-story-image,remix-suggestions,ceo-remove-search-web,healthcare-safety-patch-v3,person-card,edge-safety-prompt-treatment,share-conversation-with-attachments,image-upload-mmt,dr-summary,cross-selling-t-gpt52,ceo-optimized-loop,podcast-in-voice,track-oldest-merged-message,mem-clean-forget,url-output-sanitization,gpt5-reasoning-harmony-personality-v1,config-responder-option-by-modelname,responding-loop-for-vision-model,reduce-vision-usage,dynamic-answer-cards-ga,dr-outlinks,quiz-instant-feedback,gpt-5-on-quick-mode,safety-middleware,ceo-filedownload,hide-feedback-if-no-mic-permissio"
		"n-on-end-call,auth-assertion,connector-consent-v2,existing-teen-enabled,voice-clear-audio-capture-listeners-on-end,dr-shared-orchestrator,memory-settings-v2,election-patch,pagecreation,add-utm-source,warnings-indepth,model-migration,route-chat-to-agent,browser-automation-instruction-gpt5,group-conversations-lazy-creation,reduce-memory-overtriggering,image-model-selector-summary,utm-tracking-use-copilot-com,checkmark-emoji-fix,groupchatnotifications,upfront-persistence,groupchat-mentions,edu-cross-sell,browser-actions-charapita,contextual-suggestions,subs-redirect-to-cmc,cef,voice-new-feedback-string,reject-tier4-start-traffic,time-patch,challenge-asn,min-adaptive-citation-t-nav,cloudflare-challenge,chat-recovery-long-streaming-timeout,enable-audio-capture-worklet,voice-memory-edf,reuse-audio-context-for-voice-output,enable-audio-out-pre-buffering-c,socket-close-track,local-inference-client-side-lb,auth0-based-user-link,knowledge-extraction-harmony,router-default-preload-intent,hide-conversation-dates,remove"
		"-qr,edge-shopping-enable-all-markets,deprecate_widgets_v1,edge-page-sanitization,teen-compliance,edge-ctx-consent-tool-executing,skip-reasoning-in-smart-mode,chat-client-retry,labs-remote-config,voice-name-repetition-fix,ltm-backfill-disabled,skip-append-last-user-message-again,framework-conversation-write,email-reply,voice-enable-new-audio-icon-c,backstorytool,block-image-generation-in-voice,increase-doc-attachment-max-tokens,nav-expand-all-t,remove-clarifying-prompts,readaloud-verbatim-prompt,kill-contextual-suggestions-tabs-check,podcast-project-sources-grounding,edf-store-direct-instruction,naa-has-active-account-check,computeruse-raw-cot,reduce-memory-overtrigger-location-c,search-uploaded-docs-in-project,mem-skip-preview-search,genuiskillssmallf12,searchmode-t2,browser-actions-detailed-summary,generate-flashcard-skill,browser-actions-deprecated-non-charapita,proactive-message-additional-context,searchfinance-searchquery,group-conversations-reuse-conv-id,voice-enable-read-aloud-c,edge-text-vision-treat"
		"ment,max-adaptive-citations-c,user-message-copy,match-message-timestamp,edge-tab-safety-cache,voice-telemetry,m365-wxp-history-sync,kill-shopping-homepage-t,nav-card-short-url,kill-projects-creations-flash-card,computer-agent-skills,browser-remote-actions-for-tasks,conversation-compactor,planning-agent-elicitation,spd-citation-v2-mixed-format,agent-snapshots,group-conversations-unread-indicator,gpt52-reasoning-harmony,superbowl-search,autoprompt-off,earcon-only-after-first-use,voice-restart-telemetry,subs-hot-reload,jailbreakdisabled,pdp-track-price-comp-t,olympics-search,supersonic-task-preview,edf-memory-tuning,task-memory,trs-update-flight,block-document-generation-in-voice,task-notification,shopping-journeys-v2-container,shopping-feed-no-hero-image-t,fix-ftr,discovery-long-summary,avoid-edge-vision-highlight,agent-manager-registry,dicf6867,audioagent-v3,lm-arena-v2,windows-vision-highlights,journeys-generation-v2-t,shopping-jump-back-to-conversation-c,studio-sdk,sdk-ai-message-item,sidebar-vnext,chat-se"
		"ssion-affinity,ltm-responding-prompt-tuning-c,topic_continuation_enabled_twice_per_week,trvlflghttf,vertex-timeout,shopping-user-memory-t,fetch-convo,shadowban,update-edge-eu-user-consent-text,genui-tier3-c,genui-ground-counterfactual,discovery-harmony-timestamp,mai-whisper-language-c,gpt51-group-chat,genui-tier4-ground-flight-c,task-notification-no-timeout,shopping-journeys-v2-container-read-c,getcameraimages,web-30s-ping,v3-courteous-wait-c,shopping-feed-thumbs-feedback-toast,conversation-search-region-routing-control,edge-dont-language-switch,upsell-selector,model-training-new-privacy,voice-spatial-info,chainofthoughteventprocessor,chat-message-preview,handle-preview-event,kill-composer-creation-button,smart-mode,smart-mode-6e0b4c6f,smart-mode-cot,smart-mode-flightc,smart-mode-v2-config,searchvideos,searchvideos-google,serpvideocard,video-cards-v2,videocardrespondinginstruction,edge-responder-loop,emit-all-inference-telemetry,responderactions-all,responding-harmony-4o-v4,multi-file-upload,multiple-file-u"
		"pload,unlimitedfilereasoning,grounded-edit,page-citation,pages-footnote,gpt5-calcite,responding-harmony-gpt5-v1,smart-mode-default,tool-defs-on-separate-system-message,1s-moc-keep-facets,1s-moc-more-msn,1s-wpo-dis-dnewsr,1s-wpo-dis-nopod,discover-gemfive,discover-more-news-content,discover-news-all-large-cards,discover-newsts,discover-threets,think-deeper-cot,finance-follow,finance-watchlist-ui,prg-cmc-flws,prg-cmc-fnav,improve-context-precision,ds-editprompt,ds-new-progress,smart-mode-gpt5,actionspacereducerv2,longqueryfilter,tsrv3_router,enable-history-cache-write,truncatekmessages,responding-harmony-gpt-5-nosearch,responding-harmony-gpt-5-search,placecardnavigationenabled,placecardpromptoptimizationenabled,switcher-harmony,browser-actions,browserautomationcomputeruse,browserautomationsearchweb,edgeactiondisableouter,morefileupload,sidebar-compact-nav-items,sidebar-narrow,searchplaces-enhanced-infos,searchplaces-enhanced-photos,truncatekmessages-k20,truncatekmessages-n30,pay-ams-integration-server,pay-ams"
		"-pdp,pay-ams-price-tracking,pay-ams-product-card,edge-page-safety-check,pii-scrubber,sorttoolrouterresult,relatedresults-android,relatedresults-ios,rrcitationv2,searchmode,see-more-results,toolspacereducerclassifierflight,searchweb-page3,searchweb-sd1000,searchweb-shorter,voice-search-timezone,enrich-web-grounding-with-linkedin-api,entity-info,linkedin-url,person-card-prefer-linkedin,person-cards,edge-security-template,image-ocr-hapi,merge-user-messages,deep-research-summary-v3,dr-cover-image,action-result-relaxed-json-escaping,bingify-sanitized-urls,urls-extracted-infer-event,gpt5-reasoning-harmony,thinkdeeper-gpt5reasoning-harmony-personality,dynamic-answer-cards,indepth-comparison-and-details,warnings-and-clarifications,edu-discovery-cross-sell,study-mode-mico-quiz-tutor,citation-v2,citation-v2-cards,citation-v2-nav,inline-image,inline-video,inline-video-moments,adaptive-citations,adaptive-citations-navigation,pinned-conversation,dynamic-card-selection-instructions,nav-all-turns,nav-cards-on-all-modes,na"
		"v-hostqcscore-filter,navigation-curated-enabled,navigation-curation-gpt4o,skip-nav-classifier,generativeui-mvpt3,genui-fiximage,genui-fiximage-12,genui-json-validator,genui-mvp,genui-preturn-refactor,genui-skills,genui-skills-small,genuimvp,searchmode-gpt51-chat-harmony,searchmode-gpt51-promptv2,edge-copilot-screenshot,edge-text-vision,kill-shopping-homepage,shopping-pdp-hide-price-history,shopping-pdp-price-tracking-fallback,sorttoolsbyfrequencyflight,shopping-feed-no-hero-image,shopping-journey-staged-orchestrator,shopping-journeys-debounce,shopping-limit-concurrency,flight-booking-skill,shopping-user-memory,generativeui-flight-status,generativeui-local-events,generativeui-prayer-vertical-timeline,generativeui-sunrise-v2,genui-core,genui-counterfactual,genui-ground-t,genui-grounding-template-selector,genui-tier2-grounding-templates,genui-turncache-templates\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"isNewUser\":false,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"c"
		"hromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298"
		"exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-"
		"3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"AppInfo_Version\":\"145.0.3800.82\",\"eventName\":\"copilotWebError\",\"eventInfo_errorType\":\"APIResponseParseError\",\"eventInfo_apiUrl\":\"/config\",\"eventInfo_errors\":\"\\xE2\\x9C\\x96 Invalid input\\\\n"
		"  \\xE2\\x86\\x92 at feedbackOptions.card.audioCallSummary\",\"eventInfo_safe\":false}}\n"
		"{\"name\":\"system\",\"time\":\"2026-03-06T07:23:23.315Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":37,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBCCDD16E182AFC5E06CC216F3A\",\"userFlightIds\":\"imagegen"
		"v3,assistant-enable-answer-cards,voice-spatial,weather-cards,edgviswebground,enable-all-app-actions,promptedreasoningcombinedwithsearchpatch,promptmessagewithcards,voices78,allowanonymoususershare,share-chat-page-entry,039add1b-use-fixed-chat-layout,share-image-link,dailybriefing,pages-table,always-show-last-reaction-v2,azureconfigregexblocklist,disable-cmc-auto-reload,onedrive,suggesthangup,correct-personalization-accidental-opt-out,share-campaign,039add1b-chat-sessions-drawer,039add1b-pages-drawer,injectselfharminstructions,039add1b-refresh-token-worker,account-change-chat-reset,preload-chat-messages,1s-moc-logosize,quiz-card-suggestion,send-connected,anonymousattachmentupload,async-disclaimer-text,mem-generate-post-turn,sharecontinue,share-campaign-taeb9y,share-campaign-krq0kf,dr-editprompt-mobile,039add1b-animated-greeting-message-view,greeting-message-animation,image-fallback-thumbnail,adsidsync,think-deeper-regenerate,smart-mode-flightd-edge,narr-icachuse,img-followup-patch,inject-user-greeting,code-e"
		"dge-c,videoserp5,searchvideos-bing-fallback,searchimages-bing-fallback,edge-responding-loop-harmony-4o-1010,pay-instacart-canada,quiz-in-create-drawer,deep-research-export-file,m365-conversation-sync,deep-research-export-podcast,multiple,originaldocumentupload,web-multi-fallback-languages,share-campaign-evhqea,share-campaign-rbsrqk,share-campaign-tkzuae,share-campaign-jowp8z,share-campaign-gxcdu3,share-campaign-d2e0f5,share-campaign-dkmev6,share-campaign-coqva4,share-campaign-gez3vb,remove-extra-im-start-context,vision-in-composer-v3,deep-research-nano,export-pages-t,copilot-beta,smart-mode-default-rl,039add1b-uikit-paragraph-view,imagegenv3peakhour,onedrive-fetch,share-continue-v2,ts-dynamic-top-section-t,creator-gallery,old-search-config,thinkdeepero4minichainofthought,image-library-2,image-library-delete-image,igszcls,searchimages-cache,searchvideos-cache,pay-consistent-buy,finance-tooltip-v2,m365-pills-custom,copilot-beta-automatic-opt-in,deep-research,quiz-option-shuffle,image-cards-v2,test-srm-aa-4,de"
		"ep-research-promo-card,recipe-card,finance-watchlist-v2,finance-crypto,mutesuggestions,pages-link-navigation,pages-skip-page-selector,pages-file-upload,pages-suggested-followups,onedrive-graph,rm-relatedqna,dr-web-upd-w,dr-pro-nano,pay-getbuyoption-migration,pay-getrecipe-migration,pay-price-tracked,pay-shopify-checkout,sports-cards,smart-mode-reason-chat,pages-reasoning-gg,edge-autosuggest,composer-v4,039add1b-sentry-hang-rate-v2,voice-improved-courtesy-wait,quiz-harmony,sticky-conversation-mode,smart-mode-ensemble-switcher,t1_tsrv3_router,title-generation-harmony,pay-conversion-tracking,history-truncation-fix-parent,backstoryinsertall,local-cards,smart-mode-with-hapi,optimized-responding-for-cache,clarity-http-endpoint,share-image-continue,sharemanagement,labs-audio-expression-style-list-layout,nosearchimageonattachment,start-retry,ui-kit-paragraph-view-2,m365-cela-sheet,placecardprompclean-v3,title-generation-v2,eea-personalization-waiting-period,useggvisionmodel,study-mode,searchimages-safe,searchvideos"
		"-safe,edge-reload-tab,attachment-suggestions-c,vision-biometric-consent,page-title-generation-v2,kill-picasso-id-on-start,zircon-flight-t,browser-actions-09092025,share-campaign-ferk5z,search-pcm,detailedpromptmetrics,file-upload-config,sidebar-settings,placecard-enhance-all,n-30-k-20,pay-ams-treatment,ceo-harmony,finance-chart-clickthrough,labs-audio-expression-scripted-mode,labs-audio-expression-mode-coachmark,labs-audio-expression-story-voice-selector,thinkdeeper5reasoningloweffort,page-title-generation-hapi,skip-preview-event,m365-pills-data-v2,labs-audio-expression-auto-style,edgevision-multitab,flash-cards,finance-earnings,page-safety-check-treatment,analyzedocuments-extendedtokens,labs-audio-expression-preset-card-fixed,lazy-with-retry,sorttoolrouterresult-others-t,character-cognitive-testing-service,voice-flower-bg,thinkdeeper5miniloweffortchainofthought,image-dynamic-width,group-conversations,share-to-invite,deep-research-share-link,cot-output-panel,imagegen-galleryremixquota,place-near-me-fix,rela"
		"ted-results-t1,tru-router,pay-migrate-get-checkout-option-v2,voice-safety-patch,uselongcontextmodel,kill-regenerate,speechtranscribev2,browser-automation-inc-max-loop,thinkdeeper-truncator,search-truncation,backstory-trim,suppress-inline-link-nav-dialog,voice-time-formatting,balancedfiletokens,empty-tool-instruction,think-deeper-move-tool-instructions,heycopilot-backstory,vad-buffer,pay-edge-clarity,dr-progress,labs-audio-expression-story-image,remix-suggestions,ceo-remove-search-web,healthcare-safety-patch-v3,person-card,edge-safety-prompt-treatment,share-conversation-with-attachments,image-upload-mmt,dr-summary,cross-selling-t-gpt52,ceo-optimized-loop,podcast-in-voice,track-oldest-merged-message,mem-clean-forget,url-output-sanitization,gpt5-reasoning-harmony-personality-v1,config-responder-option-by-modelname,responding-loop-for-vision-model,reduce-vision-usage,dynamic-answer-cards-ga,dr-outlinks,quiz-instant-feedback,gpt-5-on-quick-mode,safety-middleware,ceo-filedownload,hide-feedback-if-no-mic-permissio"
		"n-on-end-call,auth-assertion,connector-consent-v2,existing-teen-enabled,voice-clear-audio-capture-listeners-on-end,dr-shared-orchestrator,memory-settings-v2,election-patch,pagecreation,add-utm-source,warnings-indepth,model-migration,route-chat-to-agent,browser-automation-instruction-gpt5,group-conversations-lazy-creation,reduce-memory-overtriggering,image-model-selector-summary,utm-tracking-use-copilot-com,checkmark-emoji-fix,groupchatnotifications,upfront-persistence,groupchat-mentions,edu-cross-sell,browser-actions-charapita,contextual-suggestions,subs-redirect-to-cmc,cef,voice-new-feedback-string,reject-tier4-start-traffic,time-patch,challenge-asn,min-adaptive-citation-t-nav,cloudflare-challenge,chat-recovery-long-streaming-timeout,enable-audio-capture-worklet,voice-memory-edf,reuse-audio-context-for-voice-output,enable-audio-out-pre-buffering-c,socket-close-track,local-inference-client-side-lb,auth0-based-user-link,knowledge-extraction-harmony,router-default-preload-intent,hide-conversation-dates,remove"
		"-qr,edge-shopping-enable-all-markets,deprecate_widgets_v1,edge-page-sanitization,teen-compliance,edge-ctx-consent-tool-executing,skip-reasoning-in-smart-mode,chat-client-retry,labs-remote-config,voice-name-repetition-fix,ltm-backfill-disabled,skip-append-last-user-message-again,framework-conversation-write,email-reply,voice-enable-new-audio-icon-c,backstorytool,block-image-generation-in-voice,increase-doc-attachment-max-tokens,nav-expand-all-t,remove-clarifying-prompts,readaloud-verbatim-prompt,kill-contextual-suggestions-tabs-check,podcast-project-sources-grounding,edf-store-direct-instruction,naa-has-active-account-check,computeruse-raw-cot,reduce-memory-overtrigger-location-c,search-uploaded-docs-in-project,mem-skip-preview-search,genuiskillssmallf12,searchmode-t2,browser-actions-detailed-summary,generate-flashcard-skill,browser-actions-deprecated-non-charapita,proactive-message-additional-context,searchfinance-searchquery,group-conversations-reuse-conv-id,voice-enable-read-aloud-c,edge-text-vision-treat"
		"ment,max-adaptive-citations-c,user-message-copy,match-message-timestamp,edge-tab-safety-cache,voice-telemetry,m365-wxp-history-sync,kill-shopping-homepage-t,nav-card-short-url,kill-projects-creations-flash-card,computer-agent-skills,browser-remote-actions-for-tasks,conversation-compactor,planning-agent-elicitation,spd-citation-v2-mixed-format,agent-snapshots,group-conversations-unread-indicator,gpt52-reasoning-harmony,superbowl-search,autoprompt-off,earcon-only-after-first-use,voice-restart-telemetry,subs-hot-reload,jailbreakdisabled,pdp-track-price-comp-t,olympics-search,supersonic-task-preview,edf-memory-tuning,task-memory,trs-update-flight,block-document-generation-in-voice,task-notification,shopping-journeys-v2-container,shopping-feed-no-hero-image-t,fix-ftr,discovery-long-summary,avoid-edge-vision-highlight,agent-manager-registry,dicf6867,audioagent-v3,lm-arena-v2,windows-vision-highlights,journeys-generation-v2-t,shopping-jump-back-to-conversation-c,studio-sdk,sdk-ai-message-item,sidebar-vnext,chat-se"
		"ssion-affinity,ltm-responding-prompt-tuning-c,topic_continuation_enabled_twice_per_week,trvlflghttf,vertex-timeout,shopping-user-memory-t,fetch-convo,shadowban,update-edge-eu-user-consent-text,genui-tier3-c,genui-ground-counterfactual,discovery-harmony-timestamp,mai-whisper-language-c,gpt51-group-chat,genui-tier4-ground-flight-c,task-notification-no-timeout,shopping-journeys-v2-container-read-c,getcameraimages,web-30s-ping,v3-courteous-wait-c,shopping-feed-thumbs-feedback-toast,conversation-search-region-routing-control,edge-dont-language-switch,upsell-selector,model-training-new-privacy,voice-spatial-info,chainofthoughteventprocessor,chat-message-preview,handle-preview-event,kill-composer-creation-button,smart-mode,smart-mode-6e0b4c6f,smart-mode-cot,smart-mode-flightc,smart-mode-v2-config,searchvideos,searchvideos-google,serpvideocard,video-cards-v2,videocardrespondinginstruction,edge-responder-loop,emit-all-inference-telemetry,responderactions-all,responding-harmony-4o-v4,multi-file-upload,multiple-file-u"
		"pload,unlimitedfilereasoning,grounded-edit,page-citation,pages-footnote,gpt5-calcite,responding-harmony-gpt5-v1,smart-mode-default,tool-defs-on-separate-system-message,1s-moc-keep-facets,1s-moc-more-msn,1s-wpo-dis-dnewsr,1s-wpo-dis-nopod,discover-gemfive,discover-more-news-content,discover-news-all-large-cards,discover-newsts,discover-threets,think-deeper-cot,finance-follow,finance-watchlist-ui,prg-cmc-flws,prg-cmc-fnav,improve-context-precision,ds-editprompt,ds-new-progress,smart-mode-gpt5,actionspacereducerv2,longqueryfilter,tsrv3_router,enable-history-cache-write,truncatekmessages,responding-harmony-gpt-5-nosearch,responding-harmony-gpt-5-search,placecardnavigationenabled,placecardpromptoptimizationenabled,switcher-harmony,browser-actions,browserautomationcomputeruse,browserautomationsearchweb,edgeactiondisableouter,morefileupload,sidebar-compact-nav-items,sidebar-narrow,searchplaces-enhanced-infos,searchplaces-enhanced-photos,truncatekmessages-k20,truncatekmessages-n30,pay-ams-integration-server,pay-ams"
		"-pdp,pay-ams-price-tracking,pay-ams-product-card,edge-page-safety-check,pii-scrubber,sorttoolrouterresult,relatedresults-android,relatedresults-ios,rrcitationv2,searchmode,see-more-results,toolspacereducerclassifierflight,searchweb-page3,searchweb-sd1000,searchweb-shorter,voice-search-timezone,enrich-web-grounding-with-linkedin-api,entity-info,linkedin-url,person-card-prefer-linkedin,person-cards,edge-security-template,image-ocr-hapi,merge-user-messages,deep-research-summary-v3,dr-cover-image,action-result-relaxed-json-escaping,bingify-sanitized-urls,urls-extracted-infer-event,gpt5-reasoning-harmony,thinkdeeper-gpt5reasoning-harmony-personality,dynamic-answer-cards,indepth-comparison-and-details,warnings-and-clarifications,edu-discovery-cross-sell,study-mode-mico-quiz-tutor,citation-v2,citation-v2-cards,citation-v2-nav,inline-image,inline-video,inline-video-moments,adaptive-citations,adaptive-citations-navigation,pinned-conversation,dynamic-card-selection-instructions,nav-all-turns,nav-cards-on-all-modes,na"
		"v-hostqcscore-filter,navigation-curated-enabled,navigation-curation-gpt4o,skip-nav-classifier,generativeui-mvpt3,genui-fiximage,genui-fiximage-12,genui-json-validator,genui-mvp,genui-preturn-refactor,genui-skills,genui-skills-small,genuimvp,searchmode-gpt51-chat-harmony,searchmode-gpt51-promptv2,edge-copilot-screenshot,edge-text-vision,kill-shopping-homepage,shopping-pdp-hide-price-history,shopping-pdp-price-tracking-fallback,sorttoolsbyfrequencyflight,shopping-feed-no-hero-image,shopping-journey-staged-orchestrator,shopping-journeys-debounce,shopping-limit-concurrency,flight-booking-skill,shopping-user-memory,generativeui-flight-status,generativeui-local-events,generativeui-prayer-vertical-timeline,generativeui-sunrise-v2,genui-core,genui-counterfactual,genui-ground-t,genui-grounding-template-selector,genui-tier2-grounding-templates,genui-turncache-templates\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"isNewUser\":false,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"c"
		"hromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298"
		"exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-"
		"3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"AppInfo_Version\":\"145.0.3800.82\",\"eventName\":\"copilotWebError\",\"eventInfo_errorType\":\"APIResponseParseError\",\"eventInfo_apiUrl\":\"/user\",\"eventInfo_errors\":\"\\xE2\\x9C\\x96 Invalid input: expected object, received undefined\\\\n"
		"  \\xE2\\x86\\x92 at phoneLink\\\\n"
		"\\xE2\\x9C\\x96 Invalid input: expected object, received undefined\\\\n"
		"  \\xE2\\x86\\x92 at requiredConsents.healthSpace\",\"eventInfo_safe\":true}}\n"
		"{\"name\":\"health\",\"time\":\"2026-03-06T07:23:23.327Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":38,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBCCDD16E182AFC5E06CC216F3A\",\"userPicassoId\":\"3VGqNUdU"
		"rjXr2j34tQeir\",\"userFlightIds\":\"imagegenv3,assistant-enable-answer-cards,voice-spatial,weather-cards,edgviswebground,enable-all-app-actions,promptedreasoningcombinedwithsearchpatch,promptmessagewithcards,voices78,allowanonymoususershare,share-chat-page-entry,039add1b-use-fixed-chat-layout,share-image-link,dailybriefing,pages-table,always-show-last-reaction-v2,azureconfigregexblocklist,disable-cmc-auto-reload,onedrive,suggesthangup,correct-personalization-accidental-opt-out,share-campaign,039add1b-chat-sessions-drawer,039add1b-pages-drawer,injectselfharminstructions,039add1b-refresh-token-worker,account-change-chat-reset,preload-chat-messages,1s-moc-logosize,quiz-card-suggestion,send-connected,anonymousattachmentupload,async-disclaimer-text,mem-generate-post-turn,sharecontinue,share-campaign-taeb9y,share-campaign-krq0kf,dr-editprompt-mobile,039add1b-animated-greeting-message-view,greeting-message-animation,image-fallback-thumbnail,adsidsync,think-deeper-regenerate,smart-mode-flightd-edge,narr-icachuse,im"
		"g-followup-patch,inject-user-greeting,code-edge-c,videoserp5,searchvideos-bing-fallback,searchimages-bing-fallback,edge-responding-loop-harmony-4o-1010,pay-instacart-canada,quiz-in-create-drawer,deep-research-export-file,m365-conversation-sync,deep-research-export-podcast,multiple,originaldocumentupload,web-multi-fallback-languages,share-campaign-evhqea,share-campaign-rbsrqk,share-campaign-tkzuae,share-campaign-jowp8z,share-campaign-gxcdu3,share-campaign-d2e0f5,share-campaign-dkmev6,share-campaign-coqva4,share-campaign-gez3vb,remove-extra-im-start-context,vision-in-composer-v3,deep-research-nano,export-pages-t,copilot-beta,smart-mode-default-rl,039add1b-uikit-paragraph-view,imagegenv3peakhour,onedrive-fetch,share-continue-v2,ts-dynamic-top-section-t,creator-gallery,old-search-config,thinkdeepero4minichainofthought,image-library-2,image-library-delete-image,igszcls,searchimages-cache,searchvideos-cache,pay-consistent-buy,finance-tooltip-v2,m365-pills-custom,copilot-beta-automatic-opt-in,deep-research,quiz-op"
		"tion-shuffle,image-cards-v2,test-srm-aa-4,deep-research-promo-card,recipe-card,finance-watchlist-v2,finance-crypto,mutesuggestions,pages-link-navigation,pages-skip-page-selector,pages-file-upload,pages-suggested-followups,onedrive-graph,rm-relatedqna,dr-web-upd-w,dr-pro-nano,pay-getbuyoption-migration,pay-getrecipe-migration,pay-price-tracked,pay-shopify-checkout,sports-cards,smart-mode-reason-chat,pages-reasoning-gg,edge-autosuggest,composer-v4,039add1b-sentry-hang-rate-v2,voice-improved-courtesy-wait,quiz-harmony,sticky-conversation-mode,smart-mode-ensemble-switcher,t1_tsrv3_router,title-generation-harmony,pay-conversion-tracking,history-truncation-fix-parent,backstoryinsertall,local-cards,smart-mode-with-hapi,optimized-responding-for-cache,clarity-http-endpoint,share-image-continue,sharemanagement,labs-audio-expression-style-list-layout,nosearchimageonattachment,start-retry,ui-kit-paragraph-view-2,m365-cela-sheet,placecardprompclean-v3,title-generation-v2,eea-personalization-waiting-period,useggvisionmod"
		"el,study-mode,searchimages-safe,searchvideos-safe,edge-reload-tab,attachment-suggestions-c,vision-biometric-consent,page-title-generation-v2,kill-picasso-id-on-start,zircon-flight-t,browser-actions-09092025,share-campaign-ferk5z,search-pcm,detailedpromptmetrics,file-upload-config,sidebar-settings,placecard-enhance-all,n-30-k-20,pay-ams-treatment,ceo-harmony,finance-chart-clickthrough,labs-audio-expression-scripted-mode,labs-audio-expression-mode-coachmark,labs-audio-expression-story-voice-selector,thinkdeeper5reasoningloweffort,page-title-generation-hapi,skip-preview-event,m365-pills-data-v2,labs-audio-expression-auto-style,edgevision-multitab,flash-cards,finance-earnings,page-safety-check-treatment,analyzedocuments-extendedtokens,labs-audio-expression-preset-card-fixed,lazy-with-retry,sorttoolrouterresult-others-t,character-cognitive-testing-service,voice-flower-bg,thinkdeeper5miniloweffortchainofthought,image-dynamic-width,group-conversations,share-to-invite,deep-research-share-link,cot-output-panel,image"
		"gen-galleryremixquota,place-near-me-fix,related-results-t1,tru-router,pay-migrate-get-checkout-option-v2,voice-safety-patch,uselongcontextmodel,kill-regenerate,speechtranscribev2,browser-automation-inc-max-loop,thinkdeeper-truncator,search-truncation,backstory-trim,suppress-inline-link-nav-dialog,voice-time-formatting,balancedfiletokens,empty-tool-instruction,think-deeper-move-tool-instructions,heycopilot-backstory,vad-buffer,pay-edge-clarity,dr-progress,labs-audio-expression-story-image,remix-suggestions,ceo-remove-search-web,healthcare-safety-patch-v3,person-card,edge-safety-prompt-treatment,share-conversation-with-attachments,image-upload-mmt,dr-summary,cross-selling-t-gpt52,ceo-optimized-loop,podcast-in-voice,track-oldest-merged-message,mem-clean-forget,url-output-sanitization,gpt5-reasoning-harmony-personality-v1,config-responder-option-by-modelname,responding-loop-for-vision-model,reduce-vision-usage,dynamic-answer-cards-ga,dr-outlinks,quiz-instant-feedback,gpt-5-on-quick-mode,safety-middleware,ceo-fi"
		"ledownload,hide-feedback-if-no-mic-permission-on-end-call,auth-assertion,connector-consent-v2,existing-teen-enabled,voice-clear-audio-capture-listeners-on-end,dr-shared-orchestrator,memory-settings-v2,election-patch,pagecreation,add-utm-source,warnings-indepth,model-migration,route-chat-to-agent,browser-automation-instruction-gpt5,group-conversations-lazy-creation,reduce-memory-overtriggering,image-model-selector-summary,utm-tracking-use-copilot-com,checkmark-emoji-fix,groupchatnotifications,upfront-persistence,groupchat-mentions,edu-cross-sell,browser-actions-charapita,contextual-suggestions,subs-redirect-to-cmc,cef,voice-new-feedback-string,reject-tier4-start-traffic,time-patch,challenge-asn,min-adaptive-citation-t-nav,cloudflare-challenge,chat-recovery-long-streaming-timeout,enable-audio-capture-worklet,voice-memory-edf,reuse-audio-context-for-voice-output,enable-audio-out-pre-buffering-c,socket-close-track,local-inference-client-side-lb,auth0-based-user-link,knowledge-extraction-harmony,router-default-p"
		"reload-intent,hide-conversation-dates,remove-qr,edge-shopping-enable-all-markets,deprecate_widgets_v1,edge-page-sanitization,teen-compliance,edge-ctx-consent-tool-executing,skip-reasoning-in-smart-mode,chat-client-retry,labs-remote-config,voice-name-repetition-fix,ltm-backfill-disabled,skip-append-last-user-message-again,framework-conversation-write,email-reply,voice-enable-new-audio-icon-c,backstorytool,block-image-generation-in-voice,increase-doc-attachment-max-tokens,nav-expand-all-t,remove-clarifying-prompts,readaloud-verbatim-prompt,kill-contextual-suggestions-tabs-check,podcast-project-sources-grounding,edf-store-direct-instruction,naa-has-active-account-check,computeruse-raw-cot,reduce-memory-overtrigger-location-c,search-uploaded-docs-in-project,mem-skip-preview-search,genuiskillssmallf12,searchmode-t2,browser-actions-detailed-summary,generate-flashcard-skill,browser-actions-deprecated-non-charapita,proactive-message-additional-context,searchfinance-searchquery,group-conversations-reuse-conv-id,voic"
		"e-enable-read-aloud-c,edge-text-vision-treatment,max-adaptive-citations-c,user-message-copy,match-message-timestamp,edge-tab-safety-cache,voice-telemetry,m365-wxp-history-sync,kill-shopping-homepage-t,nav-card-short-url,kill-projects-creations-flash-card,computer-agent-skills,browser-remote-actions-for-tasks,conversation-compactor,planning-agent-elicitation,spd-citation-v2-mixed-format,agent-snapshots,group-conversations-unread-indicator,gpt52-reasoning-harmony,superbowl-search,autoprompt-off,earcon-only-after-first-use,voice-restart-telemetry,subs-hot-reload,jailbreakdisabled,pdp-track-price-comp-t,olympics-search,supersonic-task-preview,edf-memory-tuning,task-memory,trs-update-flight,block-document-generation-in-voice,task-notification,shopping-journeys-v2-container,shopping-feed-no-hero-image-t,fix-ftr,discovery-long-summary,avoid-edge-vision-highlight,agent-manager-registry,dicf6867,audioagent-v3,lm-arena-v2,windows-vision-highlights,journeys-generation-v2-t,shopping-jump-back-to-conversation-c,studio-s"
		"dk,sdk-ai-message-item,sidebar-vnext,chat-session-affinity,ltm-responding-prompt-tuning-c,topic_continuation_enabled_twice_per_week,trvlflghttf,vertex-timeout,shopping-user-memory-t,fetch-convo,shadowban,update-edge-eu-user-consent-text,genui-tier3-c,genui-ground-counterfactual,discovery-harmony-timestamp,mai-whisper-language-c,gpt51-group-chat,genui-tier4-ground-flight-c,task-notification-no-timeout,shopping-journeys-v2-container-read-c,getcameraimages,web-30s-ping,v3-courteous-wait-c,shopping-feed-thumbs-feedback-toast,conversation-search-region-routing-control,edge-dont-language-switch,upsell-selector,model-training-new-privacy,voice-spatial-info,chainofthoughteventprocessor,chat-message-preview,handle-preview-event,kill-composer-creation-button,smart-mode,smart-mode-6e0b4c6f,smart-mode-cot,smart-mode-flightc,smart-mode-v2-config,searchvideos,searchvideos-google,serpvideocard,video-cards-v2,videocardrespondinginstruction,edge-responder-loop,emit-all-inference-telemetry,responderactions-all,responding-har"
		"mony-4o-v4,multi-file-upload,multiple-file-upload,unlimitedfilereasoning,grounded-edit,page-citation,pages-footnote,gpt5-calcite,responding-harmony-gpt5-v1,smart-mode-default,tool-defs-on-separate-system-message,1s-moc-keep-facets,1s-moc-more-msn,1s-wpo-dis-dnewsr,1s-wpo-dis-nopod,discover-gemfive,discover-more-news-content,discover-news-all-large-cards,discover-newsts,discover-threets,think-deeper-cot,finance-follow,finance-watchlist-ui,prg-cmc-flws,prg-cmc-fnav,improve-context-precision,ds-editprompt,ds-new-progress,smart-mode-gpt5,actionspacereducerv2,longqueryfilter,tsrv3_router,enable-history-cache-write,truncatekmessages,responding-harmony-gpt-5-nosearch,responding-harmony-gpt-5-search,placecardnavigationenabled,placecardpromptoptimizationenabled,switcher-harmony,browser-actions,browserautomationcomputeruse,browserautomationsearchweb,edgeactiondisableouter,morefileupload,sidebar-compact-nav-items,sidebar-narrow,searchplaces-enhanced-infos,searchplaces-enhanced-photos,truncatekmessages-k20,truncatekmes"
		"sages-n30,pay-ams-integration-server,pay-ams-pdp,pay-ams-price-tracking,pay-ams-product-card,edge-page-safety-check,pii-scrubber,sorttoolrouterresult,relatedresults-android,relatedresults-ios,rrcitationv2,searchmode,see-more-results,toolspacereducerclassifierflight,searchweb-page3,searchweb-sd1000,searchweb-shorter,voice-search-timezone,enrich-web-grounding-with-linkedin-api,entity-info,linkedin-url,person-card-prefer-linkedin,person-cards,edge-security-template,image-ocr-hapi,merge-user-messages,deep-research-summary-v3,dr-cover-image,action-result-relaxed-json-escaping,bingify-sanitized-urls,urls-extracted-infer-event,gpt5-reasoning-harmony,thinkdeeper-gpt5reasoning-harmony-personality,dynamic-answer-cards,indepth-comparison-and-details,warnings-and-clarifications,edu-discovery-cross-sell,study-mode-mico-quiz-tutor,citation-v2,citation-v2-cards,citation-v2-nav,inline-image,inline-video,inline-video-moments,adaptive-citations,adaptive-citations-navigation,pinned-conversation,dynamic-card-selection-instruct"
		"ions,nav-all-turns,nav-cards-on-all-modes,nav-hostqcscore-filter,navigation-curated-enabled,navigation-curation-gpt4o,skip-nav-classifier,generativeui-mvpt3,genui-fiximage,genui-fiximage-12,genui-json-validator,genui-mvp,genui-preturn-refactor,genui-skills,genui-skills-small,genuimvp,searchmode-gpt51-chat-harmony,searchmode-gpt51-promptv2,edge-copilot-screenshot,edge-text-vision,kill-shopping-homepage,shopping-pdp-hide-price-history,shopping-pdp-price-tracking-fallback,sorttoolsbyfrequencyflight,shopping-feed-no-hero-image,shopping-journey-staged-orchestrator,shopping-journeys-debounce,shopping-limit-concurrency,flight-booking-skill,shopping-user-memory,generativeui-flight-status,generativeui-local-events,generativeui-prayer-vertical-timeline,generativeui-sunrise-v2,genui-core,genui-counterfactual,genui-ground-t,genui-grounding-template-selector,genui-tier2-grounding-templates,genui-turncache-templates\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"isAADUser\":false,\"isNewUser\":fa"
		"lse,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d"
		"375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-7"
		"8306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"UserInfo.Id\":\"3VGqNUdUrjXr2j34tQeir\",\"AppInfo_Version\":\"145.0.3800.82\",\"eventName\":\"copilotWebAuthSDKAPICall\",\"eventInfo_apiName\":\"auth0:initializeStart\",\"eventInfo_success\":true,\"eventInfo_customData\":\"{\\\\\"eventInfo_providerType\\\\\":\\\\\"auth0\\\\\"}\"}}\n"
		"{\"name\":\"health\",\"time\":\"2026-03-06T07:23:23.332Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":39,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_duration\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BB"
		"CCDD16E182AFC5E06CC216F3A\",\"userPicassoId\":\"3VGqNUdUrjXr2j34tQeir\",\"userFlightIds\":\"imagegenv3,assistant-enable-answer-cards,voice-spatial,weather-cards,edgviswebground,enable-all-app-actions,promptedreasoningcombinedwithsearchpatch,promptmessagewithcards,voices78,allowanonymoususershare,share-chat-page-entry,039add1b-use-fixed-chat-layout,share-image-link,dailybriefing,pages-table,always-show-last-reaction-v2,azureconfigregexblocklist,disable-cmc-auto-reload,onedrive,suggesthangup,correct-personalization-accidental-opt-out,share-campaign,039add1b-chat-sessions-drawer,039add1b-pages-drawer,injectselfharminstructions,039add1b-refresh-token-worker,account-change-chat-reset,preload-chat-messages,1s-moc-logosize,quiz-card-suggestion,send-connected,anonymousattachmentupload,async-disclaimer-text,mem-generate-post-turn,sharecontinue,share-campaign-taeb9y,share-campaign-krq0kf,dr-editprompt-mobile,039add1b-animated-greeting-message-view,greeting-message-animation,image-fallback-thumbnail,adsidsync,think-de"
		"eper-regenerate,smart-mode-flightd-edge,narr-icachuse,img-followup-patch,inject-user-greeting,code-edge-c,videoserp5,searchvideos-bing-fallback,searchimages-bing-fallback,edge-responding-loop-harmony-4o-1010,pay-instacart-canada,quiz-in-create-drawer,deep-research-export-file,m365-conversation-sync,deep-research-export-podcast,multiple,originaldocumentupload,web-multi-fallback-languages,share-campaign-evhqea,share-campaign-rbsrqk,share-campaign-tkzuae,share-campaign-jowp8z,share-campaign-gxcdu3,share-campaign-d2e0f5,share-campaign-dkmev6,share-campaign-coqva4,share-campaign-gez3vb,remove-extra-im-start-context,vision-in-composer-v3,deep-research-nano,export-pages-t,copilot-beta,smart-mode-default-rl,039add1b-uikit-paragraph-view,imagegenv3peakhour,onedrive-fetch,share-continue-v2,ts-dynamic-top-section-t,creator-gallery,old-search-config,thinkdeepero4minichainofthought,image-library-2,image-library-delete-image,igszcls,searchimages-cache,searchvideos-cache,pay-consistent-buy,finance-tooltip-v2,m365-pills-cu"
		"stom,copilot-beta-automatic-opt-in,deep-research,quiz-option-shuffle,image-cards-v2,test-srm-aa-4,deep-research-promo-card,recipe-card,finance-watchlist-v2,finance-crypto,mutesuggestions,pages-link-navigation,pages-skip-page-selector,pages-file-upload,pages-suggested-followups,onedrive-graph,rm-relatedqna,dr-web-upd-w,dr-pro-nano,pay-getbuyoption-migration,pay-getrecipe-migration,pay-price-tracked,pay-shopify-checkout,sports-cards,smart-mode-reason-chat,pages-reasoning-gg,edge-autosuggest,composer-v4,039add1b-sentry-hang-rate-v2,voice-improved-courtesy-wait,quiz-harmony,sticky-conversation-mode,smart-mode-ensemble-switcher,t1_tsrv3_router,title-generation-harmony,pay-conversion-tracking,history-truncation-fix-parent,backstoryinsertall,local-cards,smart-mode-with-hapi,optimized-responding-for-cache,clarity-http-endpoint,share-image-continue,sharemanagement,labs-audio-expression-style-list-layout,nosearchimageonattachment,start-retry,ui-kit-paragraph-view-2,m365-cela-sheet,placecardprompclean-v3,title-generat"
		"ion-v2,eea-personalization-waiting-period,useggvisionmodel,study-mode,searchimages-safe,searchvideos-safe,edge-reload-tab,attachment-suggestions-c,vision-biometric-consent,page-title-generation-v2,kill-picasso-id-on-start,zircon-flight-t,browser-actions-09092025,share-campaign-ferk5z,search-pcm,detailedpromptmetrics,file-upload-config,sidebar-settings,placecard-enhance-all,n-30-k-20,pay-ams-treatment,ceo-harmony,finance-chart-clickthrough,labs-audio-expression-scripted-mode,labs-audio-expression-mode-coachmark,labs-audio-expression-story-voice-selector,thinkdeeper5reasoningloweffort,page-title-generation-hapi,skip-preview-event,m365-pills-data-v2,labs-audio-expression-auto-style,edgevision-multitab,flash-cards,finance-earnings,page-safety-check-treatment,analyzedocuments-extendedtokens,labs-audio-expression-preset-card-fixed,lazy-with-retry,sorttoolrouterresult-others-t,character-cognitive-testing-service,voice-flower-bg,thinkdeeper5miniloweffortchainofthought,image-dynamic-width,group-conversations,share-t"
		"o-invite,deep-research-share-link,cot-output-panel,imagegen-galleryremixquota,place-near-me-fix,related-results-t1,tru-router,pay-migrate-get-checkout-option-v2,voice-safety-patch,uselongcontextmodel,kill-regenerate,speechtranscribev2,browser-automation-inc-max-loop,thinkdeeper-truncator,search-truncation,backstory-trim,suppress-inline-link-nav-dialog,voice-time-formatting,balancedfiletokens,empty-tool-instruction,think-deeper-move-tool-instructions,heycopilot-backstory,vad-buffer,pay-edge-clarity,dr-progress,labs-audio-expression-story-image,remix-suggestions,ceo-remove-search-web,healthcare-safety-patch-v3,person-card,edge-safety-prompt-treatment,share-conversation-with-attachments,image-upload-mmt,dr-summary,cross-selling-t-gpt52,ceo-optimized-loop,podcast-in-voice,track-oldest-merged-message,mem-clean-forget,url-output-sanitization,gpt5-reasoning-harmony-personality-v1,config-responder-option-by-modelname,responding-loop-for-vision-model,reduce-vision-usage,dynamic-answer-cards-ga,dr-outlinks,quiz-insta"
		"nt-feedback,gpt-5-on-quick-mode,safety-middleware,ceo-filedownload,hide-feedback-if-no-mic-permission-on-end-call,auth-assertion,connector-consent-v2,existing-teen-enabled,voice-clear-audio-capture-listeners-on-end,dr-shared-orchestrator,memory-settings-v2,election-patch,pagecreation,add-utm-source,warnings-indepth,model-migration,route-chat-to-agent,browser-automation-instruction-gpt5,group-conversations-lazy-creation,reduce-memory-overtriggering,image-model-selector-summary,utm-tracking-use-copilot-com,checkmark-emoji-fix,groupchatnotifications,upfront-persistence,groupchat-mentions,edu-cross-sell,browser-actions-charapita,contextual-suggestions,subs-redirect-to-cmc,cef,voice-new-feedback-string,reject-tier4-start-traffic,time-patch,challenge-asn,min-adaptive-citation-t-nav,cloudflare-challenge,chat-recovery-long-streaming-timeout,enable-audio-capture-worklet,voice-memory-edf,reuse-audio-context-for-voice-output,enable-audio-out-pre-buffering-c,socket-close-track,local-inference-client-side-lb,auth0-based"
		"-user-link,knowledge-extraction-harmony,router-default-preload-intent,hide-conversation-dates,remove-qr,edge-shopping-enable-all-markets,deprecate_widgets_v1,edge-page-sanitization,teen-compliance,edge-ctx-consent-tool-executing,skip-reasoning-in-smart-mode,chat-client-retry,labs-remote-config,voice-name-repetition-fix,ltm-backfill-disabled,skip-append-last-user-message-again,framework-conversation-write,email-reply,voice-enable-new-audio-icon-c,backstorytool,block-image-generation-in-voice,increase-doc-attachment-max-tokens,nav-expand-all-t,remove-clarifying-prompts,readaloud-verbatim-prompt,kill-contextual-suggestions-tabs-check,podcast-project-sources-grounding,edf-store-direct-instruction,naa-has-active-account-check,computeruse-raw-cot,reduce-memory-overtrigger-location-c,search-uploaded-docs-in-project,mem-skip-preview-search,genuiskillssmallf12,searchmode-t2,browser-actions-detailed-summary,generate-flashcard-skill,browser-actions-deprecated-non-charapita,proactive-message-additional-context,searchfi"
		"nance-searchquery,group-conversations-reuse-conv-id,voice-enable-read-aloud-c,edge-text-vision-treatment,max-adaptive-citations-c,user-message-copy,match-message-timestamp,edge-tab-safety-cache,voice-telemetry,m365-wxp-history-sync,kill-shopping-homepage-t,nav-card-short-url,kill-projects-creations-flash-card,computer-agent-skills,browser-remote-actions-for-tasks,conversation-compactor,planning-agent-elicitation,spd-citation-v2-mixed-format,agent-snapshots,group-conversations-unread-indicator,gpt52-reasoning-harmony,superbowl-search,autoprompt-off,earcon-only-after-first-use,voice-restart-telemetry,subs-hot-reload,jailbreakdisabled,pdp-track-price-comp-t,olympics-search,supersonic-task-preview,edf-memory-tuning,task-memory,trs-update-flight,block-document-generation-in-voice,task-notification,shopping-journeys-v2-container,shopping-feed-no-hero-image-t,fix-ftr,discovery-long-summary,avoid-edge-vision-highlight,agent-manager-registry,dicf6867,audioagent-v3,lm-arena-v2,windows-vision-highlights,journeys-gener"
		"ation-v2-t,shopping-jump-back-to-conversation-c,studio-sdk,sdk-ai-message-item,sidebar-vnext,chat-session-affinity,ltm-responding-prompt-tuning-c,topic_continuation_enabled_twice_per_week,trvlflghttf,vertex-timeout,shopping-user-memory-t,fetch-convo,shadowban,update-edge-eu-user-consent-text,genui-tier3-c,genui-ground-counterfactual,discovery-harmony-timestamp,mai-whisper-language-c,gpt51-group-chat,genui-tier4-ground-flight-c,task-notification-no-timeout,shopping-journeys-v2-container-read-c,getcameraimages,web-30s-ping,v3-courteous-wait-c,shopping-feed-thumbs-feedback-toast,conversation-search-region-routing-control,edge-dont-language-switch,upsell-selector,model-training-new-privacy,voice-spatial-info,chainofthoughteventprocessor,chat-message-preview,handle-preview-event,kill-composer-creation-button,smart-mode,smart-mode-6e0b4c6f,smart-mode-cot,smart-mode-flightc,smart-mode-v2-config,searchvideos,searchvideos-google,serpvideocard,video-cards-v2,videocardrespondinginstruction,edge-responder-loop,emit-all"
		"-inference-telemetry,responderactions-all,responding-harmony-4o-v4,multi-file-upload,multiple-file-upload,unlimitedfilereasoning,grounded-edit,page-citation,pages-footnote,gpt5-calcite,responding-harmony-gpt5-v1,smart-mode-default,tool-defs-on-separate-system-message,1s-moc-keep-facets,1s-moc-more-msn,1s-wpo-dis-dnewsr,1s-wpo-dis-nopod,discover-gemfive,discover-more-news-content,discover-news-all-large-cards,discover-newsts,discover-threets,think-deeper-cot,finance-follow,finance-watchlist-ui,prg-cmc-flws,prg-cmc-fnav,improve-context-precision,ds-editprompt,ds-new-progress,smart-mode-gpt5,actionspacereducerv2,longqueryfilter,tsrv3_router,enable-history-cache-write,truncatekmessages,responding-harmony-gpt-5-nosearch,responding-harmony-gpt-5-search,placecardnavigationenabled,placecardpromptoptimizationenabled,switcher-harmony,browser-actions,browserautomationcomputeruse,browserautomationsearchweb,edgeactiondisableouter,morefileupload,sidebar-compact-nav-items,sidebar-narrow,searchplaces-enhanced-infos,searchp"
		"laces-enhanced-photos,truncatekmessages-k20,truncatekmessages-n30,pay-ams-integration-server,pay-ams-pdp,pay-ams-price-tracking,pay-ams-product-card,edge-page-safety-check,pii-scrubber,sorttoolrouterresult,relatedresults-android,relatedresults-ios,rrcitationv2,searchmode,see-more-results,toolspacereducerclassifierflight,searchweb-page3,searchweb-sd1000,searchweb-shorter,voice-search-timezone,enrich-web-grounding-with-linkedin-api,entity-info,linkedin-url,person-card-prefer-linkedin,person-cards,edge-security-template,image-ocr-hapi,merge-user-messages,deep-research-summary-v3,dr-cover-image,action-result-relaxed-json-escaping,bingify-sanitized-urls,urls-extracted-infer-event,gpt5-reasoning-harmony,thinkdeeper-gpt5reasoning-harmony-personality,dynamic-answer-cards,indepth-comparison-and-details,warnings-and-clarifications,edu-discovery-cross-sell,study-mode-mico-quiz-tutor,citation-v2,citation-v2-cards,citation-v2-nav,inline-image,inline-video,inline-video-moments,adaptive-citations,adaptive-citations-naviga"
		"tion,pinned-conversation,dynamic-card-selection-instructions,nav-all-turns,nav-cards-on-all-modes,nav-hostqcscore-filter,navigation-curated-enabled,navigation-curation-gpt4o,skip-nav-classifier,generativeui-mvpt3,genui-fiximage,genui-fiximage-12,genui-json-validator,genui-mvp,genui-preturn-refactor,genui-skills,genui-skills-small,genuimvp,searchmode-gpt51-chat-harmony,searchmode-gpt51-promptv2,edge-copilot-screenshot,edge-text-vision,kill-shopping-homepage,shopping-pdp-hide-price-history,shopping-pdp-price-tracking-fallback,sorttoolsbyfrequencyflight,shopping-feed-no-hero-image,shopping-journey-staged-orchestrator,shopping-journeys-debounce,shopping-limit-concurrency,flight-booking-skill,shopping-user-memory,generativeui-flight-status,generativeui-local-events,generativeui-prayer-vertical-timeline,generativeui-sunrise-v2,genui-core,genui-counterfactual,genui-ground-t,genui-grounding-template-selector,genui-tier2-grounding-templates,genui-turncache-templates\",\"eventInfo_surfaceVisible\":false,\"eventInfo_i"
		"sCopilotMode\":true,\"isAADUser\":false,\"isNewUser\":false,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:951625,"
		"22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-2"
		"0,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"UserInfo.Id\":\"3VGqNUdUrjXr2j34tQeir\",\"AppInfo_Version\":\"145.0.3800.82\",\"eventName\":\"copilotWebAuthSDKAPICall\",\"eventInfo_apiName\":\"auth0:initializeEnd\",\"eventInfo_success\":true,\"eventInfo_duration\":6,\"eventInfo_customData\":\"{\\\\\"eventInfo_providerType\\\\\":\\\\\"auth0\\\\\"}\"}}\n"
		"{\"name\":\"system\",\"time\":\"2026-03-06T07:23:23.394Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":40,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_numMessages\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D03"
		"4BBCCDD16E182AFC5E06CC216F3A\",\"userPicassoId\":\"3VGqNUdUrjXr2j34tQeir\",\"userFlightIds\":\"imagegenv3,assistant-enable-answer-cards,voice-spatial,weather-cards,edgviswebground,enable-all-app-actions,promptedreasoningcombinedwithsearchpatch,promptmessagewithcards,voices78,allowanonymoususershare,share-chat-page-entry,039add1b-use-fixed-chat-layout,share-image-link,dailybriefing,pages-table,always-show-last-reaction-v2,azureconfigregexblocklist,disable-cmc-auto-reload,onedrive,suggesthangup,correct-personalization-accidental-opt-out,share-campaign,039add1b-chat-sessions-drawer,039add1b-pages-drawer,injectselfharminstructions,039add1b-refresh-token-worker,account-change-chat-reset,preload-chat-messages,1s-moc-logosize,quiz-card-suggestion,send-connected,anonymousattachmentupload,async-disclaimer-text,mem-generate-post-turn,sharecontinue,share-campaign-taeb9y,share-campaign-krq0kf,dr-editprompt-mobile,039add1b-animated-greeting-message-view,greeting-message-animation,image-fallback-thumbnail,adsidsync,think"
		"-deeper-regenerate,smart-mode-flightd-edge,narr-icachuse,img-followup-patch,inject-user-greeting,code-edge-c,videoserp5,searchvideos-bing-fallback,searchimages-bing-fallback,edge-responding-loop-harmony-4o-1010,pay-instacart-canada,quiz-in-create-drawer,deep-research-export-file,m365-conversation-sync,deep-research-export-podcast,multiple,originaldocumentupload,web-multi-fallback-languages,share-campaign-evhqea,share-campaign-rbsrqk,share-campaign-tkzuae,share-campaign-jowp8z,share-campaign-gxcdu3,share-campaign-d2e0f5,share-campaign-dkmev6,share-campaign-coqva4,share-campaign-gez3vb,remove-extra-im-start-context,vision-in-composer-v3,deep-research-nano,export-pages-t,copilot-beta,smart-mode-default-rl,039add1b-uikit-paragraph-view,imagegenv3peakhour,onedrive-fetch,share-continue-v2,ts-dynamic-top-section-t,creator-gallery,old-search-config,thinkdeepero4minichainofthought,image-library-2,image-library-delete-image,igszcls,searchimages-cache,searchvideos-cache,pay-consistent-buy,finance-tooltip-v2,m365-pills"
		"-custom,copilot-beta-automatic-opt-in,deep-research,quiz-option-shuffle,image-cards-v2,test-srm-aa-4,deep-research-promo-card,recipe-card,finance-watchlist-v2,finance-crypto,mutesuggestions,pages-link-navigation,pages-skip-page-selector,pages-file-upload,pages-suggested-followups,onedrive-graph,rm-relatedqna,dr-web-upd-w,dr-pro-nano,pay-getbuyoption-migration,pay-getrecipe-migration,pay-price-tracked,pay-shopify-checkout,sports-cards,smart-mode-reason-chat,pages-reasoning-gg,edge-autosuggest,composer-v4,039add1b-sentry-hang-rate-v2,voice-improved-courtesy-wait,quiz-harmony,sticky-conversation-mode,smart-mode-ensemble-switcher,t1_tsrv3_router,title-generation-harmony,pay-conversion-tracking,history-truncation-fix-parent,backstoryinsertall,local-cards,smart-mode-with-hapi,optimized-responding-for-cache,clarity-http-endpoint,share-image-continue,sharemanagement,labs-audio-expression-style-list-layout,nosearchimageonattachment,start-retry,ui-kit-paragraph-view-2,m365-cela-sheet,placecardprompclean-v3,title-gene"
		"ration-v2,eea-personalization-waiting-period,useggvisionmodel,study-mode,searchimages-safe,searchvideos-safe,edge-reload-tab,attachment-suggestions-c,vision-biometric-consent,page-title-generation-v2,kill-picasso-id-on-start,zircon-flight-t,browser-actions-09092025,share-campaign-ferk5z,search-pcm,detailedpromptmetrics,file-upload-config,sidebar-settings,placecard-enhance-all,n-30-k-20,pay-ams-treatment,ceo-harmony,finance-chart-clickthrough,labs-audio-expression-scripted-mode,labs-audio-expression-mode-coachmark,labs-audio-expression-story-voice-selector,thinkdeeper5reasoningloweffort,page-title-generation-hapi,skip-preview-event,m365-pills-data-v2,labs-audio-expression-auto-style,edgevision-multitab,flash-cards,finance-earnings,page-safety-check-treatment,analyzedocuments-extendedtokens,labs-audio-expression-preset-card-fixed,lazy-with-retry,sorttoolrouterresult-others-t,character-cognitive-testing-service,voice-flower-bg,thinkdeeper5miniloweffortchainofthought,image-dynamic-width,group-conversations,shar"
		"e-to-invite,deep-research-share-link,cot-output-panel,imagegen-galleryremixquota,place-near-me-fix,related-results-t1,tru-router,pay-migrate-get-checkout-option-v2,voice-safety-patch,uselongcontextmodel,kill-regenerate,speechtranscribev2,browser-automation-inc-max-loop,thinkdeeper-truncator,search-truncation,backstory-trim,suppress-inline-link-nav-dialog,voice-time-formatting,balancedfiletokens,empty-tool-instruction,think-deeper-move-tool-instructions,heycopilot-backstory,vad-buffer,pay-edge-clarity,dr-progress,labs-audio-expression-story-image,remix-suggestions,ceo-remove-search-web,healthcare-safety-patch-v3,person-card,edge-safety-prompt-treatment,share-conversation-with-attachments,image-upload-mmt,dr-summary,cross-selling-t-gpt52,ceo-optimized-loop,podcast-in-voice,track-oldest-merged-message,mem-clean-forget,url-output-sanitization,gpt5-reasoning-harmony-personality-v1,config-responder-option-by-modelname,responding-loop-for-vision-model,reduce-vision-usage,dynamic-answer-cards-ga,dr-outlinks,quiz-in"
		"stant-feedback,gpt-5-on-quick-mode,safety-middleware,ceo-filedownload,hide-feedback-if-no-mic-permission-on-end-call,auth-assertion,connector-consent-v2,existing-teen-enabled,voice-clear-audio-capture-listeners-on-end,dr-shared-orchestrator,memory-settings-v2,election-patch,pagecreation,add-utm-source,warnings-indepth,model-migration,route-chat-to-agent,browser-automation-instruction-gpt5,group-conversations-lazy-creation,reduce-memory-overtriggering,image-model-selector-summary,utm-tracking-use-copilot-com,checkmark-emoji-fix,groupchatnotifications,upfront-persistence,groupchat-mentions,edu-cross-sell,browser-actions-charapita,contextual-suggestions,subs-redirect-to-cmc,cef,voice-new-feedback-string,reject-tier4-start-traffic,time-patch,challenge-asn,min-adaptive-citation-t-nav,cloudflare-challenge,chat-recovery-long-streaming-timeout,enable-audio-capture-worklet,voice-memory-edf,reuse-audio-context-for-voice-output,enable-audio-out-pre-buffering-c,socket-close-track,local-inference-client-side-lb,auth0-ba"
		"sed-user-link,knowledge-extraction-harmony,router-default-preload-intent,hide-conversation-dates,remove-qr,edge-shopping-enable-all-markets,deprecate_widgets_v1,edge-page-sanitization,teen-compliance,edge-ctx-consent-tool-executing,skip-reasoning-in-smart-mode,chat-client-retry,labs-remote-config,voice-name-repetition-fix,ltm-backfill-disabled,skip-append-last-user-message-again,framework-conversation-write,email-reply,voice-enable-new-audio-icon-c,backstorytool,block-image-generation-in-voice,increase-doc-attachment-max-tokens,nav-expand-all-t,remove-clarifying-prompts,readaloud-verbatim-prompt,kill-contextual-suggestions-tabs-check,podcast-project-sources-grounding,edf-store-direct-instruction,naa-has-active-account-check,computeruse-raw-cot,reduce-memory-overtrigger-location-c,search-uploaded-docs-in-project,mem-skip-preview-search,genuiskillssmallf12,searchmode-t2,browser-actions-detailed-summary,generate-flashcard-skill,browser-actions-deprecated-non-charapita,proactive-message-additional-context,searc"
		"hfinance-searchquery,group-conversations-reuse-conv-id,voice-enable-read-aloud-c,edge-text-vision-treatment,max-adaptive-citations-c,user-message-copy,match-message-timestamp,edge-tab-safety-cache,voice-telemetry,m365-wxp-history-sync,kill-shopping-homepage-t,nav-card-short-url,kill-projects-creations-flash-card,computer-agent-skills,browser-remote-actions-for-tasks,conversation-compactor,planning-agent-elicitation,spd-citation-v2-mixed-format,agent-snapshots,group-conversations-unread-indicator,gpt52-reasoning-harmony,superbowl-search,autoprompt-off,earcon-only-after-first-use,voice-restart-telemetry,subs-hot-reload,jailbreakdisabled,pdp-track-price-comp-t,olympics-search,supersonic-task-preview,edf-memory-tuning,task-memory,trs-update-flight,block-document-generation-in-voice,task-notification,shopping-journeys-v2-container,shopping-feed-no-hero-image-t,fix-ftr,discovery-long-summary,avoid-edge-vision-highlight,agent-manager-registry,dicf6867,audioagent-v3,lm-arena-v2,windows-vision-highlights,journeys-ge"
		"neration-v2-t,shopping-jump-back-to-conversation-c,studio-sdk,sdk-ai-message-item,sidebar-vnext,chat-session-affinity,ltm-responding-prompt-tuning-c,topic_continuation_enabled_twice_per_week,trvlflghttf,vertex-timeout,shopping-user-memory-t,fetch-convo,shadowban,update-edge-eu-user-consent-text,genui-tier3-c,genui-ground-counterfactual,discovery-harmony-timestamp,mai-whisper-language-c,gpt51-group-chat,genui-tier4-ground-flight-c,task-notification-no-timeout,shopping-journeys-v2-container-read-c,getcameraimages,web-30s-ping,v3-courteous-wait-c,shopping-feed-thumbs-feedback-toast,conversation-search-region-routing-control,edge-dont-language-switch,upsell-selector,model-training-new-privacy,voice-spatial-info,chainofthoughteventprocessor,chat-message-preview,handle-preview-event,kill-composer-creation-button,smart-mode,smart-mode-6e0b4c6f,smart-mode-cot,smart-mode-flightc,smart-mode-v2-config,searchvideos,searchvideos-google,serpvideocard,video-cards-v2,videocardrespondinginstruction,edge-responder-loop,emit-"
		"all-inference-telemetry,responderactions-all,responding-harmony-4o-v4,multi-file-upload,multiple-file-upload,unlimitedfilereasoning,grounded-edit,page-citation,pages-footnote,gpt5-calcite,responding-harmony-gpt5-v1,smart-mode-default,tool-defs-on-separate-system-message,1s-moc-keep-facets,1s-moc-more-msn,1s-wpo-dis-dnewsr,1s-wpo-dis-nopod,discover-gemfive,discover-more-news-content,discover-news-all-large-cards,discover-newsts,discover-threets,think-deeper-cot,finance-follow,finance-watchlist-ui,prg-cmc-flws,prg-cmc-fnav,improve-context-precision,ds-editprompt,ds-new-progress,smart-mode-gpt5,actionspacereducerv2,longqueryfilter,tsrv3_router,enable-history-cache-write,truncatekmessages,responding-harmony-gpt-5-nosearch,responding-harmony-gpt-5-search,placecardnavigationenabled,placecardpromptoptimizationenabled,switcher-harmony,browser-actions,browserautomationcomputeruse,browserautomationsearchweb,edgeactiondisableouter,morefileupload,sidebar-compact-nav-items,sidebar-narrow,searchplaces-enhanced-infos,sear"
		"chplaces-enhanced-photos,truncatekmessages-k20,truncatekmessages-n30,pay-ams-integration-server,pay-ams-pdp,pay-ams-price-tracking,pay-ams-product-card,edge-page-safety-check,pii-scrubber,sorttoolrouterresult,relatedresults-android,relatedresults-ios,rrcitationv2,searchmode,see-more-results,toolspacereducerclassifierflight,searchweb-page3,searchweb-sd1000,searchweb-shorter,voice-search-timezone,enrich-web-grounding-with-linkedin-api,entity-info,linkedin-url,person-card-prefer-linkedin,person-cards,edge-security-template,image-ocr-hapi,merge-user-messages,deep-research-summary-v3,dr-cover-image,action-result-relaxed-json-escaping,bingify-sanitized-urls,urls-extracted-infer-event,gpt5-reasoning-harmony,thinkdeeper-gpt5reasoning-harmony-personality,dynamic-answer-cards,indepth-comparison-and-details,warnings-and-clarifications,edu-discovery-cross-sell,study-mode-mico-quiz-tutor,citation-v2,citation-v2-cards,citation-v2-nav,inline-image,inline-video,inline-video-moments,adaptive-citations,adaptive-citations-nav"
		"igation,pinned-conversation,dynamic-card-selection-instructions,nav-all-turns,nav-cards-on-all-modes,nav-hostqcscore-filter,navigation-curated-enabled,navigation-curation-gpt4o,skip-nav-classifier,generativeui-mvpt3,genui-fiximage,genui-fiximage-12,genui-json-validator,genui-mvp,genui-preturn-refactor,genui-skills,genui-skills-small,genuimvp,searchmode-gpt51-chat-harmony,searchmode-gpt51-promptv2,edge-copilot-screenshot,edge-text-vision,kill-shopping-homepage,shopping-pdp-hide-price-history,shopping-pdp-price-tracking-fallback,sorttoolsbyfrequencyflight,shopping-feed-no-hero-image,shopping-journey-staged-orchestrator,shopping-journeys-debounce,shopping-limit-concurrency,flight-booking-skill,shopping-user-memory,generativeui-flight-status,generativeui-local-events,generativeui-prayer-vertical-timeline,generativeui-sunrise-v2,genui-core,genui-counterfactual,genui-ground-t,genui-grounding-template-selector,genui-tier2-grounding-templates,genui-turncache-templates\",\"eventInfo_surfaceVisible\":false,\"eventInf"
		"o_isCopilotMode\":true,\"isAADUser\":false,\"isNewUser\":false,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:9516"
		"25,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-2"
		"2-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"UserInfo.Id\":\"3VGqNUdUrjXr2j34tQeir\",\"userConsentPersonalization\":false,\"userConsentModelTraining\":false,\"userSettingComputerUseActions\":false,\"userSubscription\":\"free\",\"accountTier\":\"guest\",\"AppInfo_Version\":\"145.0.3800.82\",\"eventName\":\"edgePendingContextResponses\",\"eventInfo_numMessages\":0}}\n"
		"{\"name\":\"system\",\"time\":\"2026-03-06T07:23:23.396Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":41,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_duration\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BB"
		"CCDD16E182AFC5E06CC216F3A\",\"userPicassoId\":\"3VGqNUdUrjXr2j34tQeir\",\"userFlightIds\":\"imagegenv3,assistant-enable-answer-cards,voice-spatial,weather-cards,edgviswebground,enable-all-app-actions,promptedreasoningcombinedwithsearchpatch,promptmessagewithcards,voices78,allowanonymoususershare,share-chat-page-entry,039add1b-use-fixed-chat-layout,share-image-link,dailybriefing,pages-table,always-show-last-reaction-v2,azureconfigregexblocklist,disable-cmc-auto-reload,onedrive,suggesthangup,correct-personalization-accidental-opt-out,share-campaign,039add1b-chat-sessions-drawer,039add1b-pages-drawer,injectselfharminstructions,039add1b-refresh-token-worker,account-change-chat-reset,preload-chat-messages,1s-moc-logosize,quiz-card-suggestion,send-connected,anonymousattachmentupload,async-disclaimer-text,mem-generate-post-turn,sharecontinue,share-campaign-taeb9y,share-campaign-krq0kf,dr-editprompt-mobile,039add1b-animated-greeting-message-view,greeting-message-animation,image-fallback-thumbnail,adsidsync,think-de"
		"eper-regenerate,smart-mode-flightd-edge,narr-icachuse,img-followup-patch,inject-user-greeting,code-edge-c,videoserp5,searchvideos-bing-fallback,searchimages-bing-fallback,edge-responding-loop-harmony-4o-1010,pay-instacart-canada,quiz-in-create-drawer,deep-research-export-file,m365-conversation-sync,deep-research-export-podcast,multiple,originaldocumentupload,web-multi-fallback-languages,share-campaign-evhqea,share-campaign-rbsrqk,share-campaign-tkzuae,share-campaign-jowp8z,share-campaign-gxcdu3,share-campaign-d2e0f5,share-campaign-dkmev6,share-campaign-coqva4,share-campaign-gez3vb,remove-extra-im-start-context,vision-in-composer-v3,deep-research-nano,export-pages-t,copilot-beta,smart-mode-default-rl,039add1b-uikit-paragraph-view,imagegenv3peakhour,onedrive-fetch,share-continue-v2,ts-dynamic-top-section-t,creator-gallery,old-search-config,thinkdeepero4minichainofthought,image-library-2,image-library-delete-image,igszcls,searchimages-cache,searchvideos-cache,pay-consistent-buy,finance-tooltip-v2,m365-pills-cu"
		"stom,copilot-beta-automatic-opt-in,deep-research,quiz-option-shuffle,image-cards-v2,test-srm-aa-4,deep-research-promo-card,recipe-card,finance-watchlist-v2,finance-crypto,mutesuggestions,pages-link-navigation,pages-skip-page-selector,pages-file-upload,pages-suggested-followups,onedrive-graph,rm-relatedqna,dr-web-upd-w,dr-pro-nano,pay-getbuyoption-migration,pay-getrecipe-migration,pay-price-tracked,pay-shopify-checkout,sports-cards,smart-mode-reason-chat,pages-reasoning-gg,edge-autosuggest,composer-v4,039add1b-sentry-hang-rate-v2,voice-improved-courtesy-wait,quiz-harmony,sticky-conversation-mode,smart-mode-ensemble-switcher,t1_tsrv3_router,title-generation-harmony,pay-conversion-tracking,history-truncation-fix-parent,backstoryinsertall,local-cards,smart-mode-with-hapi,optimized-responding-for-cache,clarity-http-endpoint,share-image-continue,sharemanagement,labs-audio-expression-style-list-layout,nosearchimageonattachment,start-retry,ui-kit-paragraph-view-2,m365-cela-sheet,placecardprompclean-v3,title-generat"
		"ion-v2,eea-personalization-waiting-period,useggvisionmodel,study-mode,searchimages-safe,searchvideos-safe,edge-reload-tab,attachment-suggestions-c,vision-biometric-consent,page-title-generation-v2,kill-picasso-id-on-start,zircon-flight-t,browser-actions-09092025,share-campaign-ferk5z,search-pcm,detailedpromptmetrics,file-upload-config,sidebar-settings,placecard-enhance-all,n-30-k-20,pay-ams-treatment,ceo-harmony,finance-chart-clickthrough,labs-audio-expression-scripted-mode,labs-audio-expression-mode-coachmark,labs-audio-expression-story-voice-selector,thinkdeeper5reasoningloweffort,page-title-generation-hapi,skip-preview-event,m365-pills-data-v2,labs-audio-expression-auto-style,edgevision-multitab,flash-cards,finance-earnings,page-safety-check-treatment,analyzedocuments-extendedtokens,labs-audio-expression-preset-card-fixed,lazy-with-retry,sorttoolrouterresult-others-t,character-cognitive-testing-service,voice-flower-bg,thinkdeeper5miniloweffortchainofthought,image-dynamic-width,group-conversations,share-t"
		"o-invite,deep-research-share-link,cot-output-panel,imagegen-galleryremixquota,place-near-me-fix,related-results-t1,tru-router,pay-migrate-get-checkout-option-v2,voice-safety-patch,uselongcontextmodel,kill-regenerate,speechtranscribev2,browser-automation-inc-max-loop,thinkdeeper-truncator,search-truncation,backstory-trim,suppress-inline-link-nav-dialog,voice-time-formatting,balancedfiletokens,empty-tool-instruction,think-deeper-move-tool-instructions,heycopilot-backstory,vad-buffer,pay-edge-clarity,dr-progress,labs-audio-expression-story-image,remix-suggestions,ceo-remove-search-web,healthcare-safety-patch-v3,person-card,edge-safety-prompt-treatment,share-conversation-with-attachments,image-upload-mmt,dr-summary,cross-selling-t-gpt52,ceo-optimized-loop,podcast-in-voice,track-oldest-merged-message,mem-clean-forget,url-output-sanitization,gpt5-reasoning-harmony-personality-v1,config-responder-option-by-modelname,responding-loop-for-vision-model,reduce-vision-usage,dynamic-answer-cards-ga,dr-outlinks,quiz-insta"
		"nt-feedback,gpt-5-on-quick-mode,safety-middleware,ceo-filedownload,hide-feedback-if-no-mic-permission-on-end-call,auth-assertion,connector-consent-v2,existing-teen-enabled,voice-clear-audio-capture-listeners-on-end,dr-shared-orchestrator,memory-settings-v2,election-patch,pagecreation,add-utm-source,warnings-indepth,model-migration,route-chat-to-agent,browser-automation-instruction-gpt5,group-conversations-lazy-creation,reduce-memory-overtriggering,image-model-selector-summary,utm-tracking-use-copilot-com,checkmark-emoji-fix,groupchatnotifications,upfront-persistence,groupchat-mentions,edu-cross-sell,browser-actions-charapita,contextual-suggestions,subs-redirect-to-cmc,cef,voice-new-feedback-string,reject-tier4-start-traffic,time-patch,challenge-asn,min-adaptive-citation-t-nav,cloudflare-challenge,chat-recovery-long-streaming-timeout,enable-audio-capture-worklet,voice-memory-edf,reuse-audio-context-for-voice-output,enable-audio-out-pre-buffering-c,socket-close-track,local-inference-client-side-lb,auth0-based"
		"-user-link,knowledge-extraction-harmony,router-default-preload-intent,hide-conversation-dates,remove-qr,edge-shopping-enable-all-markets,deprecate_widgets_v1,edge-page-sanitization,teen-compliance,edge-ctx-consent-tool-executing,skip-reasoning-in-smart-mode,chat-client-retry,labs-remote-config,voice-name-repetition-fix,ltm-backfill-disabled,skip-append-last-user-message-again,framework-conversation-write,email-reply,voice-enable-new-audio-icon-c,backstorytool,block-image-generation-in-voice,increase-doc-attachment-max-tokens,nav-expand-all-t,remove-clarifying-prompts,readaloud-verbatim-prompt,kill-contextual-suggestions-tabs-check,podcast-project-sources-grounding,edf-store-direct-instruction,naa-has-active-account-check,computeruse-raw-cot,reduce-memory-overtrigger-location-c,search-uploaded-docs-in-project,mem-skip-preview-search,genuiskillssmallf12,searchmode-t2,browser-actions-detailed-summary,generate-flashcard-skill,browser-actions-deprecated-non-charapita,proactive-message-additional-context,searchfi"
		"nance-searchquery,group-conversations-reuse-conv-id,voice-enable-read-aloud-c,edge-text-vision-treatment,max-adaptive-citations-c,user-message-copy,match-message-timestamp,edge-tab-safety-cache,voice-telemetry,m365-wxp-history-sync,kill-shopping-homepage-t,nav-card-short-url,kill-projects-creations-flash-card,computer-agent-skills,browser-remote-actions-for-tasks,conversation-compactor,planning-agent-elicitation,spd-citation-v2-mixed-format,agent-snapshots,group-conversations-unread-indicator,gpt52-reasoning-harmony,superbowl-search,autoprompt-off,earcon-only-after-first-use,voice-restart-telemetry,subs-hot-reload,jailbreakdisabled,pdp-track-price-comp-t,olympics-search,supersonic-task-preview,edf-memory-tuning,task-memory,trs-update-flight,block-document-generation-in-voice,task-notification,shopping-journeys-v2-container,shopping-feed-no-hero-image-t,fix-ftr,discovery-long-summary,avoid-edge-vision-highlight,agent-manager-registry,dicf6867,audioagent-v3,lm-arena-v2,windows-vision-highlights,journeys-gener"
		"ation-v2-t,shopping-jump-back-to-conversation-c,studio-sdk,sdk-ai-message-item,sidebar-vnext,chat-session-affinity,ltm-responding-prompt-tuning-c,topic_continuation_enabled_twice_per_week,trvlflghttf,vertex-timeout,shopping-user-memory-t,fetch-convo,shadowban,update-edge-eu-user-consent-text,genui-tier3-c,genui-ground-counterfactual,discovery-harmony-timestamp,mai-whisper-language-c,gpt51-group-chat,genui-tier4-ground-flight-c,task-notification-no-timeout,shopping-journeys-v2-container-read-c,getcameraimages,web-30s-ping,v3-courteous-wait-c,shopping-feed-thumbs-feedback-toast,conversation-search-region-routing-control,edge-dont-language-switch,upsell-selector,model-training-new-privacy,voice-spatial-info,chainofthoughteventprocessor,chat-message-preview,handle-preview-event,kill-composer-creation-button,smart-mode,smart-mode-6e0b4c6f,smart-mode-cot,smart-mode-flightc,smart-mode-v2-config,searchvideos,searchvideos-google,serpvideocard,video-cards-v2,videocardrespondinginstruction,edge-responder-loop,emit-all"
		"-inference-telemetry,responderactions-all,responding-harmony-4o-v4,multi-file-upload,multiple-file-upload,unlimitedfilereasoning,grounded-edit,page-citation,pages-footnote,gpt5-calcite,responding-harmony-gpt5-v1,smart-mode-default,tool-defs-on-separate-system-message,1s-moc-keep-facets,1s-moc-more-msn,1s-wpo-dis-dnewsr,1s-wpo-dis-nopod,discover-gemfive,discover-more-news-content,discover-news-all-large-cards,discover-newsts,discover-threets,think-deeper-cot,finance-follow,finance-watchlist-ui,prg-cmc-flws,prg-cmc-fnav,improve-context-precision,ds-editprompt,ds-new-progress,smart-mode-gpt5,actionspacereducerv2,longqueryfilter,tsrv3_router,enable-history-cache-write,truncatekmessages,responding-harmony-gpt-5-nosearch,responding-harmony-gpt-5-search,placecardnavigationenabled,placecardpromptoptimizationenabled,switcher-harmony,browser-actions,browserautomationcomputeruse,browserautomationsearchweb,edgeactiondisableouter,morefileupload,sidebar-compact-nav-items,sidebar-narrow,searchplaces-enhanced-infos,searchp"
		"laces-enhanced-photos,truncatekmessages-k20,truncatekmessages-n30,pay-ams-integration-server,pay-ams-pdp,pay-ams-price-tracking,pay-ams-product-card,edge-page-safety-check,pii-scrubber,sorttoolrouterresult,relatedresults-android,relatedresults-ios,rrcitationv2,searchmode,see-more-results,toolspacereducerclassifierflight,searchweb-page3,searchweb-sd1000,searchweb-shorter,voice-search-timezone,enrich-web-grounding-with-linkedin-api,entity-info,linkedin-url,person-card-prefer-linkedin,person-cards,edge-security-template,image-ocr-hapi,merge-user-messages,deep-research-summary-v3,dr-cover-image,action-result-relaxed-json-escaping,bingify-sanitized-urls,urls-extracted-infer-event,gpt5-reasoning-harmony,thinkdeeper-gpt5reasoning-harmony-personality,dynamic-answer-cards,indepth-comparison-and-details,warnings-and-clarifications,edu-discovery-cross-sell,study-mode-mico-quiz-tutor,citation-v2,citation-v2-cards,citation-v2-nav,inline-image,inline-video,inline-video-moments,adaptive-citations,adaptive-citations-naviga"
		"tion,pinned-conversation,dynamic-card-selection-instructions,nav-all-turns,nav-cards-on-all-modes,nav-hostqcscore-filter,navigation-curated-enabled,navigation-curation-gpt4o,skip-nav-classifier,generativeui-mvpt3,genui-fiximage,genui-fiximage-12,genui-json-validator,genui-mvp,genui-preturn-refactor,genui-skills,genui-skills-small,genuimvp,searchmode-gpt51-chat-harmony,searchmode-gpt51-promptv2,edge-copilot-screenshot,edge-text-vision,kill-shopping-homepage,shopping-pdp-hide-price-history,shopping-pdp-price-tracking-fallback,sorttoolsbyfrequencyflight,shopping-feed-no-hero-image,shopping-journey-staged-orchestrator,shopping-journeys-debounce,shopping-limit-concurrency,flight-booking-skill,shopping-user-memory,generativeui-flight-status,generativeui-local-events,generativeui-prayer-vertical-timeline,generativeui-sunrise-v2,genui-core,genui-counterfactual,genui-ground-t,genui-grounding-template-selector,genui-tier2-grounding-templates,genui-turncache-templates\",\"eventInfo_surfaceVisible\":false,\"eventInfo_i"
		"sCopilotMode\":true,\"isAADUser\":false,\"isNewUser\":false,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:951625,"
		"22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-2"
		"0,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"UserInfo.Id\":\"3VGqNUdUrjXr2j34tQeir\",\"userConsentPersonalization\":false,\"userConsentModelTraining\":false,\"userSettingComputerUseActions\":false,\"userSubscription\":\"free\",\"accountTier\":\"guest\",\"AppInfo_Version\":\"145.0.3800.82\",\"eventName\":\"copilotStart\",\"eventInfo_duration\":7506.100000023842,\"eventInfo_landingPage\":\"homepage\"}}\n"
		"{\"name\":\"system\",\"time\":\"2026-03-06T07:23:23.400Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":42,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edgetab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBCCDD16E182AFC5E06CC216F3A\",\"userPicassoId\":\"3VGqNUdU"
		"rjXr2j34tQeir\",\"userFlightIds\":\"imagegenv3,assistant-enable-answer-cards,voice-spatial,weather-cards,edgviswebground,enable-all-app-actions,promptedreasoningcombinedwithsearchpatch,promptmessagewithcards,voices78,allowanonymoususershare,share-chat-page-entry,039add1b-use-fixed-chat-layout,share-image-link,dailybriefing,pages-table,always-show-last-reaction-v2,azureconfigregexblocklist,disable-cmc-auto-reload,onedrive,suggesthangup,correct-personalization-accidental-opt-out,share-campaign,039add1b-chat-sessions-drawer,039add1b-pages-drawer,injectselfharminstructions,039add1b-refresh-token-worker,account-change-chat-reset,preload-chat-messages,1s-moc-logosize,quiz-card-suggestion,send-connected,anonymousattachmentupload,async-disclaimer-text,mem-generate-post-turn,sharecontinue,share-campaign-taeb9y,share-campaign-krq0kf,dr-editprompt-mobile,039add1b-animated-greeting-message-view,greeting-message-animation,image-fallback-thumbnail,adsidsync,think-deeper-regenerate,smart-mode-flightd-edge,narr-icachuse,im"
		"g-followup-patch,inject-user-greeting,code-edge-c,videoserp5,searchvideos-bing-fallback,searchimages-bing-fallback,edge-responding-loop-harmony-4o-1010,pay-instacart-canada,quiz-in-create-drawer,deep-research-export-file,m365-conversation-sync,deep-research-export-podcast,multiple,originaldocumentupload,web-multi-fallback-languages,share-campaign-evhqea,share-campaign-rbsrqk,share-campaign-tkzuae,share-campaign-jowp8z,share-campaign-gxcdu3,share-campaign-d2e0f5,share-campaign-dkmev6,share-campaign-coqva4,share-campaign-gez3vb,remove-extra-im-start-context,vision-in-composer-v3,deep-research-nano,export-pages-t,copilot-beta,smart-mode-default-rl,039add1b-uikit-paragraph-view,imagegenv3peakhour,onedrive-fetch,share-continue-v2,ts-dynamic-top-section-t,creator-gallery,old-search-config,thinkdeepero4minichainofthought,image-library-2,image-library-delete-image,igszcls,searchimages-cache,searchvideos-cache,pay-consistent-buy,finance-tooltip-v2,m365-pills-custom,copilot-beta-automatic-opt-in,deep-research,quiz-op"
		"tion-shuffle,image-cards-v2,test-srm-aa-4,deep-research-promo-card,recipe-card,finance-watchlist-v2,finance-crypto,mutesuggestions,pages-link-navigation,pages-skip-page-selector,pages-file-upload,pages-suggested-followups,onedrive-graph,rm-relatedqna,dr-web-upd-w,dr-pro-nano,pay-getbuyoption-migration,pay-getrecipe-migration,pay-price-tracked,pay-shopify-checkout,sports-cards,smart-mode-reason-chat,pages-reasoning-gg,edge-autosuggest,composer-v4,039add1b-sentry-hang-rate-v2,voice-improved-courtesy-wait,quiz-harmony,sticky-conversation-mode,smart-mode-ensemble-switcher,t1_tsrv3_router,title-generation-harmony,pay-conversion-tracking,history-truncation-fix-parent,backstoryinsertall,local-cards,smart-mode-with-hapi,optimized-responding-for-cache,clarity-http-endpoint,share-image-continue,sharemanagement,labs-audio-expression-style-list-layout,nosearchimageonattachment,start-retry,ui-kit-paragraph-view-2,m365-cela-sheet,placecardprompclean-v3,title-generation-v2,eea-personalization-waiting-period,useggvisionmod"
		"el,study-mode,searchimages-safe,searchvideos-safe,edge-reload-tab,attachment-suggestions-c,vision-biometric-consent,page-title-generation-v2,kill-picasso-id-on-start,zircon-flight-t,browser-actions-09092025,share-campaign-ferk5z,search-pcm,detailedpromptmetrics,file-upload-config,sidebar-settings,placecard-enhance-all,n-30-k-20,pay-ams-treatment,ceo-harmony,finance-chart-clickthrough,labs-audio-expression-scripted-mode,labs-audio-expression-mode-coachmark,labs-audio-expression-story-voice-selector,thinkdeeper5reasoningloweffort,page-title-generation-hapi,skip-preview-event,m365-pills-data-v2,labs-audio-expression-auto-style,edgevision-multitab,flash-cards,finance-earnings,page-safety-check-treatment,analyzedocuments-extendedtokens,labs-audio-expression-preset-card-fixed,lazy-with-retry,sorttoolrouterresult-others-t,character-cognitive-testing-service,voice-flower-bg,thinkdeeper5miniloweffortchainofthought,image-dynamic-width,group-conversations,share-to-invite,deep-research-share-link,cot-output-panel,image"
		"gen-galleryremixquota,place-near-me-fix,related-results-t1,tru-router,pay-migrate-get-checkout-option-v2,voice-safety-patch,uselongcontextmodel,kill-regenerate,speechtranscribev2,browser-automation-inc-max-loop,thinkdeeper-truncator,search-truncation,backstory-trim,suppress-inline-link-nav-dialog,voice-time-formatting,balancedfiletokens,empty-tool-instruction,think-deeper-move-tool-instructions,heycopilot-backstory,vad-buffer,pay-edge-clarity,dr-progress,labs-audio-expression-story-image,remix-suggestions,ceo-remove-search-web,healthcare-safety-patch-v3,person-card,edge-safety-prompt-treatment,share-conversation-with-attachments,image-upload-mmt,dr-summary,cross-selling-t-gpt52,ceo-optimized-loop,podcast-in-voice,track-oldest-merged-message,mem-clean-forget,url-output-sanitization,gpt5-reasoning-harmony-personality-v1,config-responder-option-by-modelname,responding-loop-for-vision-model,reduce-vision-usage,dynamic-answer-cards-ga,dr-outlinks,quiz-instant-feedback,gpt-5-on-quick-mode,safety-middleware,ceo-fi"
		"ledownload,hide-feedback-if-no-mic-permission-on-end-call,auth-assertion,connector-consent-v2,existing-teen-enabled,voice-clear-audio-capture-listeners-on-end,dr-shared-orchestrator,memory-settings-v2,election-patch,pagecreation,add-utm-source,warnings-indepth,model-migration,route-chat-to-agent,browser-automation-instruction-gpt5,group-conversations-lazy-creation,reduce-memory-overtriggering,image-model-selector-summary,utm-tracking-use-copilot-com,checkmark-emoji-fix,groupchatnotifications,upfront-persistence,groupchat-mentions,edu-cross-sell,browser-actions-charapita,contextual-suggestions,subs-redirect-to-cmc,cef,voice-new-feedback-string,reject-tier4-start-traffic,time-patch,challenge-asn,min-adaptive-citation-t-nav,cloudflare-challenge,chat-recovery-long-streaming-timeout,enable-audio-capture-worklet,voice-memory-edf,reuse-audio-context-for-voice-output,enable-audio-out-pre-buffering-c,socket-close-track,local-inference-client-side-lb,auth0-based-user-link,knowledge-extraction-harmony,router-default-p"
		"reload-intent,hide-conversation-dates,remove-qr,edge-shopping-enable-all-markets,deprecate_widgets_v1,edge-page-sanitization,teen-compliance,edge-ctx-consent-tool-executing,skip-reasoning-in-smart-mode,chat-client-retry,labs-remote-config,voice-name-repetition-fix,ltm-backfill-disabled,skip-append-last-user-message-again,framework-conversation-write,email-reply,voice-enable-new-audio-icon-c,backstorytool,block-image-generation-in-voice,increase-doc-attachment-max-tokens,nav-expand-all-t,remove-clarifying-prompts,readaloud-verbatim-prompt,kill-contextual-suggestions-tabs-check,podcast-project-sources-grounding,edf-store-direct-instruction,naa-has-active-account-check,computeruse-raw-cot,reduce-memory-overtrigger-location-c,search-uploaded-docs-in-project,mem-skip-preview-search,genuiskillssmallf12,searchmode-t2,browser-actions-detailed-summary,generate-flashcard-skill,browser-actions-deprecated-non-charapita,proactive-message-additional-context,searchfinance-searchquery,group-conversations-reuse-conv-id,voic"
		"e-enable-read-aloud-c,edge-text-vision-treatment,max-adaptive-citations-c,user-message-copy,match-message-timestamp,edge-tab-safety-cache,voice-telemetry,m365-wxp-history-sync,kill-shopping-homepage-t,nav-card-short-url,kill-projects-creations-flash-card,computer-agent-skills,browser-remote-actions-for-tasks,conversation-compactor,planning-agent-elicitation,spd-citation-v2-mixed-format,agent-snapshots,group-conversations-unread-indicator,gpt52-reasoning-harmony,superbowl-search,autoprompt-off,earcon-only-after-first-use,voice-restart-telemetry,subs-hot-reload,jailbreakdisabled,pdp-track-price-comp-t,olympics-search,supersonic-task-preview,edf-memory-tuning,task-memory,trs-update-flight,block-document-generation-in-voice,task-notification,shopping-journeys-v2-container,shopping-feed-no-hero-image-t,fix-ftr,discovery-long-summary,avoid-edge-vision-highlight,agent-manager-registry,dicf6867,audioagent-v3,lm-arena-v2,windows-vision-highlights,journeys-generation-v2-t,shopping-jump-back-to-conversation-c,studio-s"
		"dk,sdk-ai-message-item,sidebar-vnext,chat-session-affinity,ltm-responding-prompt-tuning-c,topic_continuation_enabled_twice_per_week,trvlflghttf,vertex-timeout,shopping-user-memory-t,fetch-convo,shadowban,update-edge-eu-user-consent-text,genui-tier3-c,genui-ground-counterfactual,discovery-harmony-timestamp,mai-whisper-language-c,gpt51-group-chat,genui-tier4-ground-flight-c,task-notification-no-timeout,shopping-journeys-v2-container-read-c,getcameraimages,web-30s-ping,v3-courteous-wait-c,shopping-feed-thumbs-feedback-toast,conversation-search-region-routing-control,edge-dont-language-switch,upsell-selector,model-training-new-privacy,voice-spatial-info,chainofthoughteventprocessor,chat-message-preview,handle-preview-event,kill-composer-creation-button,smart-mode,smart-mode-6e0b4c6f,smart-mode-cot,smart-mode-flightc,smart-mode-v2-config,searchvideos,searchvideos-google,serpvideocard,video-cards-v2,videocardrespondinginstruction,edge-responder-loop,emit-all-inference-telemetry,responderactions-all,responding-har"
		"mony-4o-v4,multi-file-upload,multiple-file-upload,unlimitedfilereasoning,grounded-edit,page-citation,pages-footnote,gpt5-calcite,responding-harmony-gpt5-v1,smart-mode-default,tool-defs-on-separate-system-message,1s-moc-keep-facets,1s-moc-more-msn,1s-wpo-dis-dnewsr,1s-wpo-dis-nopod,discover-gemfive,discover-more-news-content,discover-news-all-large-cards,discover-newsts,discover-threets,think-deeper-cot,finance-follow,finance-watchlist-ui,prg-cmc-flws,prg-cmc-fnav,improve-context-precision,ds-editprompt,ds-new-progress,smart-mode-gpt5,actionspacereducerv2,longqueryfilter,tsrv3_router,enable-history-cache-write,truncatekmessages,responding-harmony-gpt-5-nosearch,responding-harmony-gpt-5-search,placecardnavigationenabled,placecardpromptoptimizationenabled,switcher-harmony,browser-actions,browserautomationcomputeruse,browserautomationsearchweb,edgeactiondisableouter,morefileupload,sidebar-compact-nav-items,sidebar-narrow,searchplaces-enhanced-infos,searchplaces-enhanced-photos,truncatekmessages-k20,truncatekmes"
		"sages-n30,pay-ams-integration-server,pay-ams-pdp,pay-ams-price-tracking,pay-ams-product-card,edge-page-safety-check,pii-scrubber,sorttoolrouterresult,relatedresults-android,relatedresults-ios,rrcitationv2,searchmode,see-more-results,toolspacereducerclassifierflight,searchweb-page3,searchweb-sd1000,searchweb-shorter,voice-search-timezone,enrich-web-grounding-with-linkedin-api,entity-info,linkedin-url,person-card-prefer-linkedin,person-cards,edge-security-template,image-ocr-hapi,merge-user-messages,deep-research-summary-v3,dr-cover-image,action-result-relaxed-json-escaping,bingify-sanitized-urls,urls-extracted-infer-event,gpt5-reasoning-harmony,thinkdeeper-gpt5reasoning-harmony-personality,dynamic-answer-cards,indepth-comparison-and-details,warnings-and-clarifications,edu-discovery-cross-sell,study-mode-mico-quiz-tutor,citation-v2,citation-v2-cards,citation-v2-nav,inline-image,inline-video,inline-video-moments,adaptive-citations,adaptive-citations-navigation,pinned-conversation,dynamic-card-selection-instruct"
		"ions,nav-all-turns,nav-cards-on-all-modes,nav-hostqcscore-filter,navigation-curated-enabled,navigation-curation-gpt4o,skip-nav-classifier,generativeui-mvpt3,genui-fiximage,genui-fiximage-12,genui-json-validator,genui-mvp,genui-preturn-refactor,genui-skills,genui-skills-small,genuimvp,searchmode-gpt51-chat-harmony,searchmode-gpt51-promptv2,edge-copilot-screenshot,edge-text-vision,kill-shopping-homepage,shopping-pdp-hide-price-history,shopping-pdp-price-tracking-fallback,sorttoolsbyfrequencyflight,shopping-feed-no-hero-image,shopping-journey-staged-orchestrator,shopping-journeys-debounce,shopping-limit-concurrency,flight-booking-skill,shopping-user-memory,generativeui-flight-status,generativeui-local-events,generativeui-prayer-vertical-timeline,generativeui-sunrise-v2,genui-core,genui-counterfactual,genui-ground-t,genui-grounding-template-selector,genui-tier2-grounding-templates,genui-turncache-templates\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"isAADUser\":false,\"isNewUser\":fa"
		"lse,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d"
		"375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12,P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-7"
		"8306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"UserInfo.Id\":\"3VGqNUdUrjXr2j34tQeir\",\"userConsentPersonalization\":false,\"userConsentModelTraining\":false,\"userSettingComputerUseActions\":false,\"userSubscription\":\"free\",\"accountTier\":\"guest\",\"AppInfo_Version\":\"145.0.3800.82\",\"eventName\":\"copilotAdsSignal\",\"eventInfo_scenario\":\"syncAdvertisingId\",\"eventInfo_conversationId\":\"vXq2PhARMGqYLvjWoYwWG\",\"eventInfo_additionalData\":\"{\\\\\"isIdSyncDisabled\\\\\":false,\\\\\"isTemporaryConversation\\\\\":false,\\\\\"isAuthenticated\\\\\":false,\\\\\"isAdPersonalizationEnabled\\\\\":false,\\\\\"enforceAdsOptOutOfPersonalization\\\\\":true,\\\\\"isGdprPlusRegion\\\\\":false,\\\\\"isChoiceCookieEmpty\\\\\":true}\"}}\n"
		"{\"name\":\"apiresponse\",\"time\":\"2026-03-06T07:23:24.904Z\",\"ver\":\"4.0\",\"iKey\":\"o:be6e4c19699f4fdf9f8c0ec9f9b398ef\",\"ext\":{\"web\":{\"consentDetails\":\"{\\\\\"Required\\\\\":true,\\\\\"Analytics\\\\\":false,\\\\\"SocialMedia\\\\\":false,\\\\\"Advertising\\\\\":false,\\\\\"GPC_DataSharingOptIn\\\\\":true}\",\"domain\":\"copilot.microsoft.com\",\"browser\":\"Edge\",\"browserVer\":\"145\",\"screenRes\":\"0X0\",\"userConsent\":false},\"sdk\":{\"ver\":\"1DS-Web-JS-4.3.3\",\"seq\":43,\"epoch\":\"2742084697\"},\"app\":{\"locale\":\"en-US\",\"sesId\":\"6Rez4jAGGRdEsMNpjbvjU7\"},\"user\":{\"locale\":\"en-US\"},\"intweb\":{},\"utc\":{\"popSample\":100},\"loc\":{\"tz\":\"+05:30\"},\"metadata\":{\"f\":{\"eventInfo_status\":{\"t\":6},\"eventInfo_duration\":{\"t\":6},\"eventInfo_responseContentLength\":{\"t\":6}}}},\"data\":{\"baseData\":{\"properties\":{\"version\":\"PostChannel=4.3.3;SystemPropertiesCollector=4.3.3\"}},\"appName\":\"CopilotN-prod-web-edgetab\",\"appVersion\":\"9569f5a\",\"surface\":\"edg"
		"etab\",\"server\":\"studio\",\"surfaceVersion\":\"unknown\",\"userMuid\":\"0D034BBCCDD16E182AFC5E06CC216F3A\",\"userPicassoId\":\"3VGqNUdUrjXr2j34tQeir\",\"userFlightIds\":\"imagegenv3,assistant-enable-answer-cards,voice-spatial,weather-cards,edgviswebground,enable-all-app-actions,promptedreasoningcombinedwithsearchpatch,promptmessagewithcards,voices78,allowanonymoususershare,share-chat-page-entry,039add1b-use-fixed-chat-layout,share-image-link,dailybriefing,pages-table,always-show-last-reaction-v2,azureconfigregexblocklist,disable-cmc-auto-reload,onedrive,suggesthangup,correct-personalization-accidental-opt-out,share-campaign,039add1b-chat-sessions-drawer,039add1b-pages-drawer,injectselfharminstructions,039add1b-refresh-token-worker,account-change-chat-reset,preload-chat-messages,1s-moc-logosize,quiz-card-suggestion,send-connected,anonymousattachmentupload,async-disclaimer-text,mem-generate-post-turn,sharecontinue,share-campaign-taeb9y,share-campaign-krq0kf,dr-editprompt-mobile,039add1b-animated-greeting-m"
		"essage-view,greeting-message-animation,image-fallback-thumbnail,adsidsync,think-deeper-regenerate,smart-mode-flightd-edge,narr-icachuse,img-followup-patch,inject-user-greeting,code-edge-c,videoserp5,searchvideos-bing-fallback,searchimages-bing-fallback,edge-responding-loop-harmony-4o-1010,pay-instacart-canada,quiz-in-create-drawer,deep-research-export-file,m365-conversation-sync,deep-research-export-podcast,multiple,originaldocumentupload,web-multi-fallback-languages,share-campaign-evhqea,share-campaign-rbsrqk,share-campaign-tkzuae,share-campaign-jowp8z,share-campaign-gxcdu3,share-campaign-d2e0f5,share-campaign-dkmev6,share-campaign-coqva4,share-campaign-gez3vb,remove-extra-im-start-context,vision-in-composer-v3,deep-research-nano,export-pages-t,copilot-beta,smart-mode-default-rl,039add1b-uikit-paragraph-view,imagegenv3peakhour,onedrive-fetch,share-continue-v2,ts-dynamic-top-section-t,creator-gallery,old-search-config,thinkdeepero4minichainofthought,image-library-2,image-library-delete-image,igszcls,searchi"
		"mages-cache,searchvideos-cache,pay-consistent-buy,finance-tooltip-v2,m365-pills-custom,copilot-beta-automatic-opt-in,deep-research,quiz-option-shuffle,image-cards-v2,test-srm-aa-4,deep-research-promo-card,recipe-card,finance-watchlist-v2,finance-crypto,mutesuggestions,pages-link-navigation,pages-skip-page-selector,pages-file-upload,pages-suggested-followups,onedrive-graph,rm-relatedqna,dr-web-upd-w,dr-pro-nano,pay-getbuyoption-migration,pay-getrecipe-migration,pay-price-tracked,pay-shopify-checkout,sports-cards,smart-mode-reason-chat,pages-reasoning-gg,edge-autosuggest,composer-v4,039add1b-sentry-hang-rate-v2,voice-improved-courtesy-wait,quiz-harmony,sticky-conversation-mode,smart-mode-ensemble-switcher,t1_tsrv3_router,title-generation-harmony,pay-conversion-tracking,history-truncation-fix-parent,backstoryinsertall,local-cards,smart-mode-with-hapi,optimized-responding-for-cache,clarity-http-endpoint,share-image-continue,sharemanagement,labs-audio-expression-style-list-layout,nosearchimageonattachment,start-"
		"retry,ui-kit-paragraph-view-2,m365-cela-sheet,placecardprompclean-v3,title-generation-v2,eea-personalization-waiting-period,useggvisionmodel,study-mode,searchimages-safe,searchvideos-safe,edge-reload-tab,attachment-suggestions-c,vision-biometric-consent,page-title-generation-v2,kill-picasso-id-on-start,zircon-flight-t,browser-actions-09092025,share-campaign-ferk5z,search-pcm,detailedpromptmetrics,file-upload-config,sidebar-settings,placecard-enhance-all,n-30-k-20,pay-ams-treatment,ceo-harmony,finance-chart-clickthrough,labs-audio-expression-scripted-mode,labs-audio-expression-mode-coachmark,labs-audio-expression-story-voice-selector,thinkdeeper5reasoningloweffort,page-title-generation-hapi,skip-preview-event,m365-pills-data-v2,labs-audio-expression-auto-style,edgevision-multitab,flash-cards,finance-earnings,page-safety-check-treatment,analyzedocuments-extendedtokens,labs-audio-expression-preset-card-fixed,lazy-with-retry,sorttoolrouterresult-others-t,character-cognitive-testing-service,voice-flower-bg,think"
		"deeper5miniloweffortchainofthought,image-dynamic-width,group-conversations,share-to-invite,deep-research-share-link,cot-output-panel,imagegen-galleryremixquota,place-near-me-fix,related-results-t1,tru-router,pay-migrate-get-checkout-option-v2,voice-safety-patch,uselongcontextmodel,kill-regenerate,speechtranscribev2,browser-automation-inc-max-loop,thinkdeeper-truncator,search-truncation,backstory-trim,suppress-inline-link-nav-dialog,voice-time-formatting,balancedfiletokens,empty-tool-instruction,think-deeper-move-tool-instructions,heycopilot-backstory,vad-buffer,pay-edge-clarity,dr-progress,labs-audio-expression-story-image,remix-suggestions,ceo-remove-search-web,healthcare-safety-patch-v3,person-card,edge-safety-prompt-treatment,share-conversation-with-attachments,image-upload-mmt,dr-summary,cross-selling-t-gpt52,ceo-optimized-loop,podcast-in-voice,track-oldest-merged-message,mem-clean-forget,url-output-sanitization,gpt5-reasoning-harmony-personality-v1,config-responder-option-by-modelname,responding-loop-f"
		"or-vision-model,reduce-vision-usage,dynamic-answer-cards-ga,dr-outlinks,quiz-instant-feedback,gpt-5-on-quick-mode,safety-middleware,ceo-filedownload,hide-feedback-if-no-mic-permission-on-end-call,auth-assertion,connector-consent-v2,existing-teen-enabled,voice-clear-audio-capture-listeners-on-end,dr-shared-orchestrator,memory-settings-v2,election-patch,pagecreation,add-utm-source,warnings-indepth,model-migration,route-chat-to-agent,browser-automation-instruction-gpt5,group-conversations-lazy-creation,reduce-memory-overtriggering,image-model-selector-summary,utm-tracking-use-copilot-com,checkmark-emoji-fix,groupchatnotifications,upfront-persistence,groupchat-mentions,edu-cross-sell,browser-actions-charapita,contextual-suggestions,subs-redirect-to-cmc,cef,voice-new-feedback-string,reject-tier4-start-traffic,time-patch,challenge-asn,min-adaptive-citation-t-nav,cloudflare-challenge,chat-recovery-long-streaming-timeout,enable-audio-capture-worklet,voice-memory-edf,reuse-audio-context-for-voice-output,enable-audio"
		"-out-pre-buffering-c,socket-close-track,local-inference-client-side-lb,auth0-based-user-link,knowledge-extraction-harmony,router-default-preload-intent,hide-conversation-dates,remove-qr,edge-shopping-enable-all-markets,deprecate_widgets_v1,edge-page-sanitization,teen-compliance,edge-ctx-consent-tool-executing,skip-reasoning-in-smart-mode,chat-client-retry,labs-remote-config,voice-name-repetition-fix,ltm-backfill-disabled,skip-append-last-user-message-again,framework-conversation-write,email-reply,voice-enable-new-audio-icon-c,backstorytool,block-image-generation-in-voice,increase-doc-attachment-max-tokens,nav-expand-all-t,remove-clarifying-prompts,readaloud-verbatim-prompt,kill-contextual-suggestions-tabs-check,podcast-project-sources-grounding,edf-store-direct-instruction,naa-has-active-account-check,computeruse-raw-cot,reduce-memory-overtrigger-location-c,search-uploaded-docs-in-project,mem-skip-preview-search,genuiskillssmallf12,searchmode-t2,browser-actions-detailed-summary,generate-flashcard-skill,brow"
		"ser-actions-deprecated-non-charapita,proactive-message-additional-context,searchfinance-searchquery,group-conversations-reuse-conv-id,voice-enable-read-aloud-c,edge-text-vision-treatment,max-adaptive-citations-c,user-message-copy,match-message-timestamp,edge-tab-safety-cache,voice-telemetry,m365-wxp-history-sync,kill-shopping-homepage-t,nav-card-short-url,kill-projects-creations-flash-card,computer-agent-skills,browser-remote-actions-for-tasks,conversation-compactor,planning-agent-elicitation,spd-citation-v2-mixed-format,agent-snapshots,group-conversations-unread-indicator,gpt52-reasoning-harmony,superbowl-search,autoprompt-off,earcon-only-after-first-use,voice-restart-telemetry,subs-hot-reload,jailbreakdisabled,pdp-track-price-comp-t,olympics-search,supersonic-task-preview,edf-memory-tuning,task-memory,trs-update-flight,block-document-generation-in-voice,task-notification,shopping-journeys-v2-container,shopping-feed-no-hero-image-t,fix-ftr,discovery-long-summary,avoid-edge-vision-highlight,agent-manager-re"
		"gistry,dicf6867,audioagent-v3,lm-arena-v2,windows-vision-highlights,journeys-generation-v2-t,shopping-jump-back-to-conversation-c,studio-sdk,sdk-ai-message-item,sidebar-vnext,chat-session-affinity,ltm-responding-prompt-tuning-c,topic_continuation_enabled_twice_per_week,trvlflghttf,vertex-timeout,shopping-user-memory-t,fetch-convo,shadowban,update-edge-eu-user-consent-text,genui-tier3-c,genui-ground-counterfactual,discovery-harmony-timestamp,mai-whisper-language-c,gpt51-group-chat,genui-tier4-ground-flight-c,task-notification-no-timeout,shopping-journeys-v2-container-read-c,getcameraimages,web-30s-ping,v3-courteous-wait-c,shopping-feed-thumbs-feedback-toast,conversation-search-region-routing-control,edge-dont-language-switch,upsell-selector,model-training-new-privacy,voice-spatial-info,chainofthoughteventprocessor,chat-message-preview,handle-preview-event,kill-composer-creation-button,smart-mode,smart-mode-6e0b4c6f,smart-mode-cot,smart-mode-flightc,smart-mode-v2-config,searchvideos,searchvideos-google,serpvi"
		"deocard,video-cards-v2,videocardrespondinginstruction,edge-responder-loop,emit-all-inference-telemetry,responderactions-all,responding-harmony-4o-v4,multi-file-upload,multiple-file-upload,unlimitedfilereasoning,grounded-edit,page-citation,pages-footnote,gpt5-calcite,responding-harmony-gpt5-v1,smart-mode-default,tool-defs-on-separate-system-message,1s-moc-keep-facets,1s-moc-more-msn,1s-wpo-dis-dnewsr,1s-wpo-dis-nopod,discover-gemfive,discover-more-news-content,discover-news-all-large-cards,discover-newsts,discover-threets,think-deeper-cot,finance-follow,finance-watchlist-ui,prg-cmc-flws,prg-cmc-fnav,improve-context-precision,ds-editprompt,ds-new-progress,smart-mode-gpt5,actionspacereducerv2,longqueryfilter,tsrv3_router,enable-history-cache-write,truncatekmessages,responding-harmony-gpt-5-nosearch,responding-harmony-gpt-5-search,placecardnavigationenabled,placecardpromptoptimizationenabled,switcher-harmony,browser-actions,browserautomationcomputeruse,browserautomationsearchweb,edgeactiondisableouter,morefileu"
		"pload,sidebar-compact-nav-items,sidebar-narrow,searchplaces-enhanced-infos,searchplaces-enhanced-photos,truncatekmessages-k20,truncatekmessages-n30,pay-ams-integration-server,pay-ams-pdp,pay-ams-price-tracking,pay-ams-product-card,edge-page-safety-check,pii-scrubber,sorttoolrouterresult,relatedresults-android,relatedresults-ios,rrcitationv2,searchmode,see-more-results,toolspacereducerclassifierflight,searchweb-page3,searchweb-sd1000,searchweb-shorter,voice-search-timezone,enrich-web-grounding-with-linkedin-api,entity-info,linkedin-url,person-card-prefer-linkedin,person-cards,edge-security-template,image-ocr-hapi,merge-user-messages,deep-research-summary-v3,dr-cover-image,action-result-relaxed-json-escaping,bingify-sanitized-urls,urls-extracted-infer-event,gpt5-reasoning-harmony,thinkdeeper-gpt5reasoning-harmony-personality,dynamic-answer-cards,indepth-comparison-and-details,warnings-and-clarifications,edu-discovery-cross-sell,study-mode-mico-quiz-tutor,citation-v2,citation-v2-cards,citation-v2-nav,inline-im"
		"age,inline-video,inline-video-moments,adaptive-citations,adaptive-citations-navigation,pinned-conversation,dynamic-card-selection-instructions,nav-all-turns,nav-cards-on-all-modes,nav-hostqcscore-filter,navigation-curated-enabled,navigation-curation-gpt4o,skip-nav-classifier,generativeui-mvpt3,genui-fiximage,genui-fiximage-12,genui-json-validator,genui-mvp,genui-preturn-refactor,genui-skills,genui-skills-small,genuimvp,searchmode-gpt51-chat-harmony,searchmode-gpt51-promptv2,edge-copilot-screenshot,edge-text-vision,kill-shopping-homepage,shopping-pdp-hide-price-history,shopping-pdp-price-tracking-fallback,sorttoolsbyfrequencyflight,shopping-feed-no-hero-image,shopping-journey-staged-orchestrator,shopping-journeys-debounce,shopping-limit-concurrency,flight-booking-skill,shopping-user-memory,generativeui-flight-status,generativeui-local-events,generativeui-prayer-vertical-timeline,generativeui-sunrise-v2,genui-core,genui-counterfactual,genui-ground-t,genui-grounding-template-selector,genui-tier2-grounding-temp"
		"lates,genui-turncache-templates\",\"eventInfo_surfaceVisible\":false,\"eventInfo_isCopilotMode\":true,\"isAADUser\":false,\"isNewUser\":false,\"pathname\":\"/\",\"anaheimId\":\"8023874198853088286\",\"chromiumFlightIds\":\"P-X-1769418-1-3,P-X-1768588-1-3,P-X-1729070-2-5,P-X-1755189-2-3,P-X-1712585-1-7,P-X-1740005-7-13,P-X-1249885-2-7,P-X-1568853-1-11,P-X-1727875-3-18,P-X-1735406-2-5,P-X-1693143-1-5,P-X-1725512-2-6,P-X-1632564-3-19,P-X-1725327-1-3,P-X-1711388-2-7,P-X-1696748-1-5,P-X-1701950-1-5,P-X-1705588-2-3,P-X-1692566-2-5,P-X-1681770-3-12,P-X-1693401-1-5,P-X-1640115-1-9,P-X-1677458-1-7,P-X-1679048-1-6,P-X-1443673-1-7,P-X-1673636-2-7,P-X-1671773-2-4,P-X-1669756-1-3,P-X-1606168-1-9,P-X-1667710-1-3,P-X-1648139-3-13,P-X-1657094-1-5,P-X-1643943-2-5,P-X-1642561-5-13,P-X-1630496-1-5,P-X-1607760-3-11,P-X-1615855-1-11,P-X-1596019-2-11,P-X-1540281-3-4,P-X-1140965-5-22,P-X-1471773-1-5,P-X-1092557-5-43,P-X-1440194-4-21,P-X-1220520-1-7,composerturnaroundux:999191,servernewbingpartner:1004138,ja4h9187:996410,treatment"
		"_6g7i0213:993988,83993905:985766,external-stable-treatment:989675,6ii7h921:951625,22f13740:1003583,externalv1:953090,eb0h7784:989442,0253d375:969912,hh632186:966219,workspacesv2_76ebi997:975944,1f1je298exp:978718,5fjei601:995184,a749h503:950779,coupons_non_blocking_task_runner:996106,treatment_a6hgd286:999588,5ii8a716:940832,732gi965v1:987970,9a8cf410:944013,d7669133:951568,5gh12322:970161,dd32e397:977465,base-treatment-18a2f284:878704,hh69d222:991188,ig54b126:959751,rustymarkov:986208,52g0j119:916619,6i033874:951846,edgepasskeytreatmentstable:933405,5f3je496:999770,c1bg4163:997773,gejhh424:916791,388ii190:952720,rubyallowed:815735,844b6531:948406,topnewsnudges:916296,treatment-with-scroll-fix-2cfd8523:951828,h1a53258:797301,29188615:824563,6hf3f664:931969,5gf64348:952724,92if2247:584837,P-R-1771297-2-5,P-R-1738217-1-7,P-R-1731486-5-13,P-R-1671932-1-6,P-R-1241132-1-6,P-R-1129815-1-5,P-R-1113531-4-9,P-R-1099640-1-4,P-R-1098501-1-7,P-R-1090419-2-5,P-R-1054140-1-5,P-R-1049918-1-4,P-R-1036635-1-5,P-R-68474-9-12"
		",P-R-60617-8-21,P-R-45373-8-86,P-R-1629967-6-10,P-R-1599889-22-18,P-R-1574995-22-20,P-R-1075865-1-8,P-R-1093245-1-19,P-R-108604-1-37,P-R-78306-1-18,P-R-73626-1-17,P-R-63165-4-26,P-R-53243-2-7,P-R-40093-3-26,P-R-38744-7-97,P-R-31899-29-499,P-D-1158614-2-4,P-R-1291681-16-17,P-R-1716517-1-6,P-R-1692180-1-6,P-R-1038760-1-10\",\"renderingType\":\"ssr\",\"UserInfo.Id\":\"3VGqNUdUrjXr2j34tQeir\",\"userConsentPersonalization\":false,\"userConsentModelTraining\":false,\"userSettingComputerUseActions\":false,\"userSubscription\":\"free\",\"accountTier\":\"guest\",\"AppInfo_Version\":\"145.0.3800.82\",\"eventName\":\"copilotApiResponse\",\"eventInfo_path\":\"https://c.bing.com/cp?cpid=3VGqNUdUrjXr2j34tQeir&cvid=vXq2PhARMGqYLvjWoYwWG&ps=1\",\"eventInfo_method\":\"GET\",\"eventInfo_status\":0,\"eventInfo_duration\":1502.1000000238419,\"eventInfo_responseContentLength\":0}}" ;


# 8 "globals.h" 2


 
 


# 3 "c:\\lr_scripts\\demo_script\\combined_Demo_script.c" 2

# 1 "vuser_init.c" 1
vuser_init()
{
	return 0;
}
# 4 "c:\\lr_scripts\\demo_script\\combined_Demo_script.c" 2

# 1 "Action.c" 1
Action()
{



	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");


	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\"Not:A-Brand\";v=\"99\", \"Microsoft Edge\";v=\"145\", \"Chromium\";v=\"145\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");
	
	lr_start_transaction("S01_DemoScript_T01_Launch");

	web_url("thinking-tester-contact-list.herokuapp.com", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"LAST");
	
	lr_end_transaction("S01_DemoScript_T01_Launch",2);

	(web_remove_auto_header("Sec-Fetch-Dest", "ImplicitGen=Yes", "LAST"));

	web_add_header("Sec-Fetch-Dest", 
		"empty");

	(web_remove_auto_header("Sec-Fetch-Mode", "ImplicitGen=Yes", "LAST"));

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	lr_think_time(4);

	 

	(web_remove_auto_header("Sec-Fetch-Storage-Access", "ImplicitGen=Yes", "LAST"));

	web_add_header("Access-Control-Request-Headers", 
		"apikey,cache-control,client-id,client-version,content-type,time-delta-to-apply-millis,upload-time");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_add_auto_header("Origin", 
		"https://copilot.microsoft.com");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");


	web_add_header("Origin", 
		"https://thinking-tester-contact-list.herokuapp.com");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	lr_think_time(7);
	
	lr_start_transaction("S01_DemoScript_T02_Login");
	
	web_reg_save_param_ex(
		"ParamName=c_Token",
		"LB=\"token\":\"",
		"RB=\"",
		"SEARCH_FILTERS",
		"LAST");

	web_custom_request("login", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/users/login", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"email\":\"alien@abc.com\",\"password\":\"Alien@13\"}", 
		"LAST");
	


	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("contactList", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"LAST");

	(web_remove_auto_header("sec-ch-ua", "ImplicitGen=Yes", "LAST"));

	(web_remove_auto_header("sec-ch-ua-mobile", "ImplicitGen=Yes", "LAST"));

	(web_remove_auto_header("sec-ch-ua-platform", "ImplicitGen=Yes", "LAST"));

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("sec-ch-ua", 
		"\"Not:A-Brand\";v=\"99\", \"Microsoft Edge\";v=\"145\", \"Chromium\";v=\"145\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");
	
	web_add_header("Authorization", "Bearer {c_Token}");

	web_custom_request("contacts", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		"LAST");
	
		lr_end_transaction("S01_DemoScript_T02_Login",2);

	 

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(11);
	
		lr_start_transaction("S01_DemoScript_T03_ClickAddContact");

	web_url("addContact", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/addContact", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		"LAST");

	(web_remove_auto_header("sec-ch-ua", "ImplicitGen=Yes", "LAST"));

	(web_remove_auto_header("sec-ch-ua-mobile", "ImplicitGen=Yes", "LAST"));

	(web_remove_auto_header("sec-ch-ua-platform", "ImplicitGen=Yes", "LAST"));

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Mesh-Client-Arch", 
		"x86_64");

	web_add_header("Sec-Mesh-Client-Edge-Channel", 
		"stable");

	web_add_header("Sec-Mesh-Client-Edge-Version", 
		"145.0.3800.82");

	web_add_header("Sec-Mesh-Client-OS", 
		"Windows");

	web_add_header("Sec-Mesh-Client-OS-Version", 
		"10.0.26200");

	web_add_header("Sec-Mesh-Client-WebView", 
		"0");

	lr_end_transaction("S01_DemoScript_T03_ClickAddContact",2);

	 

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("Origin", 
		"https://thinking-tester-contact-list.herokuapp.com");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("sec-ch-ua", 
		"\"Not:A-Brand\";v=\"99\", \"Microsoft Edge\";v=\"145\", \"Chromium\";v=\"145\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	lr_think_time(29);
	
	lr_start_transaction("S01_DemoScript_T04_SubmitContact");
	
	web_add_header("Authorization", "Bearer {c_Token}");

	web_custom_request("contacts_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/addContact", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"firstName\":\"Santhosh\",\"lastName\":\"A\",\"phone\":\"9876543210\"}", 
		"LAST");
	
	

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("contactList_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Resource=0", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/addContact", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=/css/styles.css", "ENDITEM", 
		"Url=/img/thinkingTesterLogo.png", "ENDITEM", 
		"Url=/js/contactList.js", "ENDITEM", 
		"Url=/img/thinkingTesterIcon.png", "ENDITEM", 
		"LAST");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");
	
	web_add_header("Authorization", "Bearer {c_Token}");

	web_custom_request("contacts_3", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		"LAST");
	
	lr_end_transaction("S01_DemoScript_T04_SubmitContact",2);

	 

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(10);
	
	lr_start_transaction("S01_DemoScript_T05_Logout");

	web_url("logout", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/logout", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		"LAST");
	
	lr_end_transaction("S01_DemoScript_T05_Logout",2);

	(web_remove_auto_header("sec-ch-ua", "ImplicitGen=Yes", "LAST"));

	(web_remove_auto_header("sec-ch-ua-mobile", "ImplicitGen=Yes", "LAST"));

	(web_remove_auto_header("sec-ch-ua-platform", "ImplicitGen=Yes", "LAST"));

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_custom_request("3_5", 
		"URL=https://nav-edge.smartscreen.microsoft.com/api/browser/edge/navigate/3", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0\",\"redirectChain\":[],\"enhancedRedirectChain\":{\"redirectSource\":null,\"referrerChain\":[]},\"identity\":{\"user\":{\"locale\":\"en-US\"},\"device\":{\"id\":null,\"customId\":\"724e6b55-2db0-48f8-8304-bdd3b1009d3e\",\"onlineIdTicket\":\"t=GwD2Ad9tBAAUACvdRm27aTQoBWtI3fAPXDuVCyUOZgAAEMJy5VKLk5q1G3K2X4atGqjAAWKM/5To3nr4CHnxKJR/uYMv56jDrJbtk/"
		"jBEKSl3DXZBL4OIDWpArZsduVpsZRdO1TuAK7N2qK5R/Zh+qMKN4mEm/1ImaD9KBtI3A/pzc9tc+7hSKezO/T00s7VfOum8ZfCHv1a58R5A4OTuXoFAYgK1HXFEzuUqv+nMg2rQ2FY8YFDiLvj+fyLD7g675w+fg9GMORWL2DY61s3RWFt4S7oduVV1bm2zkrdZTFzYrmdTNhZjvxBe+daQn+sX50rMN+JOdxCzAmJppcb7ohbRR2QFee1IVUuv7HSjgficeSegUPVN4bcd629PvIMT6H91tuiUDW4n/H4DEfWmhV0kcdif4/nF3n2mA7dF5Iy6zx0ZsvB0Ba9fdX68W+lvPhuhUNnyEtLhFm9Qj2mOFVU/SsxImCDvQnUeniHROz1TOcxHepHjbdmKNm30xZn2QiXiY6AZ0l81vtY2GfticR/90g+g+exZJX/+8zmZYrOXUiZo+9ggukOeuVAl4lQXHkKk9IIIVDi+"
		"ptkv7zMaogUzV9X8G6IFRfgSEPvtYIhNBIgOlXIZW+k0VjA9kId4txiIPBsHll2aw2CkQqAtJYDFzL3AQ==&p=\",\"family\":3,\"locale\":\"en-US\",\"osVersion\":\"10.0.26200.7922.ge_release\",\"browser\":{\"internetExplorer\":\"9.11.26100.0\"},\"netJoinStatus\":2,\"enterprise\":{},\"cloudSku\":false,\"architecture\":9},\"caller\":{\"locale\":\"en-US\",\"name\":\"\",\"version\":\"145.0.3800.82 (Official build) \"},\"client\":{\"version\":\"281483731271680\",\"data\":{\"topTraffic\":\"638004170464094982\",\""
		"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-a82cb2897a8bf9445d68dcc2be05af89ad4b2fda1fddb2952693be7cd5353ad3\",\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\"}}},\"config\":{\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}},\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"destination\":{\"uri\":\"https://thinking-tester-contact-list.herokuapp.com/logout\",\"ip\":\""
		"54.146.248.82\"},\"referrer\":{\"uri\":\"https://thinking-tester-contact-list.herokuapp.com/contactList\",\"ip\":\"3.229.186.102\"},\"type\":\"top\",\"forceServiceDetermination\":false,\"correlationId\":\"ddc37175-22c6-4aa2-a784-95a081c158e1\",\"synchronous\":false}", 
		"LAST");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("Origin", 
		"https://thinking-tester-contact-list.herokuapp.com");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("sec-ch-ua", 
		"\"Not:A-Brand\";v=\"99\", \"Microsoft Edge\";v=\"145\", \"Chromium\";v=\"145\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");
	
	 

 
 
 
 
 
 
 
 
 

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("thinking-tester-contact-list.herokuapp.com_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/", 
		"Resource=0", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/logout", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=/img/thinkingTesterLogo.png", "ENDITEM", 
		"Url=/js/login.js", "ENDITEM", 
		"LAST");

	return 0;
}
# 5 "c:\\lr_scripts\\demo_script\\combined_Demo_script.c" 2

# 1 "vuser_end.c" 1
vuser_end()
{
	return 0;
}
# 6 "c:\\lr_scripts\\demo_script\\combined_Demo_script.c" 2

