Action()
{



	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");


	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\"Not:A-Brand\";v=\"99\", \"Microsoft Edge\";v=\"145\", \"Chromium\";v=\"145\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");
	
	lr_start_transaction("S01_DemoScript_T01_Launch");

	web_url("thinking-tester-contact-list.herokuapp.com", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_end_transaction("S01_DemoScript_T01_Launch",LR_AUTO);

	web_revert_auto_header("Sec-Fetch-Dest");

	web_add_header("Sec-Fetch-Dest", 
		"empty");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	lr_think_time(4);

	/* Login */

	web_revert_auto_header("Sec-Fetch-Storage-Access");

	web_add_header("Access-Control-Request-Headers", 
		"apikey,cache-control,client-id,client-version,content-type,time-delta-to-apply-millis,upload-time");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_add_auto_header("Origin", 
		"https://copilot.microsoft.com");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");


	web_add_header("Origin", 
		"https://thinking-tester-contact-list.herokuapp.com");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	lr_think_time(7);
	
	lr_start_transaction("S01_DemoScript_T02_Login");
	
	web_reg_save_param_ex(
		"ParamName=c_Token",
		"LB=\"token\":\"",
		"RB=\"",
		SEARCH_FILTERS,
		LAST);

	web_custom_request("login", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/users/login", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"email\":\"alien@abc.com\",\"password\":\"Alien@13\"}", 
		LAST);
	


	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("contactList", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("sec-ch-ua", 
		"\"Not:A-Brand\";v=\"99\", \"Microsoft Edge\";v=\"145\", \"Chromium\";v=\"145\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");
	
	web_add_header("Authorization", "Bearer {c_Token}");

	web_custom_request("contacts", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);
	
		lr_end_transaction("S01_DemoScript_T02_Login",LR_AUTO);

	/* Click Add new contact */

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(11);
	
		lr_start_transaction("S01_DemoScript_T03_ClickAddContact");

	web_url("addContact", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/addContact", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Mesh-Client-Arch", 
		"x86_64");

	web_add_header("Sec-Mesh-Client-Edge-Channel", 
		"stable");

	web_add_header("Sec-Mesh-Client-Edge-Version", 
		"145.0.3800.82");

	web_add_header("Sec-Mesh-Client-OS", 
		"Windows");

	web_add_header("Sec-Mesh-Client-OS-Version", 
		"10.0.26200");

	web_add_header("Sec-Mesh-Client-WebView", 
		"0");

	lr_end_transaction("S01_DemoScript_T03_ClickAddContact",LR_AUTO);

	/* Submit */

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("Origin", 
		"https://thinking-tester-contact-list.herokuapp.com");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("sec-ch-ua", 
		"\"Not:A-Brand\";v=\"99\", \"Microsoft Edge\";v=\"145\", \"Chromium\";v=\"145\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	lr_think_time(29);
	
	lr_start_transaction("S01_DemoScript_T04_SubmitContact");
	
	web_add_header("Authorization", "Bearer {c_Token}");

	web_custom_request("contacts_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/addContact", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"firstName\":\"Santhosh\",\"lastName\":\"A\",\"phone\":\"9876543210\"}", 
		LAST);
	
	

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("contactList_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Resource=0", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/addContact", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/css/styles.css", ENDITEM, 
		"Url=/img/thinkingTesterLogo.png", ENDITEM, 
		"Url=/js/contactList.js", ENDITEM, 
		"Url=/img/thinkingTesterIcon.png", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");
	
	web_add_header("Authorization", "Bearer {c_Token}");

	web_custom_request("contacts_3", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_end_transaction("S01_DemoScript_T04_SubmitContact",LR_AUTO);

	/* Logout */

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(10);
	
	lr_start_transaction("S01_DemoScript_T05_Logout");

	web_url("logout", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/logout", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_end_transaction("S01_DemoScript_T05_Logout",LR_AUTO);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_custom_request("3_5", 
		"URL=https://nav-edge.smartscreen.microsoft.com/api/browser/edge/navigate/3", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0\",\"redirectChain\":[],\"enhancedRedirectChain\":{\"redirectSource\":null,\"referrerChain\":[]},\"identity\":{\"user\":{\"locale\":\"en-US\"},\"device\":{\"id\":null,\"customId\":\"724e6b55-2db0-48f8-8304-bdd3b1009d3e\",\"onlineIdTicket\":\"t=GwD2Ad9tBAAUACvdRm27aTQoBWtI3fAPXDuVCyUOZgAAEMJy5VKLk5q1G3K2X4atGqjAAWKM/5To3nr4CHnxKJR/uYMv56jDrJbtk/"
		"jBEKSl3DXZBL4OIDWpArZsduVpsZRdO1TuAK7N2qK5R/Zh+qMKN4mEm/1ImaD9KBtI3A/pzc9tc+7hSKezO/T00s7VfOum8ZfCHv1a58R5A4OTuXoFAYgK1HXFEzuUqv+nMg2rQ2FY8YFDiLvj+fyLD7g675w+fg9GMORWL2DY61s3RWFt4S7oduVV1bm2zkrdZTFzYrmdTNhZjvxBe+daQn+sX50rMN+JOdxCzAmJppcb7ohbRR2QFee1IVUuv7HSjgficeSegUPVN4bcd629PvIMT6H91tuiUDW4n/H4DEfWmhV0kcdif4/nF3n2mA7dF5Iy6zx0ZsvB0Ba9fdX68W+lvPhuhUNnyEtLhFm9Qj2mOFVU/SsxImCDvQnUeniHROz1TOcxHepHjbdmKNm30xZn2QiXiY6AZ0l81vtY2GfticR/90g+g+exZJX/+8zmZYrOXUiZo+9ggukOeuVAl4lQXHkKk9IIIVDi+"
		"ptkv7zMaogUzV9X8G6IFRfgSEPvtYIhNBIgOlXIZW+k0VjA9kId4txiIPBsHll2aw2CkQqAtJYDFzL3AQ==&p=\",\"family\":3,\"locale\":\"en-US\",\"osVersion\":\"10.0.26200.7922.ge_release\",\"browser\":{\"internetExplorer\":\"9.11.26100.0\"},\"netJoinStatus\":2,\"enterprise\":{},\"cloudSku\":false,\"architecture\":9},\"caller\":{\"locale\":\"en-US\",\"name\":\"\",\"version\":\"145.0.3800.82 (Official build) \"},\"client\":{\"version\":\"281483731271680\",\"data\":{\"topTraffic\":\"638004170464094982\",\""
		"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-a82cb2897a8bf9445d68dcc2be05af89ad4b2fda1fddb2952693be7cd5353ad3\",\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\"}}},\"config\":{\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}},\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"destination\":{\"uri\":\"https://thinking-tester-contact-list.herokuapp.com/logout\",\"ip\":\""
		"54.146.248.82\"},\"referrer\":{\"uri\":\"https://thinking-tester-contact-list.herokuapp.com/contactList\",\"ip\":\"3.229.186.102\"},\"type\":\"top\",\"forceServiceDetermination\":false,\"correlationId\":\"ddc37175-22c6-4aa2-a784-95a081c158e1\",\"synchronous\":false}", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("Origin", 
		"https://thinking-tester-contact-list.herokuapp.com");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("sec-ch-ua", 
		"\"Not:A-Brand\";v=\"99\", \"Microsoft Edge\";v=\"145\", \"Chromium\";v=\"145\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");
	
	//web_add_header("Authorization", "Bearer {c_Token}");

//	web_custom_request("logout_2", 
//		"URL=https://thinking-tester-contact-list.herokuapp.com/users/logout", 
//		"Method=POST", 
//		"Resource=0", 
//		"Referer=https://thinking-tester-contact-list.herokuapp.com/logout", 
//		"Snapshot=t34.inf", 
//		"Mode=HTML", 
//		"EncType=", 
//		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("thinking-tester-contact-list.herokuapp.com_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/", 
		"Resource=0", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/logout", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/img/thinkingTesterLogo.png", ENDITEM, 
		"Url=/js/login.js", ENDITEM, 
		LAST);

	return 0;
}