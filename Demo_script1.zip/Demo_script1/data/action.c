Action()
{

	web_url("current", 
		"URL=http://edge.microsoft.com/browsernetworktime/time/1/current?cup2key=2:epOdkmfEeCYd0PNk1glVEFscUj1ISC9xwPDUuzQ4a8c&cup2hreq=e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_custom_request("3", 
		"URL=https://nav-edge.smartscreen.microsoft.com/api/browser/edge/navigate/3", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0\",\"redirectChain\":[],\"enhancedRedirectChain\":{\"redirectSource\":null,\"referrerChain\":[]},\"identity\":{\"user\":{\"locale\":\"en-US\"},\"device\":{\"id\":null,\"customId\":\"d6b25121-e554-4bf8-86c0-4bfe3072b794\",\"onlineIdTicket\":\"t=GwD2Ad9tBAAUACvdRm27aTQoBWtI3fAPXDuVCyUOZgAAEMJy5VKLk5q1G3K2X4atGqjAAWKM/5To3nr4CHnxKJR/uYMv56jDrJbtk/"
		"jBEKSl3DXZBL4OIDWpArZsduVpsZRdO1TuAK7N2qK5R/Zh+qMKN4mEm/1ImaD9KBtI3A/pzc9tc+7hSKezO/T00s7VfOum8ZfCHv1a58R5A4OTuXoFAYgK1HXFEzuUqv+nMg2rQ2FY8YFDiLvj+fyLD7g675w+fg9GMORWL2DY61s3RWFt4S7oduVV1bm2zkrdZTFzYrmdTNhZjvxBe+daQn+sX50rMN+JOdxCzAmJppcb7ohbRR2QFee1IVUuv7HSjgficeSegUPVN4bcd629PvIMT6H91tuiUDW4n/H4DEfWmhV0kcdif4/nF3n2mA7dF5Iy6zx0ZsvB0Ba9fdX68W+lvPhuhUNnyEtLhFm9Qj2mOFVU/SsxImCDvQnUeniHROz1TOcxHepHjbdmKNm30xZn2QiXiY6AZ0l81vtY2GfticR/90g+g+exZJX/+8zmZYrOXUiZo+9ggukOeuVAl4lQXHkKk9IIIVDi+"
		"ptkv7zMaogUzV9X8G6IFRfgSEPvtYIhNBIgOlXIZW+k0VjA9kId4txiIPBsHll2aw2CkQqAtJYDFzL3AQ==&p=\",\"family\":3,\"locale\":\"en-US\",\"osVersion\":\"10.0.26200.7922.ge_release\",\"browser\":{\"internetExplorer\":\"9.11.26100.0\"},\"netJoinStatus\":2,\"enterprise\":{},\"cloudSku\":false,\"architecture\":9},\"caller\":{\"locale\":\"en-US\",\"name\":\"\",\"version\":\"145.0.3800.82 (Official build) \"},\"client\":{\"version\":\"281483731271680\",\"data\":{\"topTraffic\":\"638004170464094982\",\""
		"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-a82cb2897a8bf9445d68dcc2be05af89ad4b2fda1fddb2952693be7cd5353ad3\",\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\"}}},\"config\":{\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}},\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"destination\":{\"uri\":\"https://thinking-tester-contact-list.herokuapp.com/\",\"ip\":null},\"type\":\""
		"top\",\"forceServiceDetermination\":false,\"correlationId\":\"856f4f79-5970-4792-bab5-e70fa8e05672\",\"synchronous\":false}", 
		LAST);

	web_add_header("Sec-Fetch-Storage-Access", 
		"inactive");

	lr_think_time(6);

	web_url("shoppingsettings", 
		"URL=https://www.bing.com/api/shopping/v1/user/shoppingsettings", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("3_2", 
		"URL=https://nav-edge.smartscreen.microsoft.com/api/browser/edge/navigate/3", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0\",\"redirectChain\":[],\"enhancedRedirectChain\":{\"redirectSource\":null,\"referrerChain\":[]},\"identity\":{\"user\":{\"locale\":\"en-US\"},\"device\":{\"id\":null,\"customId\":\"05430adb-85e9-4709-90be-af55d0a42051\",\"onlineIdTicket\":\"t=GwD2Ad9tBAAUACvdRm27aTQoBWtI3fAPXDuVCyUOZgAAEMJy5VKLk5q1G3K2X4atGqjAAWKM/5To3nr4CHnxKJR/uYMv56jDrJbtk/"
		"jBEKSl3DXZBL4OIDWpArZsduVpsZRdO1TuAK7N2qK5R/Zh+qMKN4mEm/1ImaD9KBtI3A/pzc9tc+7hSKezO/T00s7VfOum8ZfCHv1a58R5A4OTuXoFAYgK1HXFEzuUqv+nMg2rQ2FY8YFDiLvj+fyLD7g675w+fg9GMORWL2DY61s3RWFt4S7oduVV1bm2zkrdZTFzYrmdTNhZjvxBe+daQn+sX50rMN+JOdxCzAmJppcb7ohbRR2QFee1IVUuv7HSjgficeSegUPVN4bcd629PvIMT6H91tuiUDW4n/H4DEfWmhV0kcdif4/nF3n2mA7dF5Iy6zx0ZsvB0Ba9fdX68W+lvPhuhUNnyEtLhFm9Qj2mOFVU/SsxImCDvQnUeniHROz1TOcxHepHjbdmKNm30xZn2QiXiY6AZ0l81vtY2GfticR/90g+g+exZJX/+8zmZYrOXUiZo+9ggukOeuVAl4lQXHkKk9IIIVDi+"
		"ptkv7zMaogUzV9X8G6IFRfgSEPvtYIhNBIgOlXIZW+k0VjA9kId4txiIPBsHll2aw2CkQqAtJYDFzL3AQ==&p=\",\"family\":3,\"locale\":\"en-US\",\"osVersion\":\"10.0.26200.7922.ge_release\",\"browser\":{\"internetExplorer\":\"9.11.26100.0\"},\"netJoinStatus\":2,\"enterprise\":{},\"cloudSku\":false,\"architecture\":9},\"caller\":{\"locale\":\"en-US\",\"name\":\"\",\"version\":\"145.0.3800.82 (Official build) \"},\"client\":{\"version\":\"281483731271680\",\"data\":{\"topTraffic\":\"638004170464094982\",\""
		"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-a82cb2897a8bf9445d68dcc2be05af89ad4b2fda1fddb2952693be7cd5353ad3\",\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\"}}},\"config\":{\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}},\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"destination\":{\"uri\":\"https://copilot.microsoft.com/?edgetab=1&startpage=1&prerender=1&PC=U531\",\"ip\""
		":\"2606:4700:9c61:4a7b:cdfd:de8:28b5:39a8\"},\"type\":\"frame\",\"forceServiceDetermination\":false,\"correlationId\":\"4ad89b27-1069-4155-b799-d7744508dc5d\",\"synchronous\":false}", 
		LAST);

	web_add_header("Sec-Fetch-Storage-Access", 
		"active");

	web_add_auto_header("Sec-Mesh-Client-Arch", 
		"x86_64");

	web_add_auto_header("Sec-Mesh-Client-Edge-Channel", 
		"stable");

	web_add_auto_header("Sec-Mesh-Client-Edge-Version", 
		"145.0.3800.82");

	web_add_auto_header("Sec-Mesh-Client-OS", 
		"Windows");

	web_add_auto_header("Sec-Mesh-Client-OS-Version", 
		"10.0.26200");

	web_add_auto_header("Sec-Mesh-Client-WebView", 
		"0");

	web_url("blocklist", 
		"URL=https://edge.microsoft.com/abusiveadblocking/api/v1/blocklist", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("X-Client-Data", 
		"eyIxIjoiMCIsIjIiOiIwIiwiMyI6IjAiLCI0IjoiODAyMzg3NDE5ODg1MzA4ODI4NiIsIjYiOiJzdGFibGUiLCI5IjoiZGVza3RvcCJ9");

	web_url("v3", 
		"URL=https://edge.microsoft.com/serviceexperimentation/v3/?osname=win&channel=stable&osver=10.0.26200&devicefamily=desktop&installdate=1703356467&clientversion=145.0.3800.82&experimentationmode=2&scpguard=0&scpfull=0&scpver=0", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Sec-Fetch-Dest");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_revert_auto_header("Sec-Fetch-Site");

	web_revert_auto_header("Sec-Mesh-Client-Arch");

	web_revert_auto_header("Sec-Mesh-Client-Edge-Channel");

	web_revert_auto_header("Sec-Mesh-Client-Edge-Version");

	web_revert_auto_header("Sec-Mesh-Client-OS");

	web_revert_auto_header("Sec-Mesh-Client-OS-Version");

	web_revert_auto_header("Sec-Mesh-Client-WebView");

	web_add_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_add_header("Origin", 
		"https://copilot.microsoft.com");

	web_custom_request("report", 
		"URL=https://aefd.nelreports.net/api/report?cat=bingserp", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\"Not:A-Brand\";v=\"99\", \"Microsoft Edge\";v=\"145\", \"Chromium\";v=\"145\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("thinking-tester-contact-list.herokuapp.com", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Sec-Fetch-Dest");

	web_add_header("Sec-Fetch-Dest", 
		"empty");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	lr_think_time(4);

	web_url("-7800574542027186317", 
		"URL=https://edge.microsoft.com/autofillservice/core/page/8738942224169121609/-7800574542027186317", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Sec-Fetch-Site");

	web_add_header("MSA_DeviceTicket", 
		"t=EwCYA1N5BAAU/RcvkdcJdM8Mg37m2cbcY3tdBbMAAeKeEJCcTiL+jY6V/Tn4XIoGL5iBALg1WJ9RRls3m7Jwaru/R6RBkrpoU6QJxICuVEzXPG7ciX6tXUrksRDpDG0z2t8nPsLeV1uYMtbxx8LXIWqA4iIOsug+DfgbXHhJvyVN76X+21LDRce7zbjyDOZRmb9CIlOVCkrjfEQhDLTVlUrfKFKPaP7e+Ps1w6naGrbfM01LPUV0LbWbDR1FcfXSaZs/PiQpJQcDG+WDUk79Q8nLwCLggCi1r0dhxKqGtFfmg38tATjScyE8637PsbpZHMewtVhvA3vY6FOHwBXUnum74fq6dpH18xVhia88+/gLa2hHG7044fRgpjbRiA0QZgAAEHqDR+E8lNyoJk+MOXd7gGJgAoW8DLodLfS/420TZ2386NWITuysVl1rk20VJ185YNCgUnvNqhIaSCkQTAQ/"
		"NC5nLtkSXh7sjEVKD5ULO8Zn7FqeZpsSYRgjM0jJJqbpbXaWILj8rF/vtZ72GLZv1QS3aGSr8C/TGQgMZHY0Lq+tTGHTXWtVKUsEUpen2Pyfd+oJMp32alty8hYqwNq7vOtrJ8UNgpX5uRdcDragCmOl0KAv3iXKZwwVuoAnmbuPEoZmB0RbLWTRPB7e/HJs9esj1p91+tcaDh56Vin2vk0HqDjIlG/zXMDyFRQgMSc0XPz/TKb25yp6jIdZ4xLQ29NTeE/gvY4crSYqno0BbeXx707cYszj6W8ErmKmIdT99XlnI+itgbLoBopucJrDtvXBIeffUVWYirPZkXgiqBLLo/lJxGB3P6Pqb7RTrW/3OMeo7T5GJnrJUNGoKxmcZepup+QdQjlpxgzGkKcpCoaaMpU4d5cn3Hd8a4NmUhXdrM/g2EB0TtLUDmVj5u/"
		"VIxgDOZgf2oA2alKGbexy0kSVixQha4KOKsJlUmP5HCmQIV5VFGpswRxNxeWd2m/jNBNZl5KCjQy7M2HX8Q1HswVuz4/2Fd6w/tR3UuIQlaQD8wFqlaCBf/XJq8Ei5EkbOMUZ2hwfxJuTJlfIFaq2dqa/3r21NI6TG3mHNc98hGyQ9yq4vmL4/AiVggqScct8PIYUgFxvhfBkvLEDWBkTsIHyCCcMoh3/l2VH6Vpy8ATQ2UdEQZna0q3F5rkTj/QANpI8PyXEYJyLqMNymfqVHXfq1uWkqWlHlJ3noxE9mvwD1QnbkAI=&p=");

	web_custom_request("Telemetry.Request", 
		"URL=https://nw-umwatson.events.data.microsoft.com/Telemetry.Request", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=application/xml", 
		"BodyBinary=n\\x0E\\x00\\x00<?xml version=\"1.0\"?>\n<req ver=\"2\">\n <tlm>\n  <src>\n   <desc>\n    <mach>\n     <os>\n      <arg nm=\"vermaj\" val=\"10\"/>\n      <arg nm=\"vermin\" val=\"0\"/>\n      <arg nm=\"verbld\" val=\"26200\"/>\n      <arg nm=\"vercsdbld\" val=\"7922\"/>\n      <arg nm=\"verqfe\" val=\"7922\"/>\n      <arg nm=\"csdbld\" val=\"7922\"/>\n      <arg nm=\"versp\" val=\"\"/>\n      <arg nm=\"arch\" val=\"9\"/>\n      <arg nm=\"lcid\" val=\"1033\"/>\n      <arg nm=\"geoid\" "
		"val=\"113\"/>\n      <arg nm=\"sku\" val=\"101\"/>\n      <arg nm=\"domain\" val=\"0\"/>\n      <arg nm=\"portos\" val=\"0\"/>\n      <arg nm=\"ram\" val=\"16067\"/>\n      <arg nm=\"svolsz\" val=\"475\"/>\n      <arg nm=\"wimbt\" val=\"0\"/>\n      <arg nm=\"blddt\" val=\"240331\"/>\n      <arg nm=\"bldtm\" val=\"1435\"/>\n      <arg nm=\"bldbrch\" val=\"ge_release\"/>\n      <arg nm=\"os\" val=\"Windows\"/>\n      <arg nm=\"osver\" val=\"10.0.26100.7922.amd64fre.ge_release.240331-1435\"/>\n     "
		" <arg nm=\"buildflightid\" val=\"0DA0EA0F-443C-4E74-AA7D-8508B13ABDF0.1\"/>\n      <arg nm=\"expid\" val=\"RS:31D30,FX:124117A5,FX:12ECE1E8,FX:12F282DF,FX:12F2E40E,FX:12F322BC,FX:12FF4FDD,FX:1304E767,FX:1304EA0D,FX:13083122,FX:130BC36D,FX:130DD09D,FX:1312825F,FX:1312D799,FX:1318CA30,FX:1318CAEE,FX:1318CAEF,FX:1318CBED,FX:1318CBF1,FX:132134BD,FX:132CC730,FX:132EB35F,FX:132EB493,FX:133BD388,FX:134130B4,FX:1341E6FC,FX:13430B2D,FX:13438\"/>\n      <arg nm=\"edition\" val=\"Core\"/>\n     </os>\n     "
		"<hw>\n      <arg nm=\"form\" val=\"2\"/>\n      <arg nm=\"arch\" val=\"9\"/>\n      <arg nm=\"deviceclass\" val=\"Windows.Desktop\"/>\n      <arg nm=\"sysmfg\" val=\"LENOVO\"/>\n      <arg nm=\"syspro\" val=\"21E4S49N00\"/>\n      <arg nm=\"bv\" val=\"R1SET49W(1.20)\"/>\n      <arg nm=\"ram\" val=\"16384\"/>\n      <arg nm=\"proccnt\" val=\"12\"/>\n      <arg nm=\"proclsp\" val=\"2496\"/>\n      <arg nm=\"wscpusc\" val=\"0\"/>\n      <arg nm=\"wsdsksc\" val=\"0\"/>\n      <arg nm=\"wscpudn\" val="
		"\"12th Gen Intel(R) Core(TM) i5-1235U\"/>\n      <arg nm=\"wsdgsc\" val=\"0\"/>\n      <arg nm=\"aoac\" val=\"1\"/>\n      <arg nm=\"bssku\" val=\"LENOVO_MT_21E4_BU_Think_FM_ThinkPad E14 Gen 4\"/>\n      <arg nm=\"chid\" val=\"{708919ce-f613-5f6f-9c98-9362845c6683}\"/>\n      <arg nm=\"sdksz\" val=\"476\"/>\n     </hw>\n     <ctrl>\n      <arg nm=\"tm\" val=\"0\"/>\n      <arg nm=\"mid\" val=\"16E66AB8-01C1-4FBC-9ACE-EA314E129134\"/>\n      <arg nm=\"sample\" val=\"73349199\"/>\n      <arg nm=\""
		"msft\" val=\"0\"/>\n      <arg nm=\"test\" val=\"0\"/>\n      <arg nm=\"scf\" val=\"0\"/>\n      <arg nm=\"commercialid\" val=\"\"/>\n      <arg nm=\"telemetry\" val=\"Disabled\"/>\n     </ctrl>\n    </mach>\n   </desc>\n  </src>\n  <reqs>\n   <req key=\"1\">\n    <namespace svc=\"watson\" ptr=\"generic\" gp=\"generic\" app=\"msedge.exe\">\n     <arg nm=\"p1\" val=\"msedge.exe\"/>\n     <arg nm=\"p2\" val=\"145.0.3800.82\"/>\n     <arg nm=\"p3\" val=\"underside_chat_v2\"/>\n     <arg nm=\"p4\" val"
		"=\"964E3B97FF7F0B7CE998E70185D1AB39DDF7F38F\"/>\n     <arg nm=\"p5\" val=\"ReferenceError\"/>\n     <arg nm=\"p6\" val=\"Unknown\"/>\n     <arg nm=\"p7\" val=\"0_0\"/>\n    </namespace>\n    <ctrl>\n     <arg nm=\"reportid\" val=\"9a8fbe1d-8bb7-414c-b3a0-2332b3c07250\"/>\n     <arg nm=\"procmeta.Channel\" val=\"none\"/>\n     <arg nm=\"procmeta.MetricsClientId\" val=\"fe7a72b0-b433-43dc-becb-dde01f9a7708\"/>\n     <arg nm=\"procmeta.MetricsClientIdHash\" val=\"8023874198853088286\"/>\n     <arg nm"
		"=\"procmeta.MetricsSessionId\" val=\"1700\"/>\n     <arg nm=\"procmeta.OfficialBuild\" val=\"1\"/>\n    </ctrl>\n    <cmd nm=\"event\">\n     <arg nm=\"eventtype\" val=\"crashpad_jserror\"/>\n     <arg nm=\"cat\" val=\"generic\"/>\n     <arg nm=\"p1\" val=\"msedge.exe\"/>\n     <arg nm=\"p2\" val=\"145.0.3800.82\"/>\n     <arg nm=\"p3\" val=\"underside_chat_v2\"/>\n     <arg nm=\"p4\" val=\"964E3B97FF7F0B7CE998E70185D1AB39DDF7F38F\"/>\n     <arg nm=\"p5\" val=\"ReferenceError\"/>\n     <arg nm=\""
		"p6\" val=\"Unknown\"/>\n     <arg nm=\"p7\" val=\"0_0\"/>\n    </cmd>\n   </req>\n  </reqs>\n </tlm>\n</req>\n", 
		LAST);

	web_add_header("MS-CV", 
		"XuHp2EPKEO6vYylbES6mxL");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Mesh-Client-Arch", 
		"x86_64");

	web_add_header("Sec-Mesh-Client-Edge-Channel", 
		"stable");

	web_add_header("Sec-Mesh-Client-Edge-Version", 
		"145.0.3800.82");

	web_add_header("Sec-Mesh-Client-OS", 
		"Windows");

	web_add_header("Sec-Mesh-Client-OS-Version", 
		"10.0.26200");

	web_add_header("Sec-Mesh-Client-WebView", 
		"0");

	web_add_header("X-Client-Data", 
		"CPOCywE=");

	web_add_header("X-Microsoft-Update-AppId", 
		"jmjflgjpcpepeafmmgdpfkogkghcpiha");

	web_add_header("X-Microsoft-Update-Interactivity", 
		"bg");

	web_add_header("X-Microsoft-Update-Service-Cohort", 
		"6894");

	web_add_header("X-Microsoft-Update-Updater", 
		"msedgecrx-145.0.3800.82");

	web_custom_request("crx", 
		"URL=https://edge.microsoft.com/extensionwebstorebase/v1/crx", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"msedgecrx\",\"acceptformat\":\"crx3,download,run,xz,zucc\",\"apps\":[{\"appid\":\"jmjflgjpcpepeafmmgdpfkogkghcpiha\",\"cohort\":\"rrf@0.99\",\"enabled\":true,\"installdate\":6826,\"installedby\":\"other\",\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{b3314c9d-86d6-4bd1-bcb3-bc2233c6a6d0}\",\"rd\":7004},\"targetingattributes\":{\"AppCohort\":\"rrf@0.99\",\"AppMajorVersion\":\"145\",\"AppRollout\":0.99,\"AppVersion\":\"145.0.3800.82\",\""
		"IsInternalUser\":false,\"Priority\":false},\"updatecheck\":{},\"version\":\"1.2.1\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":1,\"physmemory\":16,\"sse\":1,\"sse2\":1,\"sse3\":1,\"sse41\":1,\"sse42\":1,\"ssse3\":1},\"ismachine\":1,\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.26200.7922\"},\"prodversion\":\"145.0.3800.82\",\"protocol\":\"4.0\",\"requestid\":\"{a80d1cea-89f5-4f74-a98e-c413ef5953b9}\",\"revocationviaomahaenabled\":\"0\",\""
		"sessionid\":\"{58daf5f8-7d66-4ba3-8f46-ec94881ebd60}\",\"updaterversion\":\"145.0.3800.82\"}}", 
		LAST);

	web_add_auto_header("Sec-Fetch-Storage-Access", 
		"active");

	web_url("config.json", 
		"URL=https://edge-consumer-static.azureedge.net/mouse-gesture/config.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("MUID=10A391F8389F600B197A879A3909617B; DOMAIN=c.bing.com");

	web_add_cookie("SRM_B=10A391F8389F600B197A879A3909617B; DOMAIN=c.bing.com");

	web_add_cookie("SRM_M=10A391F8389F600B197A879A3909617B; DOMAIN=c.bing.com");

	web_add_cookie("SRCHD=AF=ANSPA1; DOMAIN=c.bing.com");

	web_add_cookie("SRCHUID=V=2&GUID=FFBC3E1D3B2846B0870E2084DE6B03D1&dmnchg=1; DOMAIN=c.bing.com");

	web_add_cookie("ANON=A=35B3412ACFB4B4F7C8875C81FFFFFFFF; DOMAIN=c.bing.com");

	web_add_cookie("USRLOC=HS=1&ELOC=LAT=13.129558563232422|LON=80.1533203125|N=Ambattur%2C%20Tamil%20Nadu|ELT=2|&CLOC=LAT=13.132892016170649|LON=80.15887664986349|A=733.4464586120832|TS=260306052617|SRC=W&BID=MjYwMzA2MTA1NjE3XzlkNDZhOGQxNmI4OGM1MzY2ZDY3MGE4ZGMyNTczMGY0ZWQ5YjZiZDcwMTNiNjVhMjkxMmU0NGJmYTVkODhkMjM=; DOMAIN=c.bing.com");

	web_add_cookie("_RwBf=r=0&ilt=53&ihpd=0&ispd=1&rc=9&rb=9&rg=0&pc=9&mtu=0&rbb=0.0&clo=0&v=1&l=2026-03-02T08:00:00.0000000Z&lft=0001-01-01T00:00:00.0000000&aof=0&ard=0001-01-01T00:00:00.0000000&rwdbt=-62135539200&rwflt=-62135539200&rwaul2=0&g=newLevel1&o=0&p=MSAAUTOENROLL&c=MR000T&t=2626&s=2025-12-31T04:56:50.3107623+00:00&ts=2026-03-02T10:18:38.2209698+00:00&rwred=0&wls=2&wlb=0&wle=0&ccp=2&cpt=0&lka=0&lkt=0&aad=0&TH=&cid=0&gb=2026w1_u&mta=0&e="
		"udvppeTG57Ox9XAPHdH8D4josUSSzXT_mUmgHWsQDJtqZt9VzWc86p9NGVsfJ8XM3DA-gASBF8TatubypNL7Tw; DOMAIN=c.bing.com");

	web_add_cookie("SRCHHPGUSR=SRCHLANG=en&IG=12952EFC67D14640BE45012492376599&PV=19.0.0&PREFCOL=1&BRW=N&BRH=S&CW=1272&CH=588&SCW=1257&SCH=3614&DPR=1.5&UTC=330&B=0&EXLTT=31&HV=1772446718&HVE=CfDJ8HAK7eZCYw5BifHFeUHnkJEXFOIrk8W3MDyszoYd0l3GQLMhY7ihnBE6vesDjwjjmD9w8qGQcUypuA9VuQ6bZKU6wrs-KNR3VRjdoPY8iwpuc9WTYcqJttT_PBvpdUwvCwWOLcn1wUkZCm9xLU7yAJhIoFN2xmbAkw9JymM2H8hqhO6d_h-7Dt2xowfXYebZJw&PRVCW=1272&PRVCH=588&AV=14&ADV=14&RB=0&MB=0; DOMAIN=c.bing.com");

	web_add_cookie("SRCHUSR=DOB=20250909&DS=1; DOMAIN=c.bing.com");

	web_add_cookie("MR=0; DOMAIN=c.bing.com");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_add_header("Sec-MS-GEC", 
		"154ACE178548BC62-556F3A387C182E55C05666F1C7594A69B01E7CCBF33C4E5128447715F7BA2AA6");

	web_add_header("Sec-MS-GEC-Version", 
		"2-145.0.3800.82");

	web_add_header("X-Client-Data", 
		"eyIxIjoiMCIsIjIiOiIwIiwiMyI6IjAiLCI0IjoiODAyMzg3NDE5ODg1MzA4ODI4NiIsIjYiOiJzdGFibGUiLCI5IjoiZGVza3RvcCJ9");

	web_add_header("X-Edge-Shopping-Flag", 
		"0");

	web_add_header("sec-ch-ua", 
		"\"Not:A-Brand\";v=\"99\", \"Microsoft Edge\";v=\"145\", \"Chromium\";v=\"145\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("cp", 
		"URL=https://c.bing.com/cp?cpid=3VGqNUdUrjXr2j34tQeir&cvid=vXq2PhARMGqYLvjWoYwWG&ps=1", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://copilot.microsoft.com/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	/* Login */

	web_revert_auto_header("Sec-Fetch-Storage-Access");

	web_add_header("Access-Control-Request-Headers", 
		"apikey,cache-control,client-id,client-version,content-type,time-delta-to-apply-millis,upload-time");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_add_auto_header("Origin", 
		"https://copilot.microsoft.com");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_custom_request("1.0", 
		"URL=https://browser.events.data.microsoft.com/OneCollector/1.0/?cors=true&content-type=application/x-json-stream&w=0", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=https://copilot.microsoft.com/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("MC1=GUID=a93052efe70543639b3c02c27df361d1&HASH=a930&LV=202509&V=4&LU=1757566661297; DOMAIN=browser.events.data.microsoft.com");

	web_add_cookie("_clck=1xdquuj%5E2%5Eg3m%5E1%5E2105; DOMAIN=browser.events.data.microsoft.com");

	web_add_cookie("MS0=448a8147f9a94afeb429e36205db9ce8; DOMAIN=browser.events.data.microsoft.com");

	web_add_cookie("_uetsid=00f85020191d11f185b7012482e6ebac; DOMAIN=browser.events.data.microsoft.com");

	web_add_cookie("_uetvid=d1ca04f08ecb11f0894e919b5864edfb; DOMAIN=browser.events.data.microsoft.com");

	web_add_header("upload-time", 
		"1772781798473");

	web_add_header("time-delta-to-apply-millis", 
		"use-collector-delta");

	web_add_auto_header("Client-Id", 
		"NO_AUTH");

	web_add_auto_header("Sec-Fetch-Storage-Access", 
		"active");

	web_add_auto_header("X-Edge-Shopping-Flag", 
		"0");

	web_add_auto_header("apikey", 
		"be6e4c19699f4fdf9f8c0ec9f9b398ef-25d58bb9-9926-4df7-8e36-bc7afb4b2c34-7563");

	web_add_auto_header("client-version", 
		"1DS-Web-JS-4.3.3");

	web_add_auto_header("sec-ch-ua", 
		"\"Not:A-Brand\";v=\"99\", \"Microsoft Edge\";v=\"145\", \"Chromium\";v=\"145\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("1.0_2", 
		"URL=https://browser.events.data.microsoft.com/OneCollector/1.0/?cors=true&content-type=application/x-json-stream&w=0", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://copilot.microsoft.com/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=application/x-json-stream", 
		body_variable_1, 
		LAST);

	web_add_header("time-delta-to-apply-millis", 
		"10481");

	web_add_header("upload-time", 
		"1772781811215");

	web_custom_request("1.0_3", 
		"URL=https://browser.events.data.microsoft.com/OneCollector/1.0/?cors=true&content-type=application/x-json-stream&w=0", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://copilot.microsoft.com/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=application/x-json-stream", 
		body_variable_2, 
		LAST);

	web_revert_auto_header("Client-Id");

	web_revert_auto_header("Sec-Fetch-Storage-Access");

	web_revert_auto_header("X-Edge-Shopping-Flag");

	web_revert_auto_header("apikey");

	web_revert_auto_header("client-version");

	web_revert_auto_header("Origin");

	web_add_header("Origin", 
		"https://thinking-tester-contact-list.herokuapp.com");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	lr_think_time(7);

	web_custom_request("login", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/users/login", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"email\":\"alien@abc.com\",\"password\":\"Alien@13\"}", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("contactList", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_custom_request("3_3", 
		"URL=https://nav-edge.smartscreen.microsoft.com/api/browser/edge/navigate/3", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0\",\"redirectChain\":[],\"enhancedRedirectChain\":{\"redirectSource\":null,\"referrerChain\":[]},\"identity\":{\"user\":{\"locale\":\"en-US\"},\"device\":{\"id\":null,\"customId\":\"6d7ba064-df06-4f82-b790-8feed203cfd5\",\"onlineIdTicket\":\"t=GwD2Ad9tBAAUACvdRm27aTQoBWtI3fAPXDuVCyUOZgAAEMJy5VKLk5q1G3K2X4atGqjAAWKM/5To3nr4CHnxKJR/uYMv56jDrJbtk/"
		"jBEKSl3DXZBL4OIDWpArZsduVpsZRdO1TuAK7N2qK5R/Zh+qMKN4mEm/1ImaD9KBtI3A/pzc9tc+7hSKezO/T00s7VfOum8ZfCHv1a58R5A4OTuXoFAYgK1HXFEzuUqv+nMg2rQ2FY8YFDiLvj+fyLD7g675w+fg9GMORWL2DY61s3RWFt4S7oduVV1bm2zkrdZTFzYrmdTNhZjvxBe+daQn+sX50rMN+JOdxCzAmJppcb7ohbRR2QFee1IVUuv7HSjgficeSegUPVN4bcd629PvIMT6H91tuiUDW4n/H4DEfWmhV0kcdif4/nF3n2mA7dF5Iy6zx0ZsvB0Ba9fdX68W+lvPhuhUNnyEtLhFm9Qj2mOFVU/SsxImCDvQnUeniHROz1TOcxHepHjbdmKNm30xZn2QiXiY6AZ0l81vtY2GfticR/90g+g+exZJX/+8zmZYrOXUiZo+9ggukOeuVAl4lQXHkKk9IIIVDi+"
		"ptkv7zMaogUzV9X8G6IFRfgSEPvtYIhNBIgOlXIZW+k0VjA9kId4txiIPBsHll2aw2CkQqAtJYDFzL3AQ==&p=\",\"family\":3,\"locale\":\"en-US\",\"osVersion\":\"10.0.26200.7922.ge_release\",\"browser\":{\"internetExplorer\":\"9.11.26100.0\"},\"netJoinStatus\":2,\"enterprise\":{},\"cloudSku\":false,\"architecture\":9},\"caller\":{\"locale\":\"en-US\",\"name\":\"\",\"version\":\"145.0.3800.82 (Official build) \"},\"client\":{\"version\":\"281483731271680\",\"data\":{\"topTraffic\":\"638004170464094982\",\""
		"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-a82cb2897a8bf9445d68dcc2be05af89ad4b2fda1fddb2952693be7cd5353ad3\",\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\"}}},\"config\":{\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}},\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"destination\":{\"uri\":\"https://thinking-tester-contact-list.herokuapp.com/contactList\",\"ip\":\""
		"54.146.248.82\"},\"referrer\":{\"uri\":\"https://thinking-tester-contact-list.herokuapp.com/\",\"ip\":\"3.229.186.102\"},\"type\":\"top\",\"forceServiceDetermination\":false,\"correlationId\":\"f6bbb5ae-e8c0-45f5-ae2a-f14b19306cd0\",\"synchronous\":false}", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("sec-ch-ua", 
		"\"Not:A-Brand\";v=\"99\", \"Microsoft Edge\";v=\"145\", \"Chromium\";v=\"145\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("contacts", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		LAST);

	/* Click Add new contact */

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(11);

	web_url("addContact", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/addContact", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_custom_request("3_4", 
		"URL=https://nav-edge.smartscreen.microsoft.com/api/browser/edge/navigate/3", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0\",\"redirectChain\":[],\"enhancedRedirectChain\":{\"redirectSource\":null,\"referrerChain\":[]},\"identity\":{\"user\":{\"locale\":\"en-US\"},\"device\":{\"id\":null,\"customId\":\"6c981eb5-8645-4cb7-b432-90bf6d61c859\",\"onlineIdTicket\":\"t=GwD2Ad9tBAAUACvdRm27aTQoBWtI3fAPXDuVCyUOZgAAEMJy5VKLk5q1G3K2X4atGqjAAWKM/5To3nr4CHnxKJR/uYMv56jDrJbtk/"
		"jBEKSl3DXZBL4OIDWpArZsduVpsZRdO1TuAK7N2qK5R/Zh+qMKN4mEm/1ImaD9KBtI3A/pzc9tc+7hSKezO/T00s7VfOum8ZfCHv1a58R5A4OTuXoFAYgK1HXFEzuUqv+nMg2rQ2FY8YFDiLvj+fyLD7g675w+fg9GMORWL2DY61s3RWFt4S7oduVV1bm2zkrdZTFzYrmdTNhZjvxBe+daQn+sX50rMN+JOdxCzAmJppcb7ohbRR2QFee1IVUuv7HSjgficeSegUPVN4bcd629PvIMT6H91tuiUDW4n/H4DEfWmhV0kcdif4/nF3n2mA7dF5Iy6zx0ZsvB0Ba9fdX68W+lvPhuhUNnyEtLhFm9Qj2mOFVU/SsxImCDvQnUeniHROz1TOcxHepHjbdmKNm30xZn2QiXiY6AZ0l81vtY2GfticR/90g+g+exZJX/+8zmZYrOXUiZo+9ggukOeuVAl4lQXHkKk9IIIVDi+"
		"ptkv7zMaogUzV9X8G6IFRfgSEPvtYIhNBIgOlXIZW+k0VjA9kId4txiIPBsHll2aw2CkQqAtJYDFzL3AQ==&p=\",\"family\":3,\"locale\":\"en-US\",\"osVersion\":\"10.0.26200.7922.ge_release\",\"browser\":{\"internetExplorer\":\"9.11.26100.0\"},\"netJoinStatus\":2,\"enterprise\":{},\"cloudSku\":false,\"architecture\":9},\"caller\":{\"locale\":\"en-US\",\"name\":\"\",\"version\":\"145.0.3800.82 (Official build) \"},\"client\":{\"version\":\"281483731271680\",\"data\":{\"topTraffic\":\"638004170464094982\",\""
		"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-a82cb2897a8bf9445d68dcc2be05af89ad4b2fda1fddb2952693be7cd5353ad3\",\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\"}}},\"config\":{\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}},\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"destination\":{\"uri\":\"https://thinking-tester-contact-list.herokuapp.com/addContact\",\"ip\":\""
		"3.229.186.102\"},\"referrer\":{\"uri\":\"https://thinking-tester-contact-list.herokuapp.com/contactList\",\"ip\":\"3.210.192.5\"},\"type\":\"top\",\"forceServiceDetermination\":false,\"correlationId\":\"56747ba2-f7b9-4365-971d-22a29f238605\",\"synchronous\":false}", 
		LAST);

	web_url("8539447273333016300", 
		"URL=https://edge.microsoft.com/autofillservice/core/page/8738942224169121609/8539447273333016300", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Sec-Mesh-Client-Arch", 
		"x86_64");

	web_add_header("Sec-Mesh-Client-Edge-Channel", 
		"stable");

	web_add_header("Sec-Mesh-Client-Edge-Version", 
		"145.0.3800.82");

	web_add_header("Sec-Mesh-Client-OS", 
		"Windows");

	web_add_header("Sec-Mesh-Client-OS-Version", 
		"10.0.26200");

	web_add_header("Sec-Mesh-Client-WebView", 
		"0");

	web_add_header("X-Microsoft-Update-AppId", 
		"oankkpibpaokgecfckkdkgaoafllipag,pghocgajpebopihickglahgebcmkcekh,eeobbhfgfagbclfofmgbdfoicabjdbkn,kpfehajjjbbcifeehjgfgnabifknmdad,ndikpojcjlepofdkaaldkinkjbeeebkl,laoigpblnllgcgjnjnllmfolckpjlhki,fppmbhmldokgmleojlplaaodlkibgikh,fgbafbciocncjfbbonhocjaohoknlaco,ojblfafjmiikbkepnnolpgbbhejhlcim,efniojlnjndmcbiieegkicadnoecjjef,jbfaflocpnkhbgcijpkiafdpbjkedane,ahmaebgpfccdhgidjaidaoojjcijckba,mpicjakjneaggahlnmbojhjpnileolnb,gllimckfbolmioaaihpppacjccghejen,kmkacjgmmfchkbeglfbjjeidfckbnkca,"
		"plbmmhnabegcabfbcejohgjpkamkddhn,fmbfidpnnknmblionmcahabilfoageoe,ohckeflnhegojcjlcpbfpciadgikcohk,llmidpclgepbgbgoecnhcmgfhmfplfao,kieecehchjjaaepgajdhcehijkehdenm,jpinkpebmplndiafioikiciobeafamld,mkcgfaeepibomfapiapjaceihcojnphg,jcmcegpcehdchljeldgmmfbgcpnmgedo,lkkdlcloifjinapabfonaibjijloebfb,lfmeghnikdkbonehgjihjebgioakijgn,pbdgbpmpeenomngainidcjmopnklimmf,hjaimielcgmceiphgjjfddlgjklfpdei,cllppcmmlnkggcmljjfigkcigaajjmid,pdfjdcjjjegpclfiilihfkmdfndkneei");

	web_add_header("X-Microsoft-Update-Interactivity", 
		"bg");

	web_add_header("X-Microsoft-Update-Service-Cohort", 
		"3137");

	web_add_header("X-Microsoft-Update-Updater", 
		"msedge-145.0.3800.82");

	web_custom_request("update", 
		"URL=https://edge.microsoft.com/componentupdater/api/v1/update?cup2key=7:KDjMqhbLWtsCyFkox3J4MTGIF0hi3xhcLksK8u05RO0&cup2hreq=6aaaded53e3e62e24053f9e3e029ef040f54895c79e1fb8bd8890f04d5dd7bed", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"msedge\",\"acceptformat\":\"crx3,download,run,xz,zucc\",\"apps\":[{\"appid\":\"oankkpibpaokgecfckkdkgaoafllipag\",\"brand\":\"INBX\",\"cached_items\":[{\"sha256\":\"fa29a6d5775ff340900a65b39b02fc8b4b77d403c048d8debf22f2f5d09c61a0\"}],\"cohort\":\"rrf@0.09\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.09\",\"AppMajorVersion\":\"145\",\"AppRollout\":0.09,\"AppVersion\":\""
		"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"6498.2025.9.4\"},{\"appid\":\"pghocgajpebopihickglahgebcmkcekh\",\"brand\":\"INBX\",\"cached_items\":[{\"sha256\":\"89f43cb3df807293de2772d5f01ac2fc1482b38ccc8fdaee859b80642b7a0487\"}],\"cohort\":\"rrf@0.25\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.25\",\""
		"AppMajorVersion\":\"145\",\"AppRollout\":0.25,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"3.0.0.16\"},{\"appid\":\"eeobbhfgfagbclfofmgbdfoicabjdbkn\",\"brand\":\"INBX\",\"cached_items\":[{\"sha256\":\"000ac7dc9366969db9d1e41810a3a27c747a7623535d856eecc2de86cfed80c7\"}],\"cohort\":\"rrf@0.51\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\""
		"targetingattributes\":{\"AppCohort\":\"rrf@0.51\",\"AppMajorVersion\":\"145\",\"AppRollout\":0.51,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"1.0.0.10\"},{\"appid\":\"kpfehajjjbbcifeehjgfgnabifknmdad\",\"brand\":\"INBX\",\"cohort\":\"rrf@0.20\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.20\",\""
		"AppMajorVersion\":\"145\",\"AppRollout\":0.2,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"120.0.6050.0\"},{\"appid\":\"ndikpojcjlepofdkaaldkinkjbeeebkl\",\"brand\":\"INBX\",\"cached_items\":[{\"sha256\":\"bcb93cba8636743d1fbd32be3bd8ce8ff602323895bf4d136c26b9bc64b0a6a4\"}],\"cohort\":\"rrf@0.92\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\""
		"targetingattributes\":{\"AppCohort\":\"rrf@0.92\",\"AppMajorVersion\":\"145\",\"AppRollout\":0.92,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"10.34.0.81\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"INBX\",\"cohort\":\"rrf@0.77\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.77\",\""
		"AppMajorVersion\":\"145\",\"AppRollout\":0.77,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"1.0.7.1652906823\"},{\"appid\":\"fppmbhmldokgmleojlplaaodlkibgikh\",\"brand\":\"INBX\",\"cohort\":\"rrf@0.35\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.35\",\"AppMajorVersion\":\"145\",\"AppRollout\":0.35,\""
		"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"1.15.0.1\"},{\"appid\":\"fgbafbciocncjfbbonhocjaohoknlaco\",\"brand\":\"INBX\",\"cached_items\":[{\"sha256\":\"6dbbf6ec975f97a56ea8ce5c81dab302db6740c89c8ddbf5774728bffaedd238\"}],\"cohort\":\"rrf@0.99\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.99\",\""
		"AppMajorVersion\":\"145\",\"AppRollout\":0.99,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"2026.2.25.1\"},{\"appid\":\"ojblfafjmiikbkepnnolpgbbhejhlcim\",\"brand\":\"INBX\",\"cached_items\":[{\"sha256\":\"2d2f683649600db91050fb41cd9ffea403ae024de38a0647b18e7f6106f6c55d\"}],\"cohort\":\"rrf@0.87\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\""
		"targetingattributes\":{\"AppCohort\":\"rrf@0.87\",\"AppMajorVersion\":\"145\",\"AppRollout\":0.87,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"4.10.2934.0\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"INBX\",\"cohort\":\"rrf@0.33\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.33\",\""
		"AppMajorVersion\":\"145\",\"AppRollout\":0.33,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"28.0.0.1\"},{\"appid\":\"jbfaflocpnkhbgcijpkiafdpbjkedane\",\"brand\":\"INBX\",\"cached_items\":[{\"sha256\":\"68f081c49007522ff83daeee4add34836f1ec4f3b187f4f7419665f08525e588\"}],\"cohort\":\"rrf@0.43\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\""
		"targetingattributes\":{\"AppCohort\":\"rrf@0.43\",\"AppMajorVersion\":\"145\",\"AppRollout\":0.43,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"1.0.0.36\"},{\"appid\":\"ahmaebgpfccdhgidjaidaoojjcijckba\",\"brand\":\"INBX\",\"cached_items\":[{\"sha256\":\"07e0ad6da3d30a27962c6e09da9798ba1745856eaad71a036e2f639e93ea0b27\"}],\"cohort\":\"rrf@0.29\",\"enabled\":true,\"installdate\""
		":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.29\",\"AppMajorVersion\":\"145\",\"AppRollout\":0.29,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"3.2.0.0\"},{\"appid\":\"mpicjakjneaggahlnmbojhjpnileolnb\",\"brand\":\"INBX\",\"cached_items\":[{\"sha256\":\"96b9640eef0668f4d266932438731ee473f9c1186e1c64440512025567be62b7\"}],\"cohort\":\""
		"rrf@0.58\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.58\",\"AppMajorVersion\":\"145\",\"AppRollout\":0.58,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"4.0.1.32\"},{\"appid\":\"gllimckfbolmioaaihpppacjccghejen\",\"brand\":\"INBX\",\"cohort\":\"rrf@0.24\",\"enabled\":true,\"installdate\":-1,\"lang\":"
		"\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.24\",\"AppMajorVersion\":\"145\",\"AppRollout\":0.24,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"1.2.0.0\"},{\"appid\":\"kmkacjgmmfchkbeglfbjjeidfckbnkca\",\"brand\":\"INBX\",\"cohort\":\"rrf@0.68\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\""
		"AppCohort\":\"rrf@0.68\",\"AppMajorVersion\":\"145\",\"AppRollout\":0.68,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"2.0.0.0\"},{\"appid\":\"plbmmhnabegcabfbcejohgjpkamkddhn\",\"brand\":\"INBX\",\"cohort\":\"rrf@0.97\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.97\",\"AppMajorVersion\":\"145\",\""
		"AppRollout\":0.97,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"3057\"},{\"appid\":\"fmbfidpnnknmblionmcahabilfoageoe\",\"brand\":\"INBX\",\"cached_items\":[{\"sha256\":\"5a8a5a5d1f948d724847c005c9875507c34e5b76e73192fc1f2d22605fd69bd7\"}],\"cohort\":\"rrf@0.57\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\""
		"rrf@0.57\",\"AppMajorVersion\":\"145\",\"AppRollout\":0.57,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"2026.2.23.1\"},{\"appid\":\"ohckeflnhegojcjlcpbfpciadgikcohk\",\"brand\":\"INBX\",\"cohort\":\"rrf@0.23\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.23\",\"AppMajorVersion\":\"145\",\"AppRollout\""
		":0.23,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"0.0.1.7\"},{\"appid\":\"llmidpclgepbgbgoecnhcmgfhmfplfao\",\"brand\":\"INBX\",\"cached_items\":[{\"sha256\":\"96a0a03e5994ee19b2a4b6f418b4b7795ad112f7045cde6fe80475475bd69022\"}],\"cohort\":\"rrf@0.95\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.95\""
		",\"AppMajorVersion\":\"145\",\"AppRollout\":0.95,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"2.1.98.0\"},{\"appid\":\"kieecehchjjaaepgajdhcehijkehdenm\",\"brand\":\"INBX\",\"cached_items\":[{\"sha256\":\"e87904d22abb47e87e180e326e5b2023feaabf4847d31e70c13211430da011a3\"}],\"cohort\":\"rrf@0.01\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\""
		"targetingattributes\":{\"AppCohort\":\"rrf@0.01\",\"AppMajorVersion\":\"145\",\"AppRollout\":0.01,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"2026.1.27.2\"},{\"appid\":\"jpinkpebmplndiafioikiciobeafamld\",\"brand\":\"INBX\",\"cached_items\":[{\"sha256\":\"f081de18a604e95a175eaf4dd91b35b7f17ad4de24ee2f20eeb034c979bbcccb\"}],\"cohort\":\"rrf@0.31\",\"enabled\":true,\""
		"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.31\",\"AppMajorVersion\":\"145\",\"AppRollout\":0.31,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"2025.10.7.5\"},{\"appid\":\"mkcgfaeepibomfapiapjaceihcojnphg\",\"brand\":\"INBX\",\"cohort\":\"rrf@0.50\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2"
		"},\"targetingattributes\":{\"AppCohort\":\"rrf@0.50\",\"AppMajorVersion\":\"145\",\"AppRollout\":0.5,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"jcmcegpcehdchljeldgmmfbgcpnmgedo\",\"brand\":\"INBX\",\"cached_items\":[{\"sha256\":\"9a506c9252f017b945a95d84023ccb639324906e4f8303a036a856ffd7ddec13\"}],\"cohort\":\"rrf@0.47\",\"enabled\":true,\"installdate"
		"\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.47\",\"AppMajorVersion\":\"145\",\"AppRollout\":0.47,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"2026.3.4.1\"},{\"appid\":\"lkkdlcloifjinapabfonaibjijloebfb\",\"brand\":\"INBX\",\"cached_items\":[{\"sha256\":\"e88948e0a3ac42d30aa2c203c5334ca648527996353413ded64951a5cd56c470\"}],\""
		"cohort\":\"rrf@0.80\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.80\",\"AppMajorVersion\":\"145\",\"AppRollout\":0.8,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"4.0.4.1\"},{\"appid\":\"lfmeghnikdkbonehgjihjebgioakijgn\",\"brand\":\"INBX\",\"cached_items\":[{\"sha256\":\""
		"017cd1932d44fa3f5b7dcfd7ace33af995856842862c48ffbdb1df11e661a0ee\"}],\"cohort\":\"rrf@0.80\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.80\",\"AppMajorVersion\":\"145\",\"AppRollout\":0.8,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"2.0.0.145\"},{\"appid\":\"pbdgbpmpeenomngainidcjmopnklimmf\",\""
		"brand\":\"INBX\",\"cohort\":\"rrf@1.00\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@1.00\",\"AppMajorVersion\":\"145\",\"AppRollout\":1,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"0.0.0.46\"},{\"appid\":\"hjaimielcgmceiphgjjfddlgjklfpdei\",\"brand\":\"INBX\",\"cohort\":\"rrf@0.04\",\"enabled\":true,\""
		"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.04\",\"AppMajorVersion\":\"145\",\"AppRollout\":0.04,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"1.0.0.5\"},{\"appid\":\"cllppcmmlnkggcmljjfigkcigaajjmid\",\"brand\":\"INBX\",\"cached_items\":[{\"sha256\":\"38b9a60260c000df8eadd64719d86020e30480df9afb893e60b5ef7d780616a5\"}],"
		"\"cohort\":\"rrf@0.16\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.16\",\"AppMajorVersion\":\"145\",\"AppRollout\":0.16,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"128.18367.18366.1\"},{\"appid\":\"pdfjdcjjjegpclfiilihfkmdfndkneei\",\"brand\":\"INBX\",\"cohort\":\"rrf@0.61\",\"enabled\":true,\""
		"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.61\",\"AppMajorVersion\":\"145\",\"AppRollout\":0.61,\"AppVersion\":\"145.0.3800.82\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.223.11\"},\"updatecheck\":{},\"version\":\"2025.7.24.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":1,\"physmemory\":16,\"sse\":1,\"sse2\":1,\"sse3\":1,\"sse41\":1,\"sse42\":1,\"ssse3\":1},"
		"\"ismachine\":1,\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.26200.7922\"},\"prodversion\":\"145.0.3800.82\",\"protocol\":\"4.0\",\"requestid\":\"{dd715f49-e127-44e6-a00b-a8d775f96d41}\",\"sessionid\":\"{d8dd567d-7e98-4ef8-bb8a-5c821e1f4882}\",\"updaters\":{\"autoupdatecheckenabled\":true,\"ismachine\":1,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.223.11\"},\"updaterversion\":\"145.0.3800.82\"}}", 
		LAST);

	web_custom_request("aiSuggestions", 
		"URL=https://edge.microsoft.com/autofillservice/core/aiSuggestions?useMultilingual=true", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"BodyBinary={\"currentFormData\":{\"domainInfo\":{\"URL\":\"https://thinking-tester-contact-list.herokuapp.com/addContact\",\"pageLocale\":\"en-US\"},\"fieldData\":[{\"autocompleteAttribute\":\"\",\"hintText\":\"\",\"label\":\"* First Name:\",\"value\":\"\"},{\"autocompleteAttribute\":\"\",\"hintText\":\"\",\"label\":\"* Last Name:\",\"value\":\"\"},{\"autocompleteAttribute\":\"\",\"hintText\":\"\",\"label\":\"Date of Birth:\",\"value\":\"\"},{\"autocompleteAttribute\":\"\",\"hintText\":\"\",\""
		"label\":\"Email:\",\"value\":\"\"},{\"autocompleteAttribute\":\"\",\"hintText\":\"\",\"label\":\"Phone:\",\"value\":\"\"},{\"autocompleteAttribute\":\"\",\"hintText\":\"\",\"label\":\"Street Address 1:\",\"value\":\"\"},{\"autocompleteAttribute\":\"\",\"hintText\":\"\",\"label\":\"Street Address 2:\",\"value\":\"\"},{\"autocompleteAttribute\":\"\",\"hintText\":\"\",\"label\":\"City:\",\"value\":\"\"},{\"autocompleteAttribute\":\"\",\"hintText\":\"\",\"label\":\"State or Province:\",\"value\":\"\"}"
		",{\"autocompleteAttribute\":\"\",\"hintText\":\"\",\"label\":\"Postal Code:\",\"value\":\"\"},{\"autocompleteAttribute\":\"\",\"hintText\":\"\",\"label\":\"Country:\",\"value\":\"\"}],\"formTitle\":\"\"},\"lastSubmittedForms\":[{\"fieldData\":[{\"type\":\"Amount\",\"value\":\"0.00\"},{\"type\":\"Category\",\"value\":\"Salary\"},{\"type\":\"Amount\",\"value\":\"136000.00\"},{\"type\":\"Total Loan Tenure (Months)\",\"value\":\"36\"},{\"type\":\"EMIs Paid\",\"value\":\"11\"},{\"type\":\"Loan Amount "
		"(\\xE2\\x82\\xB9)\",\"value\":\"5000000.00\"},{\"type\":\"Interest Rate (%)\",\"value\":\"7.90\"},{\"type\":\"Tenure (Years)\",\"value\":\"12\"}]},{\"fieldData\":[{\"type\":\"Category\",\"value\":\"others\"},{\"type\":\"Amount\",\"value\":\"1.00\"}]},{\"fieldData\":[{\"type\":\"Category\",\"value\":\"Meat\"},{\"type\":\"Amount\",\"value\":\"1200.00\"}]}],\"lastUsedProfiles\":[],\"mostUsedProfiles\":[]}", 
		LAST);

	/* Submit */

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("Origin", 
		"https://thinking-tester-contact-list.herokuapp.com");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("sec-ch-ua", 
		"\"Not:A-Brand\";v=\"99\", \"Microsoft Edge\";v=\"145\", \"Chromium\";v=\"145\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	lr_think_time(29);

	web_custom_request("contacts_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/addContact", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"firstName\":\"Santhosh\",\"lastName\":\"A\",\"phone\":\"9876543210\"}", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("contactList_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Resource=0", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/addContact", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/css/styles.css", ENDITEM, 
		"Url=/img/thinkingTesterLogo.png", ENDITEM, 
		"Url=/js/contactList.js", ENDITEM, 
		"Url=/img/thinkingTesterIcon.png", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_custom_request("contacts_3", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);

	/* Logout */

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(10);

	web_url("logout", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/logout", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_revert_auto_header("sec-ch-ua-platform");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_custom_request("3_5", 
		"URL=https://nav-edge.smartscreen.microsoft.com/api/browser/edge/navigate/3", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0\",\"redirectChain\":[],\"enhancedRedirectChain\":{\"redirectSource\":null,\"referrerChain\":[]},\"identity\":{\"user\":{\"locale\":\"en-US\"},\"device\":{\"id\":null,\"customId\":\"724e6b55-2db0-48f8-8304-bdd3b1009d3e\",\"onlineIdTicket\":\"t=GwD2Ad9tBAAUACvdRm27aTQoBWtI3fAPXDuVCyUOZgAAEMJy5VKLk5q1G3K2X4atGqjAAWKM/5To3nr4CHnxKJR/uYMv56jDrJbtk/"
		"jBEKSl3DXZBL4OIDWpArZsduVpsZRdO1TuAK7N2qK5R/Zh+qMKN4mEm/1ImaD9KBtI3A/pzc9tc+7hSKezO/T00s7VfOum8ZfCHv1a58R5A4OTuXoFAYgK1HXFEzuUqv+nMg2rQ2FY8YFDiLvj+fyLD7g675w+fg9GMORWL2DY61s3RWFt4S7oduVV1bm2zkrdZTFzYrmdTNhZjvxBe+daQn+sX50rMN+JOdxCzAmJppcb7ohbRR2QFee1IVUuv7HSjgficeSegUPVN4bcd629PvIMT6H91tuiUDW4n/H4DEfWmhV0kcdif4/nF3n2mA7dF5Iy6zx0ZsvB0Ba9fdX68W+lvPhuhUNnyEtLhFm9Qj2mOFVU/SsxImCDvQnUeniHROz1TOcxHepHjbdmKNm30xZn2QiXiY6AZ0l81vtY2GfticR/90g+g+exZJX/+8zmZYrOXUiZo+9ggukOeuVAl4lQXHkKk9IIIVDi+"
		"ptkv7zMaogUzV9X8G6IFRfgSEPvtYIhNBIgOlXIZW+k0VjA9kId4txiIPBsHll2aw2CkQqAtJYDFzL3AQ==&p=\",\"family\":3,\"locale\":\"en-US\",\"osVersion\":\"10.0.26200.7922.ge_release\",\"browser\":{\"internetExplorer\":\"9.11.26100.0\"},\"netJoinStatus\":2,\"enterprise\":{},\"cloudSku\":false,\"architecture\":9},\"caller\":{\"locale\":\"en-US\",\"name\":\"\",\"version\":\"145.0.3800.82 (Official build) \"},\"client\":{\"version\":\"281483731271680\",\"data\":{\"topTraffic\":\"638004170464094982\",\""
		"customSynchronousLookupUris\":\"0\",\"edgeSettings\":\"2.0-a82cb2897a8bf9445d68dcc2be05af89ad4b2fda1fddb2952693be7cd5353ad3\",\"customSettings\":\"F95BA787499AB4FA9EFFF472CE383A14\"}}},\"config\":{\"user\":{\"uriReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}},\"device\":{\"appControl\":{\"level\":\"anywhere\"},\"appReputation\":{\"enforcedByPolicy\":false,\"level\":\"warn\"}}},\"destination\":{\"uri\":\"https://thinking-tester-contact-list.herokuapp.com/logout\",\"ip\":\""
		"54.146.248.82\"},\"referrer\":{\"uri\":\"https://thinking-tester-contact-list.herokuapp.com/contactList\",\"ip\":\"3.229.186.102\"},\"type\":\"top\",\"forceServiceDetermination\":false,\"correlationId\":\"ddc37175-22c6-4aa2-a784-95a081c158e1\",\"synchronous\":false}", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("Origin", 
		"https://thinking-tester-contact-list.herokuapp.com");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("sec-ch-ua", 
		"\"Not:A-Brand\";v=\"99\", \"Microsoft Edge\";v=\"145\", \"Chromium\";v=\"145\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_custom_request("logout_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/users/logout", 
		"Method=POST", 
		"Resource=0", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/logout", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("thinking-tester-contact-list.herokuapp.com_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/", 
		"Resource=0", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/logout", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/img/thinkingTesterLogo.png", ENDITEM, 
		"Url=/js/login.js", ENDITEM, 
		LAST);

	return 0;
}